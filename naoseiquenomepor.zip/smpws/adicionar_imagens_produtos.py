import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartpaws.settings')
django.setup()

from produtos.models import Produto
from django.core.files import File

print("🖼️ Adicionando imagens aos produtos...\n")

# Você pode fazer de duas formas:

# OPÇÃO 1: Por ID do produto
IMAGENS_POR_ID = {
    1: 'racao_golden_adulto.jpg',
    2: 'racao_royal_filhote.jpg',
    3: 'petisco_palito.jpg',
    4: 'coleira_couro.jpg',
    5: 'cama_pet.jpg',
    # ... adicione mais conforme seus produtos
}

# OPÇÃO 2: Por nome do produto (mais fácil de gerenciar)
IMAGENS_POR_NOME = {
    'Ração Golden Fórmula Adultos': 'racao_golden_adulto.jpg',
    'Ração Royal Canin Filhote': 'racao_royal_filhote.jpg',
    'Petisco Palito Carne': 'petisco_palito.jpg',
    'Coleira de Couro': 'coleira_couro.jpg',
    'Cama Pet Macia': 'cama_pet.jpg',
    'Brinquedo Mordedor': 'brinquedo_mordedor.jpg',
    'Shampoo Pet': 'shampoo.jpg',
    'Areia Sanitária': 'areia_sanitaria.jpg',
    'Comedouro Inox': 'comedouro.jpg',
    'Bebedouro Automático': 'bebedouro.jpg',
}

produtos = Produto.objects.all()

for produto in produtos:
    # Verifica se já tem imagem principal
    if produto.imagem_principal:
        print(f"⏭️  {produto.nome} já tem imagem")
        continue
    
    # Busca pelo nome do produto
    arquivo = IMAGENS_POR_NOME.get(produto.nome)
    
    if not arquivo:
        print(f"⚠️  {produto.nome} - Sem imagem definida")
        continue
    
    caminho = f'media/produtos/{arquivo}'
    
    if os.path.exists(caminho):
        with open(caminho, 'rb') as f:
            produto.imagem_principal.save(arquivo, File(f), save=True)
        print(f"✅ {produto.nome} - Imagem adicionada!")
    else:
        print(f"❌ {produto.nome} - Arquivo {arquivo} não encontrado em {caminho}")

print("\n✨ Imagens de produtos adicionadas!\n")