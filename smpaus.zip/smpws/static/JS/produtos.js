// ==========================================
// PRODUTOS.JS - Smart Paws
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    
    // ========== AUTO-SUBMIT DOS FILTROS ==========
    const formFiltros = document.getElementById('form-filtros');
    const checkboxPromo = document.querySelector('input[name="em_promocao"]');
    const selectCategoria = document.getElementById('filtro-categoria');
    
    if (checkboxPromo) {
        checkboxPromo.addEventListener('change', function() {
            formFiltros.submit();
        });
    }
    
    if (selectCategoria) {
        selectCategoria.addEventListener('change', function() {
            formFiltros.submit();
        });
    }
    
    // ========== TOGGLE VIEW (GRID/LIST) ==========
    const btnViews = document.querySelectorAll('.btn-view');
    const produtosContainer = document.getElementById('produtos-container');
    
    btnViews.forEach(btn => {
        btn.addEventListener('click', function() {
            const view = this.getAttribute('data-view');
            
            // Remove active de todos
            btnViews.forEach(b => b.classList.remove('active'));
            
            // Adiciona active no clicado
            this.classList.add('active');
            
            // Muda o layout
            if (view === 'list') {
                produtosContainer.classList.add('produtos-list');
                produtosContainer.classList.remove('produtos-grid');
            } else {
                produtosContainer.classList.add('produtos-grid');
                produtosContainer.classList.remove('produtos-list');
            }
            
            // Salva preferência no localStorage
            localStorage.setItem('viewMode', view);
        });
    });
    
    // Carrega preferência salva
    const savedView = localStorage.getItem('viewMode');
    if (savedView === 'list') {
        document.querySelector('.btn-view[data-view="list"]')?.click();
    }
    
    // ========== BUSCA COM DEBOUNCE ==========
    const buscaInput = document.getElementById('busca-produtos');
    let timeoutBusca;
    
    if (buscaInput) {
        buscaInput.addEventListener('input', function() {
            clearTimeout(timeoutBusca);
            
            timeoutBusca = setTimeout(() => {
                if (this.value.length >= 3 || this.value.length === 0) {
                    formFiltros.submit();
                }
            }, 800); // Espera 800ms após parar de digitar
        });
    }
    
    // ========== ADICIONAR AO CARRINHO ==========
    window.adicionarCarrinho = function(produtoId) {
        // Animação de feedback
        const btn = event.target.closest('.btn-adicionar-carrinho');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adicionando...';
        btn.disabled = true;
        
        // Simulação de requisição (substitua por chamada AJAX real)
        setTimeout(() => {
            btn.innerHTML = '<i class="fas fa-check"></i> Adicionado!';
            btn.style.backgroundColor = '#28a745';
            
            // Restaura após 2 segundos
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
                btn.style.backgroundColor = '';
            }, 2000);
            
            // Atualiza contador do carrinho (se tiver)
            atualizarContadorCarrinho();
            
        }, 1000);
        
        console.log('Produto adicionado:', produtoId);
    };
    
    // ========== ATUALIZAR CONTADOR CARRINHO ==========
    function atualizarContadorCarrinho() {
        // Implementar quando tiver carrinho
        const contador = document.querySelector('.carrinho-contador');
        if (contador) {
            let atual = parseInt(contador.textContent) || 0;
            contador.textContent = atual + 1;
            
            // Animação
            contador.classList.add('pulse');
            setTimeout(() => contador.classList.remove('pulse'), 500);
        }
    }
    
    // ========== SMOOTH SCROLL ==========
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // ========== LOADING STATE ==========
    const formOrdenacao = document.querySelector('.form-ordenacao select');
    if (formOrdenacao) {
        formOrdenacao.addEventListener('change', function() {
            // Mostrar loading
            produtosContainer.style.opacity = '0.5';
            produtosContainer.style.pointerEvents = 'none';
        });
    }
    
    // ========== LAZY LOADING IMAGES ==========
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src || img.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        document.querySelectorAll('img[loading="lazy"]').forEach(img => {
            imageObserver.observe(img);
        });
    }
    
});

// ========== ANIMAÇÃO DE ENTRADA DOS CARDS ==========
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
        }
    });
}, {
    threshold: 0.1
});

// Adiciona o CSS da animação
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .card-produto {
        opacity: 0;
    }
    
    .pulse {
        animation: pulse 0.5s;
    }
    
    @keyframes pulse {
        0%, 100% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.2);
        }
    }
`;
document.head.appendChild(style);

// Observa todos os cards
document.querySelectorAll('.card-produto').forEach(card => {
    observer.observe(card);
});
