from django.contrib import admin
from django.utils.html import format_html
from .models import Carrinho, ItemCarrinho, CarrinhoAbandonado


class ItemCarrinhoInline(admin.TabularInline):

    model = ItemCarrinho
    extra = 0
    readonly_fields = ['subtotal', 'desconto_total', 'peso_total']
    fields = [
        'produto', 'quantidade', 'preco_unitario',
        'subtotal', 'desconto_total', 'observacoes'
    ]


@admin.register(Carrinho)
class CarrinhoAdmin(admin.ModelAdmin):

    
    list_display = [
        'usuario_email',
        'total_itens',
        'subtotal_formatado',
        'peso_total',
        'updated_at',
        'esta_vazio'
    ]
    
    list_filter = [
        'created_at',
        'updated_at',
        'itens__produto__categoria'
    ]
    
    search_fields = [
        'usuario__email',
        'usuario__username',
        'itens__produto__nome'
    ]
    
    readonly_fields = [
        'created_at',
        'updated_at',
        'total_itens',
        'subtotal',
        'total_desconto',
        'peso_total',
        'total_preco'
    ]
    
    inlines = [ItemCarrinhoInline]
    
    fieldsets = (
        ('Usuário', {
            'fields': ('usuario',)
        }),
        ('Resumo', {
            'fields': ('total_itens', 'subtotal', 'total_desconto', 'peso_total', 'total_preco')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )
    
    def usuario_email(self, obj):
        return obj.usuario.email
    usuario_email.short_description = 'Email do Usuário'
    
    def subtotal_formatado(self, obj):
        return format_html('R$ {:.2f}', obj.subtotal)
    subtotal_formatado.short_description = 'Subtotal'
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('usuario')


@admin.register(ItemCarrinho)
class ItemCarrinhoAdmin(admin.ModelAdmin):

    
    list_display = [
        'produto_nome',
        'usuario_email',
        'quantidade',
        'preco_unitario_formatado',
        'subtotal_formatado',
        'disponivel',
        'updated_at'
    ]
    
    list_filter = [
        'created_at',
        'updated_at',
        'produto__categoria',
        'produto__ativo'
    ]
    
    search_fields = [
        'produto__nome',
        'carrinho__usuario__email',
        'observacoes'
    ]
    
    readonly_fields = [
        'subtotal',
        'desconto_total',
        'peso_total',
        'created_at',
        'updated_at'
    ]
    
    def produto_nome(self, obj):
        return obj.produto.nome
    produto_nome.short_description = 'Produto'
    
    def usuario_email(self, obj):
        return obj.carrinho.usuario.email
    usuario_email.short_description = 'Usuário'
    
    def preco_unitario_formatado(self, obj):
        return format_html('R$ {:.2f}', obj.preco_unitario)
    preco_unitario_formatado.short_description = 'Preço Unitário'
    
    def subtotal_formatado(self, obj):
        return format_html('R$ {:.2f}', obj.subtotal)
    subtotal_formatado.short_description = 'Subtotal'
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related(
            'produto', 'produto__categoria', 'carrinho__usuario'
        )


@admin.register(CarrinhoAbandonado)
class CarrinhoAbandonadoAdmin(admin.ModelAdmin):
    """Admin para carrinhos abandonados"""
    
    list_display = [
        'usuario_email',
        'total_itens',
        'valor_carrinho',
        'data_abandono',
        'email_enviado',
        'recuperado'
    ]
    
    list_filter = [
        'email_enviado',
        'recuperado',
        'data_abandono',
        'data_email'
    ]
    
    search_fields = [
        'carrinho__usuario__email'
    ]
    
    readonly_fields = [
        'data_abandono',
        'data_email'
    ]
    
    actions = ['marcar_email_enviado', 'marcar_recuperado']
    
    def usuario_email(self, obj):
        return obj.carrinho.usuario.email
    usuario_email.short_description = 'Email'
    
    def total_itens(self, obj):
        return obj.carrinho.total_itens
    total_itens.short_description = 'Itens'
    
    def valor_carrinho(self, obj):
        return format_html('R$ {:.2f}', obj.carrinho.total_preco)
    valor_carrinho.short_description = 'Valor'
    
    def marcar_email_enviado(self, request, queryset):
        count = queryset.update(email_enviado=True)
        self.message_user(request, f'{count} carrinho(s) marcado(s) como email enviado.')
    marcar_email_enviado.short_description = 'Marcar email como enviado'
    
    def marcar_recuperado(self, request, queryset):
        count = queryset.update(recuperado=True)
        self.message_user(request, f'{count} carrinho(s) marcado(s) como recuperado.')
    marcar_recuperado.short_description = 'Marcar como recuperado'