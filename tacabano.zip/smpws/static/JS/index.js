

// FUTURO CARROSSEL

document.addEventListener('DOMContentLoaded', () => {
    const track = document.querySelector('.carrossel-track');
    const btnAnterior = document.querySelector('.carrossel-nav.anterior');
    const btnProximo = document.querySelector('.carrossel-nav.proximo');
    const items = document.querySelectorAll('.carrossel-item');
    
    if (!track || !items.length) return;
    
    let currentIndex = 0;
    let itemsPerView = 3; // Quantidade de cards visíveis
    let autoplayInterval;
    const autoplayDelay = 5000; // 5 segundos
    
    // Calcula quantos itens são visíveis baseado no tamanho da tela
    function updateItemsPerView() {
        const width = window.innerWidth;
        if (width <= 768) {
            itemsPerView = 1;
        } else if (width <= 1024) {
            itemsPerView = 2;
        } else {
            itemsPerView = 3;
        }
    }
    
    // Atualiza a posição do carrossel
    function updateCarousel() {
        const itemWidth = items[0].offsetWidth;
        const gap = 20; // Gap entre os itens
        const offset = -(currentIndex * (itemWidth + gap));
        track.style.transform = `translateX(${offset}px)`;
        
        // Atualiza estado dos botões
        btnAnterior.disabled = currentIndex === 0;
        btnProximo.disabled = currentIndex >= items.length - itemsPerView;
    }
    
    // Próximo slide
    function nextSlide() {
        if (currentIndex < items.length - itemsPerView) {
            currentIndex++;
            updateCarousel();
        } else {
            // Volta ao início
            currentIndex = 0;
            updateCarousel();
        }
    }
    
    // Slide anterior
    function prevSlide() {
        if (currentIndex > 0) {
            currentIndex--;
            updateCarousel();
        }
    }
    
    // Autoplay
    function startAutoplay() {
        autoplayInterval = setInterval(nextSlide, autoplayDelay);
    }
    
    function stopAutoplay() {
        clearInterval(autoplayInterval);
    }
    
    // Event listeners
    btnProximo?.addEventListener('click', () => {
        nextSlide();
        stopAutoplay();
        startAutoplay();
    });
    
    btnAnterior?.addEventListener('click', () => {
        prevSlide();
        stopAutoplay();
        startAutoplay();
    });
    
    // Pausa ao passar o mouse
    track.addEventListener('mouseenter', stopAutoplay);
    track.addEventListener('mouseleave', startAutoplay);
    
    // Suporte para teclado
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
            stopAutoplay();
            startAutoplay();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
            stopAutoplay();
            startAutoplay();
        }
    });
    
    // Suporte para swipe em mobile
    let touchStartX = 0;
    let touchEndX = 0;
    
    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoplay();
    });
    
    track.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
        startAutoplay();
    });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;
        
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                nextSlide();
            } else {
                prevSlide();
            }
        }
    }
    
    // Atualiza ao redimensionar a janela
    window.addEventListener('resize', () => {
        updateItemsPerView();
        currentIndex = 0; // Reseta ao redimensionar
        updateCarousel();
    });
    
    // Inicializa
    updateItemsPerView();
    updateCarousel();
    startAutoplay();
});



// MENU DROPDOWN

document.addEventListener('DOMContentLoaded', function() {
    // Seleciona todos os itens de menu que têm um dropdown
    const dropdowns = document.querySelectorAll('.has-dropdown');

    dropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('a'); 

        trigger.addEventListener('click', function(event) {
        
        if (trigger.getAttribute('href') === '#') {
            event.preventDefault();

            document.querySelectorAll('.has-dropdown.is-open').forEach(openDropdown => {
                if (openDropdown !== dropdown) {
                    openDropdown.classList.remove('is-open');
                }
            });

                dropdown.classList.toggle('is-open');
            }
        });
    });

    // Fecha o dropdown se o usuário clicar fora dele
    window.addEventListener('click', function(event) {
        // Verifica se o clique não foi dentro de um item com dropdown
        if (!event.target.closest('.has-dropdown')) {
            // Se não foi, remove a classe 'is-open' de todos os dropdowns
            document.querySelectorAll('.has-dropdown.is-open').forEach(openDropdown => {
                openDropdown.classList.remove('is-open');
            });
        }
    });
});



// --- INÍCIO: LÓGICA DA ANIMAÇÃO REVEAL AO ROLAR ---

document.addEventListener('DOMContentLoaded', () => {
    // 1. Seleciona todos os elementos que devem ser animados
    const elementsToReveal = document.querySelectorAll('.reveal-on-scroll');

    // 2. Cria o "observador"
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            // 3. Se o elemento está visível na tela...
            if (entry.isIntersecting) {
                // 4. ...adiciona a classe '.is-visible' para disparar a animação
                entry.target.classList.add('is-visible');
                // 5. (Opcional) Para a observação para que a animação aconteça só uma vez
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1 // A animação dispara quando 10% do elemento está visível
    });

    // 6. Inicia a observação para cada elemento
    elementsToReveal.forEach(element => {
        observer.observe(element);
    });
});

// --- FIM: LÓGICA DA ANIMAÇÃO REVEAL AO ROLAR ---
/* JS/index.js */

// --- INÍCIO: LÓGICA DO BOTÃO VOLTAR AO TOPO ---

document.addEventListener('DOMContentLoaded', () => {
    // 1. Seleciona o botão
    const backToTopButton = document.getElementById('back-to-top-btn');

    // 2. Adiciona um "ouvinte" para o evento de rolagem da página
    window.addEventListener('scroll', () => {
        // 3. Se o usuário rolou mais de 300 pixels para baixo...
        if (window.scrollY > 300) {
            // ...adiciona a classe que torna o botão visível
            backToTopButton.classList.add('is-visible');
        } else {
            // ...caso contrário, remove a classe
            backToTopButton.classList.remove('is-visible');
        }
    });

    // 4. Adiciona um "ouvinte" para o evento de clique no botão
    backToTopButton.addEventListener('click', () => {
        // 5. Rola a página suavemente de volta para o topo
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});
