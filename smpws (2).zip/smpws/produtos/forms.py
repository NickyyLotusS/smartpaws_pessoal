from django import forms
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models import Min, Max
from .models import Produto, Categoria, Marca, Avaliacao


class BuscaForm(forms.Form):
    """Formulário de busca simples"""
    
    q = forms.CharField(
        max_length=255,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Buscar produtos, marcas...',
            'autocomplete': 'off',
            'id': 'busca-input'
        }),
        label='Buscar'
    )
    
    def clean_q(self):
        """Limpa e valida termo de busca"""
        busca = self.cleaned_data.get('q', '').strip()
        if busca and len(busca) < 2:
            raise forms.ValidationError('Digite pelo menos 2 caracteres para buscar.')
        return busca


class ProdutoFilterForm(forms.Form):
    """Formulário avançado de filtros com choices dinâmicos"""
    
    categoria = forms.ModelChoiceField(
        queryset=Categoria.objects.none(),  # Será preenchido dinamicamente
        required=False,
        empty_label="Todas as categorias",
        widget=forms.Select(attrs={
            'class': 'form-select',
            'id': 'filtro-categoria'
        }),
        label='Categoria'
    )
    
    marca = forms.ModelChoiceField(
        queryset=Marca.objects.none(),  # Será preenchido dinamicamente
        required=False,
        empty_label="Todas as marcas",
        widget=forms.Select(attrs={
            'class': 'form-select',
            'id': 'filtro-marca'
        }),
        label='Marca'
    )
    
    tipo_animal = forms.ChoiceField(
        choices=[('', 'Todos os animais')] + Produto.TIPOS_ANIMAIS,
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select',
            'id': 'filtro-tipo-animal'
        }),
        label='Tipo de Animal'
    )
    
    idade_animal = forms.ChoiceField(
        choices=[('', 'Todas as idades')] + Produto.IDADES_ANIMAIS,
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select',
            'id': 'filtro-idade-animal'
        }),
        label='Idade do Animal'
    )
    
    preco_min = forms.DecimalField(
        required=False,
        min_value=0,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Preço mínimo',
            'step': '0.01',
            'id': 'filtro-preco-min'
        }),
        label='Preço Mínimo'
    )
    
    preco_max = forms.DecimalField(
        required=False,
        min_value=0,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Preço máximo',
            'step': '0.01',
            'id': 'filtro-preco-max'
        }),
        label='Preço Máximo'
    )
    
    promocao = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input',
            'id': 'filtro-promocao'
        }),
        label='Apenas produtos em promoção'
    )
    
    destaque = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input',
            'id': 'filtro-destaque'
        }),
        label='Apenas produtos em destaque'
    )
    
    novo = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input',
            'id': 'filtro-novo'
        }),
        label='Apenas lançamentos'
    )
    
    ordenar = forms.ChoiceField(
        choices=[
            ('relevancia', 'Relevância'),
            ('nome_asc', 'Nome A-Z'),
            ('nome_desc', 'Nome Z-A'),
            ('preco_asc', 'Menor preço'),
            ('preco_desc', 'Maior preço'),
            ('mais_vendidos', 'Mais vendidos'),
            ('lancamentos', 'Lançamentos'),
            ('avaliacoes', 'Melhor avaliados'),
        ],
        required=False,
        initial='relevancia',
        widget=forms.Select(attrs={
            'class': 'form-select',
            'id': 'filtro-ordenar'
        }),
        label='Ordenar por'
    )
    
    def __init__(self, *args, **kwargs):
        """Inicializa choices dinâmicos baseados nos produtos ativos"""
        super().__init__(*args, **kwargs)
        
        # Categorias ativas com produtos
        self.fields['categoria'].queryset = Categoria.objects.filter(
            ativo=True,
            produtos__ativo=True
        ).distinct().order_by('ordem', 'nome')
        
        # Marcas ativas com produtos
        self.fields['marca'].queryset = Marca.objects.filter(
            ativo=True,
            produtos__ativo=True
        ).distinct().order_by('nome')
        
        # Definir faixa de preços baseada nos produtos
        preco_range = Produto.objects.filter(ativo=True).aggregate(
            min_preco=Min('preco'),
            max_preco=Max('preco')
        )
        
        if preco_range['min_preco'] and preco_range['max_preco']:
            self.fields['preco_min'].widget.attrs.update({
                'min': preco_range['min_preco'],
                'max': preco_range['max_preco']
            })
            self.fields['preco_max'].widget.attrs.update({
                'min': preco_range['min_preco'],
                'max': preco_range['max_preco']
            })
    
    def clean(self):
        """Validação global do formulário"""
        cleaned_data = super().clean()
        preco_min = cleaned_data.get('preco_min')
        preco_max = cleaned_data.get('preco_max')
        
        # Validar faixa de preços
        if preco_min and preco_max and preco_min > preco_max:
            raise forms.ValidationError('Preço mínimo não pode ser maior que o máximo.')
        
        return cleaned_data


class AvaliacaoForm(forms.ModelForm):
    """Formulário para avaliações de produtos"""
    
    class Meta:
        model = Avaliacao
        fields = ['nota', 'titulo', 'comentario']
        
        widgets = {
            'nota': forms.RadioSelect(
                choices=[(i, f'{i} estrela{"s" if i > 1 else ""}') 
                        for i in range(1, 6)],
                attrs={'class': 'form-check-input'}
            ),
            'titulo': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Título da sua avaliação (opcional)',
                'maxlength': 100
            }),
            'comentario': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Compartilhe sua experiência com este produto...',
                'rows': 4,
                'maxlength': 500
            }),
        }
        
        labels = {
            'nota': 'Sua avaliação',
            'titulo': 'Título (opcional)',
            'comentario': 'Comentário'
        }
        
        help_texts = {
            'nota': 'Selecione de 1 a 5 estrelas',
            'comentario': 'Máximo 500 caracteres'
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Adicionar classes CSS para estrelas
        self.fields['nota'].widget.attrs.update({
            'class': 'avaliacao-estrelas'
        })
    
    def clean_comentario(self):
        """Valida comentário"""
        comentario = self.cleaned_data.get('comentario', '').strip()
        
        if len(comentario) < 10:
            raise forms.ValidationError('Comentário deve ter pelo menos 10 caracteres.')
        
        # Verificar palavras proibidas (básico)
        palavras_proibidas = ['spam', 'lixo', 'ruim demais']
        for palavra in palavras_proibidas:
            if palavra.lower() in comentario.lower():
                raise forms.ValidationError('Comentário contém conteúdo inadequado.')
        
        return comentario


class AdicionarCarrinhoForm(forms.Form):
    """Formulário para adicionar produto ao carrinho"""
    
    produto_id = forms.IntegerField(
        widget=forms.HiddenInput(),
        validators=[MinValueValidator(1)]
    )
    
    quantidade = forms.IntegerField(
        min_value=1,
        max_value=99,
        initial=1,
        widget=forms.NumberInput(attrs={
            'class': 'form-control text-center',
            'style': 'width: 80px;',
            'min': '1',
            'max': '99'
        }),
        label='Quantidade'
    )
    
    def __init__(self, produto=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        if produto:
            # Definir máximo baseado no estoque
            if produto.controlar_estoque:
                max_quantidade = min(produto.estoque, 99)
                self.fields['quantidade'].max_value = max_quantidade
                self.fields['quantidade'].widget.attrs['max'] = max_quantidade
                
                if max_quantidade <= 0:
                    self.fields['quantidade'].disabled = True
                    self.fields['quantidade'].help_text = 'Produto fora de estoque'
    
    def clean_quantidade(self):
        """Valida quantidade solicitada"""
        quantidade = self.cleaned_data.get('quantidade')
        
        if quantidade and quantidade <= 0:
            raise forms.ValidationError('Quantidade deve ser maior que zero.')
        
        return quantidade


class ComparacaoForm(forms.Form):
    """Formulário para comparar produtos"""
    
    produtos = forms.ModelMultipleChoiceField(
        queryset=Produto.objects.filter(ativo=True),
        widget=forms.CheckboxSelectMultiple(attrs={
            'class': 'form-check-input'
        }),
        label='Selecione produtos para comparar',
        help_text='Máximo 4 produtos'
    )
    
    def clean_produtos(self):
        """Limita comparação a 4 produtos"""
        produtos = self.cleaned_data.get('produtos')
        
        if produtos and len(produtos) > 4:
            raise forms.ValidationError('Você pode comparar no máximo 4 produtos.')
        
        if produtos and len(produtos) < 2:
            raise forms.ValidationError('Selecione pelo menos 2 produtos para comparar.')
        
        return produtos


class FiltroAvancadoForm(forms.Form):
    """Formulário de filtro mais avançado para busca específica"""
    
    q = forms.CharField(
        max_length=255,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Digite sua busca...',
        }),
        label='Buscar'
    )
    
    categoria = forms.ModelChoiceField(
        queryset=Categoria.objects.filter(ativo=True),
        required=False,
        empty_label="Categoria"
    )
    
    marca = forms.ModelChoiceField(
        queryset=Marca.objects.filter(ativo=True),
        required=False,
        empty_label="Marca"
    )
    
    preco_de = forms.DecimalField(
        required=False,
        min_value=0,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'De R$'
        })
    )
    
    preco_ate = forms.DecimalField(
        required=False,
        min_value=0,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Até R$'
        })
    )
    
    tem_estoque = forms.BooleanField(
        required=False,
        label='Apenas com estoque'
    )
    
    def __init__(self, *args, **kwargs):
        """Personaliza campos baseado em dados dinâmicos"""
        super().__init__(*args, **kwargs)
        
        # Aplicar classes CSS
        for field_name, field in self.fields.items():
            if isinstance(field.widget, forms.Select):
                field.widget.attrs['class'] = 'form-select'
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs['class'] = 'form-check-input'


class NewsletterForm(forms.Form):
    """Formulário para newsletter de produtos"""
    
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Seu e-mail para ofertas especiais'
        }),
        label='E-mail'
    )
    
    categorias_interesse = forms.ModelMultipleChoiceField(
        queryset=Categoria.objects.filter(ativo=True),
        required=False,
        widget=forms.CheckboxSelectMultiple(attrs={
            'class': 'form-check-input'
        }),
        label='Categorias de interesse'
    )
    
    aceito_termos = forms.BooleanField(
        required=True,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        }),
        label='Aceito receber e-mails promocionais'
    )