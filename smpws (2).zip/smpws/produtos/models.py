from django.db import models
from django.contrib.auth import get_user_model

from django.db import models
from django.contrib.auth import get_user_model
from django.utils.text import slugify
from django.urls import reverse
from django.core.validators import MinValueValidator, MaxValueValidator
from PIL import Image
import os

User = get_user_model()

class Categoria(models.Model):

    nome = models.CharField(max_length=100, unique= True, verbose_name="Nome da Categoria")
    slug = models.SlugField(max_length=150, unique=True, blank=True)
    descricao = models.TextField(blank=True, verbose_name='Descrição')
    imagem = models.ImageField(upload_to='categorias/%Y/%m/',blank=True,null=True,verbose_name='Imagem da Categoria')
    ativo = models.BooleanField(default=True, verbose_name='Categoria Ativa')
    ordem = models.PositiveIntegerField(default=0, help_text='Ordem de exibição (0 = primeiro)',verbose_name='Ordem')
    destaque = models.BooleanField( default=False,verbose_name='Destacar na home?')
    meta_title = models.CharField( max_length=60, blank=True, help_text='Título para SEO')
    meta_description = models.CharField( max_length=160, blank=True, help_text='Descrição para SEO')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Categoria'
        verbose_name_plural = 'Categorias'
        ordering = ['ordem', 'nome']
    
    def __str__(self):
        return self.nome
    
    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.nome)
            slug = base_slug
            contador = 1
            while Categoria.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{contador}"
                contador += 1
            self.slug = slug
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        return reverse('produtos:categoria', kwargs={'slug': self.slug})
    
    @property
    def total_produtos(self):
        """Total de produtos ativos na categoria"""
        return self.produtos.filter(ativo=True).count()


class Marca(models.Model):
    """Marcas dos produtos (Pedigree, Whiskas, etc)"""
    
    nome = models.CharField(
        max_length=100,
        unique=True,
        verbose_name='Nome da Marca'
    )
    slug = models.SlugField(
        max_length=150,
        unique=True,
        blank=True
    )
    logo = models.ImageField(
        upload_to='marcas/%Y/%m/',
        blank=True,
        null=True,
        verbose_name='Logo da Marca'
    )
    descricao = models.TextField(
        blank=True,
        verbose_name='Sobre a Marca'
    )
    site_oficial = models.URLField(
        blank=True,
        verbose_name='Site Oficial'
    )
    pais_origem = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='País de Origem'
    )
    ativo = models.BooleanField(
        default=True,
        verbose_name='Marca Ativa'
    )
    destaque = models.BooleanField(
        default=False,
        verbose_name='Marca em Destaque'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Marca'
        verbose_name_plural = 'Marcas'
        ordering = ['nome']
    
    def __str__(self):
        return self.nome
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nome)
        super().save(*args, **kwargs)
    
    @property
    def total_produtos(self):
        return self.produtos.filter(ativo=True).count()


class Produto(models.Model):
    """Produtos da loja"""
    
    # Choices
    TIPOS_ANIMAIS = [
        ('cao', 'Cão'),
        ('gato', 'Gato'),
        ('peixe', 'Peixe'),
        ('passaro', 'Pássaro'),
        ('hamster', 'Hamster'),
        ('coelho', 'Coelho'),
        ('reptil', 'Réptil'),
        ('todos', 'Todos os Animais'),
    ]
    
    IDADES_ANIMAIS = [
        ('filhote', 'Filhote'),
        ('adulto', 'Adulto'),
        ('senior', 'Senior'),
        ('todas', 'Todas as Idades'),
    ]
    
    UNIDADES_MEDIDA = [
        ('un', 'Unidade'),
        ('kg', 'Quilograma'),
        ('g', 'Grama'),
        ('l', 'Litro'),
        ('ml', 'Mililitro'),
        ('pacote', 'Pacote'),
    ]
    
    # Informações básicas
    nome = models.CharField(
        max_length=200,
        verbose_name='Nome do Produto'
    )
    slug = models.SlugField(
        max_length=150,
        unique=True,
        blank=True
    )
    descricao = models.TextField(
        verbose_name='Descrição Detalhada'
    )
    descricao_curta = models.CharField(
        max_length=255,
        blank=True,
        verbose_name='Descrição Resumida'
    )
    
    # Relacionamentos
    categoria = models.ForeignKey(
        Categoria,
        on_delete=models.CASCADE,
        related_name='produtos',
        verbose_name='Categoria'
    )
    marca = models.ForeignKey(
        Marca,
        on_delete=models.CASCADE,
        related_name='produtos',
        verbose_name='Marca'
    )
    
    # Preços
    preco = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0.01)],
        verbose_name='Preço'
    )
    preco_custo = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        validators=[MinValueValidator(0.01)],
        verbose_name='Preço de Custo'
    )
    preco_promocional = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        validators=[MinValueValidator(0.01)],
        verbose_name='Preço Promocional'
    )
    
    # Estoque
    estoque = models.PositiveIntegerField(
        default=0,
        verbose_name='Quantidade em Estoque'
    )
    estoque_minimo = models.PositiveIntegerField(
        default=5,
        help_text='Alerta quando estoque ficar abaixo',
        verbose_name='Estoque Mínimo'
    )
    controlar_estoque = models.BooleanField(
        default=True,
        verbose_name='Controlar Estoque?'
    )
    
    # Características físicas
    peso = models.DecimalField(
        max_digits=8,
        decimal_places=3,
        blank=True,
        null=True,
        help_text='Peso em KG',
        verbose_name='Peso (KG)'
    )
    dimensoes = models.CharField(
        max_length=50,
        blank=True,
        help_text='Formato: 10x20x30 (cm)',
        verbose_name='Dimensões (LxAxP)'
    )
    unidade_medida = models.CharField(
        max_length=10,
        choices=UNIDADES_MEDIDA,
        default='un',
        verbose_name='Unidade de Medida'
    )
    
    # Especificações para animais
    tipo_animal = models.CharField(
        max_length=10,
        choices=TIPOS_ANIMAIS,
        default='todos',
        verbose_name='Tipo de Animal'
    )
    idade_animal = models.CharField(
        max_length=10,
        choices=IDADES_ANIMAIS,
        default='todas',
        verbose_name='Idade do Animal'
    )
    
    # Informações adicionais
    ingredientes = models.TextField(
        blank=True,
        verbose_name='Ingredientes/Composição'
    )
    modo_uso = models.TextField(
        blank=True,
        verbose_name='Modo de Uso'
    )
    beneficios = models.TextField(
        blank=True,
        verbose_name='Benefícios'
    )
    
    # SKU e códigos
    sku = models.CharField(
        max_length=50,
        unique=True,
        blank=True,
        verbose_name='Código SKU'
    )
    codigo_barras = models.CharField(
        max_length=20,
        blank=True,
        verbose_name='Código de Barras'
    )
    
    # Status
    ativo = models.BooleanField(
        default=True,
        verbose_name='Produto Ativo'
    )
    destaque = models.BooleanField(
        default=False,
        verbose_name='Produto em Destaque'
    )
    novo = models.BooleanField(
        default=True,
        verbose_name='Produto Novo'
    )
    promocao = models.BooleanField(
        default=False,
        verbose_name='Em Promoção'
    )
    
    # Vendas
    total_vendas = models.PositiveIntegerField(
        default=0,
        verbose_name='Total de Vendas'
    )
    visualizacoes = models.PositiveIntegerField(
        default=0,
        verbose_name='Visualizações'
    )
    
    # SEO
    meta_title = models.CharField(
        max_length=60,
        blank=True,
        help_text='Título para SEO'
    )
    meta_description = models.CharField(
        max_length=160,
        blank=True,
        help_text='Descrição para SEO'
    )
    
    # Timestamps
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='Criado em'
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='Atualizado em'
    )
    
    class Meta:
        verbose_name = 'Produto'
        verbose_name_plural = 'Produtos'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['ativo', 'categoria']),
            models.Index(fields=['tipo_animal', 'ativo']),
            models.Index(fields=['destaque', 'ativo']),
            models.Index(fields=['promocao', 'ativo']),
        ]
    
    def __str__(self):
        return self.nome
    
    def save(self, *args, **kwargs):
        # Gerar slug automaticamente
        if not self.slug:
            base_slug = slugify(self.nome)
            slug = base_slug
            contador = 1
            while Produto.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{contador}"
                contador += 1
            self.slug = slug
        
        # Gerar SKU automaticamente
        if not self.sku:
            import uuid
            self.sku = f"PROD-{uuid.uuid4().hex[:8].upper()}"
        
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        return reverse('produtos:detalhe', kwargs={'slug': self.slug})
    
    @property
    def preco_final(self):
        """Retorna preço promocional se existir, senão preço normal"""
        return self.preco_promocional if self.preco_promocional else self.preco
    
    @property
    def tem_desconto(self):
        """Verifica se produto tem desconto"""
        return bool(self.preco_promocional and self.preco_promocional < self.preco)
    
    @property
    def percentual_desconto(self):
        """Calcula percentual de desconto"""
        if self.tem_desconto:
            return int(((self.preco - self.preco_promocional) / self.preco) * 100)
        return 0
    
    @property
    def estoque_baixo(self):
        """Verifica se estoque está baixo"""
        return self.estoque <= self.estoque_minimo if self.controlar_estoque else False
    
    @property
    def disponivel(self):
        """Verifica se produto está disponível"""
        if not self.ativo:
            return False
        if self.controlar_estoque:
            return self.estoque > 0
        return True
    
    @property
    def margem_lucro(self):
        """Calcula margem de lucro"""
        if self.preco_custo:
            return ((self.preco_final - self.preco_custo) / self.preco_custo) * 100
        return 0
    
    def incrementar_visualizacao(self):
        """Incrementa contador de visualizações"""
        self.visualizacoes += 1
        self.save(update_fields=['visualizacoes'])
    
    @property
    def media_avaliacoes(self):
        """Média das avaliações"""
        avaliacoes = self.avaliacoes.filter(aprovado=True)
        if avaliacoes.exists():
            return round(sum(a.nota for a in avaliacoes) / len(avaliacoes), 1)
        return 0
    
    @property
    def total_avaliacoes(self):
        """Total de avaliações aprovadas"""
        return self.avaliacoes.filter(aprovado=True).count()


class ImagemProduto(models.Model):
    """Múltiplas imagens para cada produto"""
    
    produto = models.ForeignKey(
        Produto,
        on_delete=models.CASCADE,
        related_name='imagens',
        verbose_name='Produto'
    )
    imagem = models.ImageField(
        upload_to='produtos/%Y/%m/',
        verbose_name='Imagem'
    )
    alt_text = models.CharField(
        max_length=200,
        help_text='Texto alternativo para acessibilidade',
        verbose_name='Texto Alternativo'
    )
    is_principal = models.BooleanField(
        default=False,
        verbose_name='Imagem Principal'
    )
    ordem = models.PositiveIntegerField(
        default=0,
        verbose_name='Ordem de Exibição'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Imagem do Produto'
        verbose_name_plural = 'Imagens dos Produtos'
        ordering = ['ordem', 'id']
    
    def __str__(self):
        return f"Imagem - {self.produto.nome}"
    
    def save(self, *args, **kwargs):
        # Se marcar como principal, remove das outras
        if self.is_principal:
            ImagemProduto.objects.filter(
                produto=self.produto
            ).update(is_principal=False)
        
        super().save(*args, **kwargs)
        
        # Redimensionar imagem
        if self.imagem:
            img = Image.open(self.imagem.path)
            # Redimensionar para máximo 800x800 mantendo proporção
            if img.height > 800 or img.width > 800:
                output_size = (800, 800)
                img.thumbnail(output_size)
                img.save(self.imagem.path)


class Avaliacao(models.Model):
    """Avaliações dos produtos pelos usuários"""
    
    produto = models.ForeignKey(
        Produto,
        on_delete=models.CASCADE,
        related_name='avaliacoes',
        verbose_name='Produto'
    )
    usuario = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        verbose_name='Usuário'
    )
    nota = models.PositiveIntegerField(
        choices=[(i, f'{i} estrela{"s" if i > 1 else ""}') for i in range(1, 6)],
        verbose_name='Nota'
    )
    titulo = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='Título da Avaliação'
    )
    comentario = models.TextField(
        verbose_name='Comentário'
    )
    aprovado = models.BooleanField(
        default=True,
        verbose_name='Avaliação Aprovada'
    )
    util = models.PositiveIntegerField(
        default=0,
        verbose_name='Avaliações "Útil"'
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='Avaliado em'
    )
    
    class Meta:
        verbose_name = 'Avaliação'
        verbose_name_plural = 'Avaliações'
        unique_together = ['produto', 'usuario'] 
        ordering = ['-created_at']
    
    def __str__(self):
        nome_usuario = getattr(self.usuario, 'nome_completo', self.usuario.username)
        return f"{nome_usuario} - {self.produto.nome} ({self.nota}★)"


class Lista(models.Model):
    """Listas de produtos (favoritos, desejos)"""
    
    TIPOS_LISTA = [
        ('favoritos', 'Favoritos'),
        ('desejos', 'Lista de Desejos'),
        ('comparar', 'Comparar'),
    ]
    
    usuario = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        verbose_name='Usuário'
    )
    tipo = models.CharField(
        max_length=20,
        choices=TIPOS_LISTA,
        default='favoritos'
    )
    nome = models.CharField(
        max_length=100,
        default='Minha Lista',
        verbose_name='Nome da Lista'
    )
    produtos = models.ManyToManyField(
        Produto,
        blank=True,
        verbose_name='Produtos'
    )
    publica = models.BooleanField(
        default=False,
        verbose_name='Lista Pública'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Lista'
        verbose_name_plural = 'Listas'
        unique_together = ['usuario', 'tipo']
    
    def __str__(self):
        return f"{self.nome} - {self.usuario.username}"
    
    @property
    def total_produtos(self):
        return self.produtos.count()