from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Avg, Count, Prefetch
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.generic import ListView, DetailView
from django.views.decorators.http import require_POST
from django.http import JsonResponse, Http404
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django.core.cache import cache
import json

from .models import Produto, Categoria, Marca, ImagemProduto, Avaliacao, Lista
from .forms import ProdutoFilterForm, AvaliacaoForm, BuscaForm
# from apps.carrinho.models import Carrinho, ItemCarrinho


class ProdutoListView(ListView):
    """Lista de produtos com filtros, busca e paginação"""
    
    model = Produto
    template_name = 'produtos/lista.html'
    context_object_name = 'produtos'
    paginate_by = 12
    
    def get_queryset(self):
        """Otimizada com select_related e prefetch_related"""
        queryset = Produto.objects.filter(ativo=True).select_related(
            'categoria', 'marca'
        ).prefetch_related(
            Prefetch('imagens', queryset=ImagemProduto.objects.filter(is_principal=True)),
            'avaliacoes'
        )
        
        # Aplicar filtros
        queryset = self._aplicar_filtros(queryset)
        
        # Aplicar busca
        queryset = self._aplicar_busca(queryset)
        
        # Ordenação
        queryset = self._aplicar_ordenacao(queryset)
        
        return queryset.distinct()
    
    def _aplicar_filtros(self, queryset):
        """Aplica filtros da URL"""
        # Filtro por categoria
        categoria_slug = self.request.GET.get('categoria')
        if categoria_slug:
            queryset = queryset.filter(categoria__slug=categoria_slug)
        
        # Filtro por marca
        marca_slug = self.request.GET.get('marca')
        if marca_slug:
            queryset = queryset.filter(marca__slug=marca_slug)
        
        # Filtro por tipo de animal
        tipo_animal = self.request.GET.get('tipo_animal')
        if tipo_animal:
            queryset = queryset.filter(tipo_animal=tipo_animal)
        
        # Filtro por idade do animal
        idade_animal = self.request.GET.get('idade_animal')
        if idade_animal:
            queryset = queryset.filter(idade_animal=idade_animal)
        
        # Filtro por faixa de preço
        preco_min = self.request.GET.get('preco_min')
        preco_max = self.request.GET.get('preco_max')
        
        if preco_min:
            try:
                queryset = queryset.filter(preco__gte=float(preco_min))
            except ValueError:
                pass
        
        if preco_max:
            try:
                queryset = queryset.filter(preco__lte=float(preco_max))
            except ValueError:
                pass
        
        # Filtros booleanos
        if self.request.GET.get('promocao'):
            queryset = queryset.filter(promocao=True)
        
        if self.request.GET.get('destaque'):
            queryset = queryset.filter(destaque=True)
        
        if self.request.GET.get('novo'):
            queryset = queryset.filter(novo=True)
        
        return queryset
    
    def _aplicar_busca(self, queryset):
        """Aplica busca por texto"""
        busca = self.request.GET.get('q', '').strip()
        if busca:
            queryset = queryset.filter(
                Q(nome__icontains=busca) |
                Q(descricao__icontains=busca) |
                Q(descricao_curta__icontains=busca) |
                Q(marca__nome__icontains=busca) |
                Q(categoria__nome__icontains=busca) |
                Q(sku__icontains=busca)
            )
        
        return queryset
    
    def _aplicar_ordenacao(self, queryset):
        """Aplica ordenação"""
        ordenar = self.request.GET.get('ordenar', 'relevancia')
        
        ordenacoes = {
            'relevancia': ['-destaque', '-total_vendas', '-visualizacoes'],
            'nome_asc': ['nome'],
            'nome_desc': ['-nome'],
            'preco_asc': ['preco'],
            'preco_desc': ['-preco'],
            'mais_vendidos': ['-total_vendas', '-visualizacoes'],
            'lancamentos': ['-created_at'],
            'avaliacoes': ['-avaliacoes__nota'],
        }
        
        if ordenar in ordenacoes:
            for campo in ordenacoes[ordenar]:
                queryset = queryset.order_by(campo)
        else:
            queryset = queryset.order_by('-destaque', '-created_at')
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Adicionar dados para filtros
        context.update({
            'categorias': Categoria.objects.filter(ativo=True).order_by('ordem', 'nome'),
            'marcas': Marca.objects.filter(ativo=True).order_by('nome'),
            'tipos_animais': Produto.TIPOS_ANIMAIS,
            'idades_animais': Produto.IDADES_ANIMAIS,
            'form_filtro': ProdutoFilterForm(self.request.GET),
            'form_busca': BuscaForm(self.request.GET),
            'filtros_ativos': self._get_filtros_ativos(),
            'total_produtos': self.get_queryset().count(),
        })
        
        # Manter parâmetros de filtro na paginação
        get_copy = self.request.GET.copy()
        if 'page' in get_copy:
            get_copy.pop('page')
        context['filtros_url'] = get_copy.urlencode()
        
        return context
    
    def _get_filtros_ativos(self):
        """Retorna filtros ativos para exibição"""
        filtros = []
        
        # Mapear parâmetros para nomes amigáveis
        mapeamentos = {
            'categoria': ('Categoria', lambda x: Categoria.objects.get(slug=x).nome if Categoria.objects.filter(slug=x).exists() else x),
            'marca': ('Marca', lambda x: Marca.objects.get(slug=x).nome if Marca.objects.filter(slug=x).exists() else x),
            'tipo_animal': ('Animal', dict(Produto.TIPOS_ANIMAIS).get),
            'idade_animal': ('Idade', dict(Produto.IDADES_ANIMAIS).get),
            'preco_min': ('Preço mín', lambda x: f'R$ {x}'),
            'preco_max': ('Preço máx', lambda x: f'R$ {x}'),
            'q': ('Busca', lambda x: f'"{x}"'),
        }
        
        for param, valor in self.request.GET.items():
            if param in mapeamentos and valor:
                try:
                    nome, formatter = mapeamentos[param]
                    valor_formatado = formatter(valor) if formatter else valor
                    if valor_formatado:
                        filtros.append({
                            'nome': nome,
                            'valor': valor_formatado,
                            'param': param,
                            'valor_param': valor
                        })
                except:
                    pass
        
        return filtros


class ProdutoDetailView(DetailView):
    """Detalhes do produto com otimizações"""
    
    model = Produto
    template_name = 'produtos/detalhe.html'
    context_object_name = 'produto'
    slug_field = 'slug'
    slug_url_kwarg = 'slug'
    
    def get_queryset(self):
        return Produto.objects.filter(ativo=True).select_related(
            'categoria', 'marca'
        ).prefetch_related(
            'imagens',
            Prefetch('avaliacoes', queryset=Avaliacao.objects.filter(aprovado=True).select_related('usuario'))
        )
    
    def get_object(self, queryset=None):
        produto = super().get_object(queryset)
        
        # Incrementar visualizações (apenas uma vez por sessão)
        session_key = f'produto_visto_{produto.id}'
        if not self.request.session.get(session_key):
            produto.incrementar_visualizacao()
            self.request.session[session_key] = True
        
        return produto
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        produto = context['produto']
        
        # Produtos relacionados
        produtos_relacionados = Produto.objects.filter(
            categoria=produto.categoria,
            ativo=True
        ).exclude(
            id=produto.id
        ).select_related(
            'categoria', 'marca'
        ).prefetch_related(
            'imagens'
        )[:8]
        
        # Estatísticas das avaliações
        avaliacoes_stats = produto.avaliacoes.filter(aprovado=True).aggregate(
            media=Avg('nota'),
            total=Count('id'),
            cinco_estrelas=Count('id', filter=Q(nota=5)),
            quatro_estrelas=Count('id', filter=Q(nota=4)),
            tres_estrelas=Count('id', filter=Q(nota=3)),
            duas_estrelas=Count('id', filter=Q(nota=2)),
            uma_estrela=Count('id', filter=Q(nota=1)),
        )
        
        # Verificar se usuário já avaliou
        ja_avaliou = False
        if self.request.user.is_authenticated:
            ja_avaliou = Avaliacao.objects.filter(
                produto=produto,
                usuario=self.request.user
            ).exists()
        
        context.update({
            'produtos_relacionados': produtos_relacionados,
            'avaliacoes_stats': avaliacoes_stats,
            'ja_avaliou': ja_avaliou,
            'form_avaliacao': AvaliacaoForm(),
            'imagens': produto.imagens.all().order_by('ordem'),
            'imagem_principal': produto.imagens.filter(is_principal=True).first(),
        })
        
        return context


def buscar_produtos(request):
    """View específica para busca com AJAX"""
    
    form = BuscaForm(request.GET)
    produtos = Produto.objects.none()
    
    if form.is_valid():
        termo = form.cleaned_data['q']
        
        produtos = Produto.objects.filter(
            Q(nome__icontains=termo) |
            Q(descricao__icontains=termo) |
            Q(marca__nome__icontains=termo) |
            Q(categoria__nome__icontains=termo)
        ).filter(ativo=True).select_related(
            'categoria', 'marca'
        ).prefetch_related('imagens')[:20]  # Limitar para performance
    
    # Se for requisição AJAX, retornar JSON
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        dados = []
        for produto in produtos:
            imagem_principal = produto.imagens.filter(is_principal=True).first()
            dados.append({
                'id': produto.id,
                'nome': produto.nome,
                'slug': produto.slug,
                'preco': float(produto.preco_final),
                'tem_desconto': produto.tem_desconto,
                'percentual_desconto': produto.percentual_desconto,
                'imagem': imagem_principal.imagem.url if imagem_principal else None,
                'categoria': produto.categoria.nome,
                'marca': produto.marca.nome,
                'url': produto.get_absolute_url(),
            })
        
        return JsonResponse({
            'produtos': dados,
            'total': len(dados)
        })
    
    # Senão, renderizar template
    context = {
        'produtos': produtos,
        'form': form,
        'termo_busca': form.cleaned_data.get('q') if form.is_valid() else ''
    }
    
    return render(request, 'produtos/busca.html', context)


@cache_page(60 * 5)  # Cache por 5 minutos
def categoria_detalhe(request, slug):
    """Detalhes de uma categoria específica"""
    
    categoria = get_object_or_404(Categoria, slug=slug, ativo=True)
    
    # Produtos da categoria com paginação
    produtos = Produto.objects.filter(
        categoria=categoria,
        ativo=True
    ).select_related('marca').prefetch_related('imagens').order_by('-destaque', '-created_at')
    
    # Aplicar filtros adicionais
    filtros = ProdutoFilterForm(request.GET)
    if filtros.is_valid():
        if filtros.cleaned_data.get('marca'):
            produtos = produtos.filter(marca__slug=filtros.cleaned_data['marca'])
        
        if filtros.cleaned_data.get('tipo_animal'):
            produtos = produtos.filter(tipo_animal=filtros.cleaned_data['tipo_animal'])
    
    # Paginação
    paginator = Paginator(produtos, 12)
    page = request.GET.get('page')
    
    try:
        produtos_paginados = paginator.page(page)
    except PageNotAnInteger:
        produtos_paginados = paginator.page(1)
    except EmptyPage:
        produtos_paginados = paginator.page(paginator.num_pages)
    
    # Estatísticas da categoria
    stats = {
        'total_produtos': produtos.count(),
        'marcas_distintas': produtos.values_list('marca__nome', flat=True).distinct().count(),
        'faixa_preco': produtos.aggregate(
            min_preco=models.Min('preco'),
            max_preco=models.Max('preco')
        )
    }
    
    context = {
        'categoria': categoria,
        'produtos': produtos_paginados,
        'stats': stats,
        'marcas': Marca.objects.filter(produtos__categoria=categoria, ativo=True).distinct(),
        'tipos_animais': Produto.TIPOS_ANIMAIS,
        'form_filtro': filtros,
    }
    
    return render(request, 'produtos/categoria.html', context)


@cache_page(60 * 5)  # Cache por 5 minutos
def marca_detalhe(request, slug):
    """Detalhes de uma marca específica"""
    
    marca = get_object_or_404(Marca, slug=slug, ativo=True)
    
    produtos = Produto.objects.filter(
        marca=marca,
        ativo=True
    ).select_related('categoria').prefetch_related('imagens').order_by('-destaque', '-created_at')
    
    # Paginação
    paginator = Paginator(produtos, 12)
    page = request.GET.get('page')
    produtos_paginados = paginator.get_page(page)
    
    context = {
        'marca': marca,
        'produtos': produtos_paginados,
        'total_produtos': produtos.count(),
        'categorias': Categoria.objects.filter(produtos__marca=marca, ativo=True).distinct(),
    }
    
    return render(request, 'produtos/marca.html', context)


@login_required
@require_POST
def adicionar_avaliacao(request, produto_slug):
    """Adicionar avaliação a um produto"""
    
    produto = get_object_or_404(Produto, slug=produto_slug, ativo=True)
    
    # Verificar se usuário já avaliou
    if Avaliacao.objects.filter(produto=produto, usuario=request.user).exists():
        messages.error(request, 'Você já avaliou este produto.')
        return redirect('produtos:detalhe', slug=produto.slug)
    
    form = AvaliacaoForm(request.POST)
    if form.is_valid():
        avaliacao = form.save(commit=False)
        avaliacao.produto = produto
        avaliacao.usuario = request.user
        avaliacao.save()
        
        messages.success(request, 'Avaliação adicionada com sucesso!')
    else:
        messages.error(request, 'Erro ao adicionar avaliação. Verifique os dados.')
    
    return redirect('produtos:detalhe', slug=produto.slug)


@login_required
@require_POST
def adicionar_ao_carrinho(request):
    """Adicionar produto ao carrinho (AJAX + Fallback)"""
    
    produto_id = request.POST.get('produto_id')
    quantidade = int(request.POST.get('quantidade', 1))
    
    try:
        produto = Produto.objects.get(id=produto_id, ativo=True)
        
        # Verificar disponibilidade
        if not produto.disponivel:
            raise ValueError('Produto não disponível.')
        
        if produto.controlar_estoque and quantidade > produto.estoque:
            raise ValueError('Quantidade indisponível em estoque.')
        
        # Obter ou criar carrinho
        carrinho, created = Carrinho.objects.get_or_create(usuario=request.user)
        
        # Adicionar ou atualizar item
        item, created = ItemCarrinho.objects.get_or_create(
            carrinho=carrinho,
            produto=produto,
            defaults={'quantidade': quantidade, 'preco_unitario': produto.preco_final}
        )
        
        if not created:
            nova_quantidade = item.quantidade + quantidade
            if produto.controlar_estoque and nova_quantidade > produto.estoque:
                raise ValueError('Quantidade total excede o estoque.')
            
            item.quantidade = nova_quantidade
            item.preco_unitario = produto.preco_final  # Atualizar preço
            item.save()
        
        # Resposta para AJAX
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': True,
                'message': f'{produto.nome} adicionado ao carrinho!',
                'carrinho': {
                    'total_itens': carrinho.total_itens,
                    'total_preco': float(carrinho.total_preco)
                }
            })
        
        messages.success(request, f'{produto.nome} adicionado ao carrinho!')
        
    except Produto.DoesNotExist:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'message': 'Produto não encontrado.'})
        messages.error(request, 'Produto não encontrado.')
        
    except ValueError as e:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'message': str(e)})
        messages.error(request, str(e))
    
    except Exception as e:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'message': 'Erro interno.'})
        messages.error(request, 'Erro ao adicionar produto ao carrinho.')
    
    # Fallback para não-AJAX
    return redirect('produtos:detalhe', slug=produto.slug if 'produto' in locals() else '')


@login_required
def gerenciar_lista(request, tipo='favoritos'):
    """Gerenciar listas (favoritos, desejos, etc.)"""
    
    tipos_validos = ['favoritos', 'desejos', 'comparar']
    if tipo not in tipos_validos:
        raise Http404
    
    lista, created = Lista.objects.get_or_create(
        usuario=request.user,
        tipo=tipo,
        defaults={'nome': dict(Lista.TIPOS_LISTA)[tipo]}
    )
    
    produtos = lista.produtos.filter(ativo=True).select_related(
        'categoria', 'marca'
    ).prefetch_related('imagens')
    
    # Paginação
    paginator = Paginator(produtos, 12)
    page = request.GET.get('page')
    produtos_paginados = paginator.get_page(page)
    
    context = {
        'lista': lista,
        'produtos': produtos_paginados,
        'tipo': tipo,
    }
    
    return render(request, 'produtos/lista_usuario.html', context)


@login_required
@require_POST
def toggle_lista(request):
    """Adicionar/remover produto da lista (AJAX)"""
    
    produto_id = request.POST.get('produto_id')
    tipo = request.POST.get('tipo', 'favoritos')
    
    try:
        produto = Produto.objects.get(id=produto_id, ativo=True)
        lista, created = Lista.objects.get_or_create(
            usuario=request.user,
            tipo=tipo,
            defaults={'nome': dict(Lista.TIPOS_LISTA)[tipo]}
        )
        
        if produto in lista.produtos.all():
            lista.produtos.remove(produto)
            adicionado = False
            message = f'Removido de {lista.nome}'
        else:
            lista.produtos.add(produto)
            adicionado = True
            message = f'Adicionado a {lista.nome}'
        
        return JsonResponse({
            'success': True,
            'adicionado': adicionado,
            'message': message,
            'total': lista.total_produtos
        })
        
    except Produto.DoesNotExist:
        return JsonResponse({
            'success': False,
            'message': 'Produto não encontrado.'
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': 'Erro interno.'
        })


def produtos_em_destaque(request):
    """API para produtos em destaque (usado em AJAX)"""
    
    produtos = Produto.objects.filter(
        ativo=True,
        destaque=True
    ).select_related('categoria', 'marca').prefetch_related('imagens')[:8]
    
    dados = []
    for produto in produtos:
        imagem_principal = produto.imagens.filter(is_principal=True).first()
        dados.append({
            'id': produto.id,
            'nome': produto.nome,
            'slug': produto.slug,
            'preco': float(produto.preco_final),
            'tem_desconto': produto.tem_desconto,
            'percentual_desconto': produto.percentual_desconto,
            'imagem': imagem_principal.imagem.url if imagem_principal else None,
            'categoria': produto.categoria.nome,
            'url': produto.get_absolute_url(),
        })
    
    return JsonResponse({'produtos': dados})


# View para comparar produtos
def comparar_produtos(request):
    """Comparar até 4 produtos"""
    
    produto_ids = request.GET.getlist('produtos')
    
    if len(produto_ids) > 4:
        messages.warning(request, 'Máximo 4 produtos para comparação.')
        produto_ids = produto_ids[:4]
    
    produtos = Produto.objects.filter(
        id__in=produto_ids,
        ativo=True
    ).select_related('categoria', 'marca').prefetch_related('imagens')
    
    context = {
        'produtos': produtos,
        'total_produtos': len(produtos)
    }
    
    return render(request, 'produtos/comparar.html', context)