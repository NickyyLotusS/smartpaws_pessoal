from rest_framework import serializers
from decimal import Decimal
from django.core.exceptions import ValidationError as DjangoValidationError
from django.utils import timezone
from .models import (
    TipoServico, Profissional, Servico, HorarioFuncionamento,
    Agendamento, AvaliacaoServico, FotoServico
)
from usuarios.serializers import UsuarioBasicoSerializer


class TipoServicoSerializer(serializers.ModelSerializer):
    """Serializer para tipos de serviços"""
    
    class Meta:
        model = TipoServico
        fields = [
            'id', 'nome', 'titulo', 'descricao', 'icone', 'cor', 'ativo'
        ]


class HorarioFuncionamentoSerializer(serializers.ModelSerializer):
    """Serializer para horários de funcionamento"""
    
    dia_semana_nome = serializers.CharField(source='get_dia_semana_display', read_only=True)
    
    class Meta:
        model = HorarioFuncionamento
        fields = [
            'id', 'dia_semana', 'dia_semana_nome', 'hora_inicio', 'hora_fim', 'ativo'
        ]


class FotoServicoSerializer(serializers.ModelSerializer):
    """Serializer para fotos dos serviços"""
    
    class Meta:
        model = FotoServico
        fields = ['id', 'imagem', 'descricao', 'created_at']


class ServicoSerializer(serializers.ModelSerializer):
    """Serializer para serviços"""
    
    tipo_servico = TipoServicoSerializer(read_only=True)
    preco_final = serializers.ReadOnlyField()
    tem_desconto = serializers.ReadOnlyField()
    percentual_desconto = serializers.ReadOnlyField()
    
    class Meta:
        model = Servico
        fields = [
            'id', 'tipo_servico', 'nome', 'descricao', 'preco_base',
            'preco_promocional', 'preco_final', 'tem_desconto', 'percentual_desconto',
            'duracao_estimada', 'aceita_domicilio', 'taxa_deslocamento',
            'aceita_pequeno', 'aceita_medio', 'aceita_grande', 'ativo'
        ]


class ProfissionalSerializer(serializers.ModelSerializer):
    """Serializer para profissionais"""
    
    usuario = UsuarioBasicoSerializer(read_only=True)
    servicos = ServicoSerializer(many=True, read_only=True)
    horarios = HorarioFuncionamentoSerializer(many=True, read_only=True)
    fotos = FotoServicoSerializer(many=True, read_only=True)
    endereco_completo = serializers.ReadOnlyField()
    esta_ativo = serializers.ReadOnlyField()
    
    class Meta:
        model = Profissional
        fields = [
            'id', 'usuario', 'tipo', 'nome_comercial', 'descricao',
            'telefone_comercial', 'whatsapp', 'email_comercial', 'site',
            'endereco_completo', 'foto_perfil', 'foto_local',
            'status', 'aceita_agendamentos', 'nota_media', 'total_avaliacoes',
            'esta_ativo', 'servicos', 'horarios', 'fotos', 'created_at'
        ]


class ProfissionalResumoSerializer(serializers.ModelSerializer):
    """Serializer resumido para listagens"""
    
    endereco_completo = serializers.ReadOnlyField()
    total_servicos = serializers.SerializerMethodField()
    
    class Meta:
        model = Profissional
        fields = [
            'id', 'nome_comercial', 'descricao', 'foto_perfil',
            'nota_media', 'total_avaliacoes', 'endereco_completo',
            'total_servicos', 'aceita_agendamentos'
        ]
    
    def get_total_servicos(self, obj):
        return obj.servicos.filter(ativo=True).count()


class AgendamentoSerializer(serializers.ModelSerializer):
    """Serializer para agendamentos"""
    
    cliente = UsuarioBasicoSerializer(read_only=True)
    servico = ServicoSerializer(read_only=True)
    data_hora_completa = serializers.ReadOnlyField()
    pode_cancelar = serializers.ReadOnlyField()
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = Agendamento
        fields = [
            'id', 'cliente', 'servico', 'data_agendamento', 'hora_agendamento',
            'data_hora_completa', 'nome_pet', 'especie_pet', 'porte_pet',
            'observacoes_pet', 'endereco_servico', 'valor_servico',
            'valor_deslocamento', 'valor_total', 'forma_pagamento', 'pago',
            'status', 'status_display', 'pode_cancelar', 'observacoes',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'valor_total', 'created_at', 'updated_at']


class CriarAgendamentoSerializer(serializers.ModelSerializer):
    """Serializer para criar agendamento"""
    
    servico_id = serializers.IntegerField()
    
    class Meta:
        model = Agendamento
        fields = [
            'servico_id', 'data_agendamento', 'hora_agendamento',
            'nome_pet', 'especie_pet', 'porte_pet', 'observacoes_pet',
            'endereco_servico', 'forma_pagamento', 'observacoes'
        ]
    
    def validate_servico_id(self, value):
        """Valida se serviço existe e está ativo"""
        try:
            servico = Servico.objects.get(id=value, ativo=True)
            if not servico.profissional.esta_ativo:
                raise serializers.ValidationError("Profissional não está ativo.")
            return value
        except Servico.DoesNotExist:
            raise serializers.ValidationError("Serviço não encontrado.")
    
    def validate_data_agendamento(self, value):
        """Valida data do agendamento"""
        if value < timezone.now().date():
            raise serializers.ValidationError("Não é possível agendar para datas passadas.")
        return value
    
    def validate(self, attrs):
        """Validação geral"""
        servico_id = attrs['servico_id']
        data_agendamento = attrs['data_agendamento']
        hora_agendamento = attrs['hora_agendamento']
        
        try:
            servico = Servico.objects.get(id=servico_id)
            
            # Verificar se profissional atende no dia/hora
            dia_semana = data_agendamento.weekday()
            horario = servico.profissional.horarios.filter(
                dia_semana=dia_semana,
                ativo=True
            ).first()
            
            if not horario:
                raise serializers.ValidationError(
                    "Profissional não atende neste dia da semana."
                )
            
            if not (horario.hora_inicio <= hora_agendamento <= horario.hora_fim):
                raise serializers.ValidationError(
                    "Horário fora do funcionamento do profissional."
                )
            
            # Verificar se horário está disponível
            if Agendamento.objects.filter(
                servico=servico,
                data_agendamento=data_agendamento,
                hora_agendamento=hora_agendamento,
                status__in=['pendente', 'confirmado', 'em_andamento']
            ).exists():
                raise serializers.ValidationError(
                    "Horário já está ocupado."
                )
            
            attrs['servico'] = servico
            
        except Servico.DoesNotExist:
            raise serializers.ValidationError("Serviço não encontrado.")
        
        return attrs
    
    def create(self, validated_data):
        """Cria agendamento com cálculos automáticos"""
        servico = validated_data.pop('servico')
        validated_data.pop('servico_id')
        
        # Calcular valores
        valor_servico = servico.preco_final
        valor_deslocamento = Decimal('0.00') #verificar a biblioteca
        
        if validated_data.get('endereco_servico') and servico.aceita_domicilio:
            valor_deslocamento = servico.taxa_deslocamento
        
        valor_total = valor_servico + valor_deslocamento
        
        agendamento = Agendamento.objects.create(
            servico=servico,
            cliente=self.context['request'].user,
            valor_servico=valor_servico,
            valor_deslocamento=valor_deslocamento,
            valor_total=valor_total,
            **validated_data
        )
        
        return agendamento


class AvaliacaoServicoSerializer(serializers.ModelSerializer):
    """Serializer para avaliações"""
    
    cliente = UsuarioBasicoSerializer(read_only=True)
    profissional = ProfissionalResumoSerializer(read_only=True)
    
    class Meta:
        model = AvaliacaoServico
        fields = [
            'id', 'cliente', 'profissional', 'nota', 'titulo', 'comentario',
            'pontualidade', 'qualidade', 'atendimento', 'recomenda',
            'aprovado', 'created_at'
        ]
        read_only_fields = ['id', 'created_at']


class CadastrarProfissionalSerializer(serializers.ModelSerializer):
    """Serializer para cadastro de profissional"""
    
    class Meta:
        model = Profissional
        fields = [
            'tipo', 'nome_comercial', 'descricao', 'cpf_cnpj', 'rg_ie',
            'telefone_comercial', 'whatsapp', 'email_comercial', 'site',
            'cep', 'logradouro', 'numero', 'complemento', 'bairro',
            'cidade', 'estado', 'foto_perfil', 'foto_local'
        ]
    
    def create(self, validated_data):
        """Cria perfil profissional para o usuário logado"""
        validated_data['usuario'] = self.context['request'].user
        validated_data['status'] = 'pendente'
        return super().create(validated_data)