from django.db import models
from django.contrib.auth.models import User

class Parceiro(models.Model):
    nome = models.CharField(max_length=200)
    logo = models.ImageField(upload_to='parceiros/')
    site = models.URLField(blank=True)
    ativo = models.BooleanField(default=True)
    
    class Meta:
        verbose_name_plural = "Parceiros"
    
    def __str__(self):
        return self.nome


class Pet(models.Model):
    SEXO_CHOICES = [
        ('M', 'Macho'),
        ('F', 'Fêmea'),
    ]
    
    TIPO_CHOICES = [
        ('cachorro', 'Cachorro'),
        ('gato', 'Gato'),
    ]
    
    STATUS_CHOICES = [
        ('disponivel', 'Disponível'),
        ('em_processo', 'Em Processo de Adoção'),
        ('adotado', 'Adotado'),
    ]
    
    nome = models.CharField(max_length=100)
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES, default='cachorro')
    sexo = models.CharField(max_length=1, choices=SEXO_CHOICES)
    idade = models.IntegerField(help_text="Idade em meses")
    raca = models.CharField(max_length=100, blank=True)
    descricao = models.TextField()
    foto = models.ImageField(upload_to='pets/')
    
    # Localização
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2)
    
    # Parceiro responsável
    parceiro = models.ForeignKey(Parceiro, on_delete=models.CASCADE, related_name='pets')
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='disponivel')
    data_cadastro = models.DateTimeField(auto_now_add=True)
    visualizacoes = models.IntegerField(default=0)
    
    # Características
    castrado = models.BooleanField(default=False)
    vacinado = models.BooleanField(default=False)
    vermifugado = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-data_cadastro']
    
    def __str__(self):
        return f"{self.nome} - {self.cidade}/{self.estado}"
    
    def incrementar_visualizacao(self):
        self.visualizacoes += 1
        self.save(update_fields=['visualizacoes'])


class SolicitacaoAdocao(models.Model):
    STATUS_CHOICES = [
        ('pendente', 'Pendente'),
        ('aprovada', 'Aprovada'),
        ('recusada', 'Recusada'),
    ]
    
    pet = models.ForeignKey(Pet, on_delete=models.CASCADE, related_name='solicitacoes')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='solicitacoes_adocao')
    
    # Dados do solicitante
    nome_completo = models.CharField(max_length=200)
    email = models.EmailField()
    telefone = models.CharField(max_length=20)
    cpf = models.CharField(max_length=14)
    
    # Endereço
    endereco = models.CharField(max_length=300)
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2)
    cep = models.CharField(max_length=9)
    
    # Informações sobre moradia
    tipo_moradia = models.CharField(max_length=100, 
        choices=[
            ('casa', 'Casa'),
            ('apartamento', 'Apartamento'),
        ]
    )
    possui_quintal = models.BooleanField(default=False)
    tem_outros_pets = models.BooleanField(default=False)
    descricao_outros_pets = models.TextField(blank=True)
    
    # Motivação
    motivo_adocao = models.TextField()
    experiencia_pets = models.TextField()
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pendente')
    data_solicitacao = models.DateTimeField(auto_now_add=True)
    data_resposta = models.DateTimeField(null=True, blank=True)
    observacoes = models.TextField(blank=True)
    
    class Meta:
        verbose_name = "Solicitação de Adoção"
        verbose_name_plural = "Solicitações de Adoção"
        ordering = ['-data_solicitacao']
    
    def __str__(self):
        return f"{self.nome_completo} - {self.pet.nome}"


class PromocaoAdocao(models.Model):
    STATUS_CHOICES = [
        ('pendente', 'Pendente Aprovação'),
        ('aprovada', 'Aprovada'),
        ('recusada', 'Recusada'),
    ]
    
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='promocoes_adocao')
    
    # Dados do pet
    nome_pet = models.CharField(max_length=100)
    tipo_pet = models.CharField(max_length=20, 
        choices=[
            ('cachorro', 'Cachorro'),
            ('gato', 'Gato'),
        ]
    )
    sexo = models.CharField(max_length=1, 
        choices=[
            ('M', 'Macho'),
            ('F', 'Fêmea'),
        ]
    )
    idade = models.IntegerField(help_text="Idade em meses")
    raca = models.CharField(max_length=100, blank=True)
    descricao = models.TextField()
    foto = models.ImageField(upload_to='promocao_pets/')
    
    # Dados do responsável
    nome_responsavel = models.CharField(max_length=200)
    email = models.EmailField()
    telefone = models.CharField(max_length=20)
    
    # Localização do pet
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2)
    
    # Informações adicionais
    motivo = models.TextField(help_text="Por que está promovendo a adoção?")
    castrado = models.BooleanField(default=False)
    vacinado = models.BooleanField(default=False)
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pendente')
    data_solicitacao = models.DateTimeField(auto_now_add=True)
    data_resposta = models.DateTimeField(null=True, blank=True)
    observacoes_admin = models.TextField(blank=True)
    
    class Meta:
        verbose_name = "Promoção de Adoção"
        verbose_name_plural = "Promoções de Adoção"
        ordering = ['-data_solicitacao']
    
    def __str__(self):
        return f"{self.nome_pet} - {self.nome_responsavel}"