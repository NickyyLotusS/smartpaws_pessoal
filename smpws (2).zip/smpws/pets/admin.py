from django.contrib import admin
from django.utils.html import format_html
from .models import Parceiro, Pet, SolicitacaoAdocao, PromocaoAdocao


@admin.register(Parceiro)
class ParceiroAdmin(admin.ModelAdmin):
    list_display = ['nome', 'ativo', 'site', 'total_pets']
    list_filter = ['ativo']
    search_fields = ['nome']
    
    def total_pets(self, obj):
        return obj.pets.count()
    total_pets.short_description = 'Total de Pets'
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.prefetch_related('pets')


@admin.register(Pet)
class PetAdmin(admin.ModelAdmin):
    list_display = ['nome', 'tipo', 'sexo', 'idade_display', 'cidade_estado', 
                    'parceiro', 'status', 'visualizacoes', 'data_cadastro']
    list_filter = ['status', 'tipo', 'sexo', 'parceiro', 'estado', 'castrado', 'vacinado']
    search_fields = ['nome', 'cidade', 'raca', 'descricao']
    readonly_fields = ['visualizacoes', 'data_cadastro', 'preview_foto']
    
    fieldsets = (
        ('Informações Básicas', {
            'fields': ('nome', 'tipo', 'sexo', 'idade', 'raca', 'descricao')
        }),
        ('Localização', {
            'fields': ('cidade', 'estado')
        }),
        ('Foto', {
            'fields': ('foto', 'preview_foto')
        }),
        ('Parceiro e Status', {
            'fields': ('parceiro', 'status')
        }),
        ('Características', {
            'fields': ('castrado', 'vacinado', 'vermifugado')
        }),
        ('Estatísticas', {
            'fields': ('visualizacoes', 'data_cadastro')
        }),
    )
    
    def idade_display(self, obj):
        anos = obj.idade // 12
        meses = obj.idade % 12
        if anos > 0:
            return f"{anos} ano{'s' if anos > 1 else ''} e {meses} mese{'s' if meses != 1 else ''}"
        return f"{meses} mese{'s' if meses != 1 else ''}"
    idade_display.short_description = 'Idade'
    
    def cidade_estado(self, obj):
        return f"{obj.cidade}/{obj.estado}"
    cidade_estado.short_description = 'Localização'
    
    def preview_foto(self, obj):
        if obj.foto:
            return format_html('<img src="{}" style="max-height: 200px; border-radius: 10px;"/>', obj.foto.url)
        return "Sem foto"
    preview_foto.short_description = 'Preview'


@admin.register(SolicitacaoAdocao)
class SolicitacaoAdocaoAdmin(admin.ModelAdmin):
    list_display = ['nome_completo', 'pet', 'usuario', 'status', 
                    'data_solicitacao', 'cidade_estado']
    list_filter = ['status', 'data_solicitacao', 'tipo_moradia', 
                   'possui_quintal', 'tem_outros_pets']
    search_fields = ['nome_completo', 'email', 'cpf', 'pet__nome']
    readonly_fields = ['usuario', 'pet', 'data_solicitacao']
    date_hierarchy = 'data_solicitacao'
    
    fieldsets = (
        ('Pet e Solicitante', {
            'fields': ('pet', 'usuario', 'status', 'data_solicitacao', 'data_resposta')
        }),
        ('Dados Pessoais', {
            'fields': ('nome_completo', 'email', 'telefone', 'cpf')
        }),
        ('Endereço', {
            'fields': ('endereco', 'cidade', 'estado', 'cep')
        }),
        ('Informações sobre Moradia', {
            'fields': ('tipo_moradia', 'possui_quintal', 'tem_outros_pets', 
                      'descricao_outros_pets')
        }),
        ('Motivação', {
            'fields': ('motivo_adocao', 'experiencia_pets')
        }),
        ('Observações', {
            'fields': ('observacoes',)
        }),
    )
    
    def cidade_estado(self, obj):
        return f"{obj.cidade}/{obj.estado}"
    cidade_estado.short_description = 'Localização'
    
    actions = ['aprovar_solicitacoes', 'recusar_solicitacoes']
    
    def aprovar_solicitacoes(self, request, queryset):
        from django.utils import timezone
        updated = queryset.update(status='aprovada', data_resposta=timezone.now())
        self.message_user(request, f'{updated} solicitação(ões) aprovada(s).')
    aprovar_solicitacoes.short_description = 'Aprovar solicitações selecionadas'
    
    def recusar_solicitacoes(self, request, queryset):
        from django.utils import timezone
        updated = queryset.update(status='recusada', data_resposta=timezone.now())
        self.message_user(request, f'{updated} solicitação(ões) recusada(s).')
    recusar_solicitacoes.short_description = 'Recusar solicitações selecionadas'


@admin.register(PromocaoAdocao)
class PromocaoAdocaoAdmin(admin.ModelAdmin):
    list_display = ['nome_pet', 'nome_responsavel', 'usuario', 'status', 
                    'data_solicitacao', 'cidade_estado']
    list_filter = ['status', 'tipo_pet', 'sexo', 'data_solicitacao']
    search_fields = ['nome_pet', 'nome_responsavel', 'email', 'cidade']
    readonly_fields = ['usuario', 'data_solicitacao', 'preview_foto']
    date_hierarchy = 'data_solicitacao'
    
    fieldsets = (
        ('Status', {
            'fields': ('status', 'data_solicitacao', 'data_resposta')
        }),
        ('Dados do Pet', {
            'fields': ('nome_pet', 'tipo_pet', 'sexo', 'idade', 'raca', 
                      'descricao', 'foto', 'preview_foto')
        }),
        ('Localização do Pet', {
            'fields': ('cidade', 'estado')
        }),
        ('Dados do Responsável', {
            'fields': ('usuario', 'nome_responsavel', 'email', 'telefone')
        }),
        ('Informações Adicionais', {
            'fields': ('motivo', 'castrado', 'vacinado')
        }),
        ('Observações da Administração', {
            'fields': ('observacoes_admin',)
        }),
    )
    
    def cidade_estado(self, obj):
        return f"{obj.cidade}/{obj.estado}"
    cidade_estado.short_description = 'Localização'
    
    def preview_foto(self, obj):
        if obj.foto:
            return format_html('<img src="{}" style="max-height: 200px; border-radius: 10px;"/>', obj.foto.url)
        return "Sem foto"
    preview_foto.short_description = 'Preview'
    
    actions = ['aprovar_promocoes', 'recusar_promocoes']
    
    def aprovar_promocoes(self, request, queryset):
        from django.utils import timezone
        updated = queryset.update(status='aprovada', data_resposta=timezone.now())
        self.message_user(request, f'{updated} promoção(ões) aprovada(s).')
    aprovar_promocoes.short_description = 'Aprovar promoções selecionadas'
    
    def recusar_promocoes(self, request, queryset):
        from django.utils import timezone
        updated = queryset.update(status='recusada', data_resposta=timezone.now())
        self.message_user(request, f'{updated} promoção(ões) recusada(s).')
    recusar_promocoes.short_description = 'Recusar promoções selecionadas'