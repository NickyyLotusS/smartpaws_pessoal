from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .models import Pet, Parceiro, SolicitacaoAdocao, PromocaoAdocao
from .forms import SolicitacaoAdocaoForm, PromocaoAdocaoForm


def adocao(request):
    """Página principal de adoção"""
    # Buscar parceiros ativos
    parceiros = Parceiro.objects.filter(ativo=True)
    
    # Buscar pets disponíveis
    pets = Pet.objects.filter(status='disponivel')
    
    # Filtros
    ordenacao = request.GET.get('ordem', '-data_cadastro')
    
    if ordenacao == 'recentes':
        pets = pets.order_by('-data_cadastro')
    elif ordenacao == 'antigos':
        pets = pets.order_by('data_cadastro')
    elif ordenacao == 'mais_vistos':
        pets = pets.order_by('-visualizacoes')
    elif ordenacao == 'menos_vistos':
        pets = pets.order_by('visualizacoes')
    
    # Filtro por tipo, sexo, cidade
    tipo = request.GET.get('tipo')
    if tipo:
        pets = pets.filter(tipo=tipo)
    
    sexo = request.GET.get('sexo')
    if sexo:
        pets = pets.filter(sexo=sexo)
    
    cidade = request.GET.get('cidade')
    if cidade:
        pets = pets.filter(cidade__icontains=cidade)
    
    context = {
        'parceiros': parceiros,
        'pets': pets,
        'ordenacao_atual': ordenacao,
    }
    
    return render(request, 'pets/adocao.html', context)


def detalhe_pet(request, pet_id):
    """Detalhes de um pet específico"""
    pet = get_object_or_404(Pet, id=pet_id, status='disponivel')
    
    # Incrementar visualizações
    pet.incrementar_visualizacao()
    
    # Buscar pets similares
    pets_similares = Pet.objects.filter(
        status='disponivel',
        tipo=pet.tipo
    ).exclude(id=pet.id)[:4]
    
    context = {
        'pet': pet,
        'pets_similares': pets_similares,
    }
    
    return render(request, 'pets/detalhe_pet.html', context)


@login_required
def solicitar_adocao(request, pet_id):
    """Formulário de solicitação de adoção"""
    pet = get_object_or_404(Pet, id=pet_id, status='disponivel')
    
    # Verificar se já existe solicitação pendente do usuário para este pet
    solicitacao_existente = SolicitacaoAdocao.objects.filter(
        pet=pet,
        usuario=request.user,
        status='pendente'
    ).exists()
    
    if solicitacao_existente:
        messages.warning(request, 'Você já possui uma solicitação pendente para este pet.')
        return redirect('detalhe_pet', pet_id=pet.id)
    
    if request.method == 'POST':
        form = SolicitacaoAdocaoForm(request.POST)
        if form.is_valid():
            solicitacao = form.save(commit=False)
            solicitacao.pet = pet
            solicitacao.usuario = request.user
            solicitacao.save()
            
            messages.success(request, 'Solicitação de adoção enviada com sucesso! Entraremos em contato em breve.')
            return redirect('minhas_solicitacoes')
    else:
        # Preencher dados iniciais com informações do usuário
        initial_data = {
            'nome_completo': request.user.get_full_name(),
            'email': request.user.email,
        }
        form = SolicitacaoAdocaoForm(initial=initial_data)
    
    context = {
        'form': form,
        'pet': pet,
    }
    
    return render(request, 'pets/solicitar_adocao.html', context)


@login_required
def minhas_solicitacoes(request):
    """Lista de solicitações de adoção do usuário"""
    solicitacoes = SolicitacaoAdocao.objects.filter(usuario=request.user)
    
    context = {
        'solicitacoes': solicitacoes,
    }
    
    return render(request, 'pets/minhas_solicitacoes.html', context)


@login_required
def promover_adocao(request):
    """Formulário para promover um pet para adoção"""
    if request.method == 'POST':
        form = PromocaoAdocaoForm(request.POST, request.FILES)
        if form.is_valid():
            promocao = form.save(commit=False)
            promocao.usuario = request.user
            promocao.save()
            
            messages.success(request, 'Solicitação enviada com sucesso! Analisaremos e entraremos em contato.')
            return redirect('minhas_promocoes')
    else:
        # Preencher dados iniciais
        initial_data = {
            'nome_responsavel': request.user.get_full_name(),
            'email': request.user.email,
        }
        form = PromocaoAdocaoForm(initial=initial_data)
    
    context = {
        'form': form,
    }
    
    return render(request, 'pets/promover_adocao.html', context)


@login_required
def minhas_promocoes(request):
    """Lista de promoções de adoção do usuário"""
    promocoes = PromocaoAdocao.objects.filter(usuario=request.user)
    
    context = {
        'promocoes': promocoes,
    }
    
    return render(request, 'pets/minhas_promocoes.html', context)


def buscar_pets(request):
    """Busca de pets com filtros"""
    query = request.GET.get('q', '')
    
    pets = Pet.objects.filter(status='disponivel')
    
    if query:
        pets = pets.filter(
            Q(nome__icontains=query) |
            Q(cidade__icontains=query) |
            Q(raca__icontains=query) |
            Q(descricao__icontains=query)
        )
    
    context = {
        'pets': pets,
        'query': query,
    }
    
    return render(request, 'pets/buscar_pets.html', context)