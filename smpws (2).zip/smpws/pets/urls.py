from django.urls import path
from . import views

urlpatterns = [
    # Página principal de adoção
    path('', views.adocao, name='adocao'),
    
    # Detalhes e solicitação
    path('pet/<int:pet_id>/', views.detalhe_pet, name='detalhe_pet'),
    path('pet/<int:pet_id>/solicitar/', views.solicitar_adocao, name='solicitar_adocao'),
    


    # Minhas solicitações
    path('minhas-solicitacoes/', views.minhas_solicitacoes, name='minhas_solicitacoes'),
    
    # Promover adoção
    path('promover/', views.promover_adocao, name='promover_adocao'),
    path('minhas-promocoes/', views.minhas_promocoes, name='minhas_promocoes'),
    
    # Busca
    path('buscar/', views.buscar_pets, name='buscar_pets'),
]