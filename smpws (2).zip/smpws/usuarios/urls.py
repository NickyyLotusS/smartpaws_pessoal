from django.urls import path, include
from rest_framework_simplejwt.views import TokenRefreshView, TokenVerifyView
from . import views, api_views

app_name = 'usuarios'

# URLs
urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('registro/', views.registro_view, name='registro'),
    path('perfil/', views.perfil_view, name='perfil'),
    path('enderecos/', views.enderecos_view, name='enderecos'),
]

# URLs da API
api_patterns = [
    # autenticação
    path('auth/registro/', api_views.RegistroAPIView.as_view(), name='api_registro'),
    path('auth/login/', api_views.CustomTokenObtainPairView.as_view(), name='api_login'),
    path('auth/refresh/', TokenRefreshView.as_view(), name='api_token_refresh'),
    path('auth/verify/', TokenVerifyView.as_view(), name='api_token_verify'),
    
    # Verificação e reset da senha
    path('verificar-email/', api_views.verificar_email, name='api_verificar_email'),
    path('reset-senha/request/', api_views.reset_senha_request, name='api_reset_senha_request'),
    path('reset-senha/confirm/', api_views.reset_senha_confirm, name='api_reset_senha_confirm'),
    
    # Perfil
    path('perfil/', api_views.PerfilAPIView.as_view(), name='api_perfil'),
    path('alterar-senha/', api_views.AlterarSenhaAPIView.as_view(), name='api_alterar_senha'),
    path('stats/', api_views.user_stats, name='api_user_stats'),
    
    # Foto
    path('foto-perfil/', api_views.upload_foto_perfil, name='api_upload_foto'),
    path('foto-perfil/remover/', api_views.remover_foto_perfil, name='api_remover_foto'),
    
    # Endereço
    path('enderecos/', api_views.EnderecoListCreateAPIView.as_view(), name='api_enderecos'),
    path('enderecos/<int:pk>/', api_views.EnderecoDetailAPIView.as_view(), name='api_endereco_detail'),
]

urlpatterns += [path('api/', include(api_patterns))]