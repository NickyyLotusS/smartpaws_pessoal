from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError
from PIL import Image
import re

def validar_cpf(cpf):

    # remove caracteres especiais
    cpf_numeros = re.sub(r'[^0-9]', '', str(cpf))
    
    # verificação 
    if len(cpf_numeros) != 11:
        raise ValidationError("CPF deve ter 11 dígitos")
    
    if cpf_numeros == cpf_numeros[0] * 11:
        raise ValidationError("CPF inválido")
    
    
    soma = sum(int(cpf_numeros[i]) * (10 - i) for i in range(9))
    primeiro_dv = 11 - (soma % 11)
    if primeiro_dv >= 10:
        primeiro_dv = 0
    

    soma = sum(int(cpf_numeros[i]) * (11 - i) for i in range(10))
    segundo_dv = 11 - (soma % 11)
    if segundo_dv >= 10:
        segundo_dv = 0

    if primeiro_dv != int(cpf_numeros[9]) or segundo_dv != int(cpf_numeros[10]):
        raise ValidationError("CPF inválido")
    
    return cpf

class Usuario(AbstractUser):

    
    # email para login
    email = models.EmailField(
        unique=True,
        verbose_name="Email",
        help_text="Email será usado para fazer login"
    )
    
    # CPF contendo a validação que foi definida anteriormente
    cpf = models.CharField(
        max_length=14,
        unique=True,
        blank=True,
        null=True,
        validators=[validar_cpf],
        verbose_name="CPF",
        help_text="Formato: 000.000.000-00"
    )
    
    # Telefone 
    telefone_regex = RegexValidator(
        regex=r'^\(\d{2}\)\s\d{4,5}-\d{4}$',
        message="Telefone: (61) 91234-5678 ou (61) 1234-5678"
    )
    telefone = models.CharField(
        max_length=15,
        validators=[telefone_regex],
        blank=True,
        verbose_name="Telefone"
    )
    
    # Dados pessoais
    data_nascimento = models.DateField(
        null=True,
        blank=True,
        verbose_name="Data de Nascimento"
    )
    
    SEXO_CHOICES = [
        ('M', 'Masculino'),
        ('F', 'Feminino'),
        
        ('O', 'Outro'),
        ('N', 'Prefiro não informar')
    ]
    sexo = models.CharField(
        max_length=1,
        choices=SEXO_CHOICES,
        blank=True,
        verbose_name="Sexo"
    )
    
    
    foto_perfil = models.ImageField(
        upload_to='usuarios/fotos/%Y/%m/',
        blank=True,
        null=True,
        verbose_name="Foto do Perfil"
    )
    
    # Status da conta
    is_verified = models.BooleanField(
        default=False,
        verbose_name="Email Verificado"
    )
    
    aceita_marketing = models.BooleanField(
        default=False,
        verbose_name="Aceita receber emails promocionais"
    )
    
    # Tokens para verificação
    verification_token = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )
    
    reset_password_token = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )
    
    # Metadata
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Criado em"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Atualizado em"
    )
    last_login_ip = models.GenericIPAddressField(
        null=True,
        blank=True,
        verbose_name="Último IP de login"
    )
    
    # Configurações do modelo
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name']
    
    class Meta:
        verbose_name = "Usuário"
        verbose_name_plural = "Usuários"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['cpf']),
            models.Index(fields=['is_active', 'is_verified']),
        ]
    
    def __str__(self):
        return self.email
    
    @property
    def nome_completo(self):

        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}".strip()
        elif self.first_name:
            return self.first_name
        return self.username
    
    @property
    def idade(self):
 
        if self.data_nascimento:
            from datetime import date
            today = date.today()
            return today.year - self.data_nascimento.year - (
                (today.month, today.day) < (self.data_nascimento.month, self.data_nascimento.day)
            )
        return None
    
    @property
    def cpf_formatado(self):

        if self.cpf:
            cpf_numeros = re.sub(r'[^0-9]', '', self.cpf)
            if len(cpf_numeros) == 11:
                return f"{cpf_numeros[:3]}.{cpf_numeros[3:6]}.{cpf_numeros[6:9]}-{cpf_numeros[9:]}"
        return self.cpf
    
    def clean(self):

        super().clean()
        
        # Validação da idade mínima
        if self.data_nascimento and self.idade and self.idade < 13:
            raise ValidationError("Usuário deve ter pelo menos 13 anos")
    
    def save(self, *args, **kwargs):

        # Formatar CPF
        if self.cpf:
            cpf_numeros = re.sub(r'[^0-9]', '', self.cpf)
            if len(cpf_numeros) == 11:
                self.cpf = f"{cpf_numeros[:3]}.{cpf_numeros[3:6]}.{cpf_numeros[6:9]}-{cpf_numeros[9:]}"
        
        # Email sempre minúsculo
        if self.email:
            self.email = self.email.lower()
        
        super().save(*args, **kwargs)
        
        # Redimensionar foto do perfil
        if self.foto_perfil:
            try:
                img = Image.open(self.foto_perfil.path)
                if img.height > 400 or img.width > 400:
                    output_size = (400, 400)
                    img.thumbnail(output_size, Image.Resampling.LANCZOS)
                    img.save(self.foto_perfil.path, optimize=True, quality=85)
            except Exception:
                pass  # Ignora erros de processamento de imagem
    
    def generate_verification_token(self):
    
        import uuid
        self.verification_token = str(uuid.uuid4())
        self.save(update_fields=['verification_token'])
        return self.verification_token
    
    def verify_email(self):

        self.is_verified = True
        self.verification_token = None
        self.save(update_fields=['is_verified', 'verification_token'])


class Endereco(models.Model):

    
    usuario = models.ForeignKey(
        Usuario,
        on_delete=models.CASCADE,
        related_name='enderecos',
        verbose_name="Usuário"
    )
    

    cep_regex = RegexValidator(
        regex=r'^\d{5}-?\d{3}$',
        message="CEP deve estar no formato: 00000-000"
    )
    
    nome = models.CharField(
        max_length=100,
        help_text="Ex: Casa, Trabalho, Apartamento",
        verbose_name="Nome do Endereço"
    )
    
    cep = models.CharField(
        max_length=9,
        validators=[cep_regex],
        verbose_name="CEP"
    )
    
    logadouro = models.CharField(
        max_length=200,
        verbose_name="Logadouro"
    )
    
    numero = models.CharField(
        max_length=10,
        verbose_name="Número"
    )
    
    complemento = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Complemento"
    )
    
    bairro = models.CharField(
        max_length=100,
        verbose_name="Bairro"
    )
    
    cidade = models.CharField(
        max_length=100,
        verbose_name="Cidade"
    )
    

    ESTADOS_CHOICES = [
        ('AC', 'Acre'), ('AL', 'Alagoas'), ('AP', 'Amapá'), ('AM', 'Amazonas'),
        ('BA', 'Bahia'), ('CE', 'Ceará'), ('DF', 'Distrito Federal'), ('ES', 'Espírito Santo'),
        ('GO', 'Goiás'), ('MA', 'Maranhão'), ('MT', 'Mato Grosso'), ('MS', 'Mato Grosso do Sul'),
        ('MG', 'Minas Gerais'), ('PA', 'Pará'), ('PB', 'Paraíba'), ('PR', 'Paraná'),
        ('PE', 'Pernambuco'), ('PI', 'Piauí'), ('RJ', 'Rio de Janeiro'), ('RN', 'Rio Grande do Norte'),
        ('RS', 'Rio Grande do Sul'), ('RO', 'Rondônia'), ('RR', 'Roraima'), ('SC', 'Santa Catarina'),
        ('SP', 'São Paulo'), ('SE', 'Sergipe'), ('TO', 'Tocantins')
    ]
    
    estado = models.CharField(
        max_length=2,
        choices=ESTADOS_CHOICES,
        verbose_name="Estado"
    )
    
    is_principal = models.BooleanField(
        default=False,
        verbose_name="Endereço Principal"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Endereço"
        verbose_name_plural = "Endereços"
        ordering = ['-is_principal', '-created_at']
        unique_together = [['usuario', 'nome']]  
    
    def __str__(self):
        return f"{self.nome} - {self.usuario.email}"
    
    @property
    def endereco_completo(self):

        endereco = f"{self.logradouro}, {self.numero}"
        if self.complemento:
            endereco += f", {self.complemento}"
        endereco += f" - {self.bairro}, {self.cidade}/{self.estado} - CEP: {self.cep}"
        return endereco
    
    def save(self, *args, **kwargs):

        if self.cep:
            cep_numeros = re.sub(r'[^0-9]', '', self.cep)
            if len(cep_numeros) == 8:
                self.cep = f"{cep_numeros[:5]}-{cep_numeros[5:]}"
        

        if self.is_principal:
            Endereco.objects.filter(
                usuario=self.usuario,
                is_principal=True
            ).exclude(pk=self.pk).update(is_principal=False)
        
        super().save(*args, **kwargs)