from rest_framework import status, generics, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth import login
from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.utils import timezone
from django.shortcuts import get_object_or_404
import uuid

from .models import Usuario, Endereco
from .serializers import (
    RegistroSerializer,
    UsuarioCompletoSerializer,
    UsuarioBasicoSerializer,
    LoginSerializer,
    PerfilUpdateSerializer,
    AlterarSenhaSerializer,
    EnderecoSerializer,
    VerificacaoEmailSerializer,
    ResetSenhaRequestSerializer,
    ResetSenhaConfirmSerializer
)


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):

    
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        

        token['username'] = user.username
        token['email'] = user.email
        token['is_verified'] = user.is_verified
        
        return token
    
    def validate(self, attrs):
        data = super().validate(attrs)
        
        
        user_data = UsuarioBasicoSerializer(self.user).data
        data['user'] = user_data

        self.user.last_login = timezone.now()
        self.user.save(update_fields=['last_login'])
        
        return data


class CustomTokenObtainPairView(TokenObtainPairView):

    serializer_class = CustomTokenObtainPairSerializer


class RegistroAPIView(generics.CreateAPIView):
   
    queryset = Usuario.objects.all()
    serializer_class = RegistroSerializer
    permission_classes = [permissions.AllowAny]
    
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
   
        usuario = serializer.save()
     
        refresh = RefreshToken.for_user(usuario)
        access_token = refresh.access_token
        
        
        self.enviar_email_verificacao(usuario, request)
        

        usuario_data = UsuarioBasicoSerializer(usuario).data
        
        return Response({
            'message': 'Usuário registrado com sucesso! Verifique seu email para ativação da conta.',
            'user': usuario_data,
            'tokens': {
                'refresh': str(refresh),
                'access': str(access_token),
            }
        }, status=status.HTTP_201_CREATED)
    
    def enviar_email_verificacao(self, usuario, request):
       
        try:
            verification_link = request.build_absolute_uri(
                f'/api/usuarios/verificar-email/?token={usuario.verification_token}'
            )
            
            context = {
                'usuario': usuario,
                'verification_link': verification_link,
                'site_name': 'SmartPaws'
            }
            
            subject = 'Verifique seu email - SmartPaws'
            html_message = render_to_string('usuarios/email_verificacao.html', context)
            
            send_mail(
                subject,
                '',  
                settings.EMAIL_HOST_USER,
                [usuario.email],
                html_message=html_message,
                fail_silently=True
            )
        except Exception as e:
            print(f"Erro ao enviar email de verificação: {e}")


@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def verificar_email(request):

    serializer = VerificacaoEmailSerializer(data=request.data)
    
    if serializer.is_valid():
        usuario = serializer.save()
        
        return Response({
            'message': 'Email verificado com sucesso!',
            'user': UsuarioBasicoSerializer(usuario).data
        })
    
    return Response({
        'message': 'Token inválido.',
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


class PerfilAPIView(generics.RetrieveUpdateAPIView):

    
    permission_classes = [permissions.IsAuthenticated]
    
    def get_object(self):
        return self.request.user
    
    def get_serializer_class(self):
        if self.request.method == 'GET':
            return UsuarioCompletoSerializer
        return PerfilUpdateSerializer
    
    def retrieve(self, request, *args, **kwargs):

        instance = self.get_object()
        serializer = UsuarioCompletoSerializer(instance)
        return Response({
            'user': serializer.data
        })
    
    def update(self, request, *args, **kwargs):

        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        
        usuario = serializer.save()
        user_data = UsuarioCompletoSerializer(usuario).data
        
        return Response({
            'message': 'Perfil atualizado com sucesso!',
            'user': user_data
        })


class AlterarSenhaAPIView(generics.GenericAPIView):

    
    serializer_class = AlterarSenhaSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        serializer = self.get_serializer(
            data=request.data,
            context={'request': request}
        )
        
        if serializer.is_valid():
            serializer.save()
            
            return Response({
                'message': 'Senha alterada com sucesso!'
            })
        
        return Response({
            'message': 'Erro ao alterar senha.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def reset_senha_request(request):

    serializer = ResetSenhaRequestSerializer(data=request.data)
    
    if serializer.is_valid():
        email = serializer.validated_data['email']
        usuario = get_object_or_404(Usuario, email=email, is_active=True)

        usuario.reset_password_token = str(uuid.uuid4())
        usuario.save(update_fields=['reset_password_token'])
        

        try:
            reset_link = request.build_absolute_uri(
                f'/reset-senha/?token={usuario.reset_password_token}'
            )
            
            context = {
                'usuario': usuario,
                'reset_link': reset_link,
                'site_name': 'smartpaws'
            }
            
            subject = 'Reset de senha - SmartPaws'
            html_message = render_to_string('usuarios/email_reset_senha.html', context)
            
            send_mail(
                subject,
                '',
                settings.EMAIL_HOST_USER,
                [usuario.email],
                html_message=html_message,
                fail_silently=False
            )
        except Exception as e:
            return Response({
                'message': 'Erro ao enviar email.'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        return Response({
            'message': 'Email de reset enviado com sucesso!'
        })
    
    return Response({
        'message': 'Email inválido.',
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def reset_senha_confirm(request):

    serializer = ResetSenhaConfirmSerializer(data=request.data)
    
    if serializer.is_valid():
        usuario = serializer.save()
        
        return Response({
            'message': 'Senha alterada com sucesso!'
        })
    
    return Response({
        'message': 'Dados inválidos.',
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


class EnderecoListCreateAPIView(generics.ListCreateAPIView):

    
    serializer_class = EnderecoSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return Endereco.objects.filter(usuario=self.request.user)
    
    def perform_create(self, serializer):
        serializer.save(usuario=self.request.user)
    
    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        
        if response.status_code == 201:
            response.data = {
                'message': 'Endereço adicionado com sucesso!',
                'endereco': response.data
            }
        
        return response


class EnderecoDetailAPIView(generics.RetrieveUpdateDestroyAPIView):

    
    serializer_class = EnderecoSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return Endereco.objects.filter(usuario=self.request.user)
    
    def update(self, request, *args, **kwargs):
        response = super().update(request, *args, **kwargs)
        
        if response.status_code == 200:
            response.data = {
                'message': 'Endereço atualizado com sucesso!',
                'endereco': response.data
            }
        
        return response
    
    def destroy(self, request, *args, **kwargs):
        super().destroy(request, *args, **kwargs)
        
        return Response({
            'message': 'Endereço removido com sucesso!'
        })


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def upload_foto_perfil(request):

    
    if 'foto' not in request.FILES:
        return Response({
            'message': 'Nenhuma foto foi enviada.'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    foto = request.FILES['foto']
    
    # Validações
    if foto.size > 5 * 1024 * 1024:  
        return Response({
            'message': 'Arquivo muito grande. Máximo 5MB.'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    if not foto.content_type.startswith('image/'):
        return Response({
            'message': 'Arquivo deve ser uma imagem.'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Salvar foto
    user = request.user
    user.foto_perfil = foto
    user.save(update_fields=['foto_perfil'])
    
    return Response({
        'message': 'Foto do perfil atualizada com sucesso!',
        'foto_url': user.foto_perfil.url if user.foto_perfil else None
    })


@api_view(['DELETE'])
@permission_classes([permissions.IsAuthenticated])
def remover_foto_perfil(request):
    
    
    user = request.user
    
    if user.foto_perfil:
        user.foto_perfil.delete()
        user.save()
        
        return Response({
            'message': 'Foto do perfil removida com sucesso!'
        })
    
    return Response({
        'message': 'Usuário não possui foto do perfil.'
    }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def user_stats(request):

    
    user = request.user

    from produtos.models import Avaliacao
    
    stats = {
        'total_enderecos': user.enderecos.count(),
        'total_avaliacoes': Avaliacao.objects.filter(usuario=user).count(),
        # 'itens_carrinho': ItemCarrinho.objects.filter(carrinho__usuario=user).count(),
        'membro_desde': user.created_at.strftime('%d/%m/%Y'),
        'ultimo_login': user.last_login.strftime('%d/%m/%Y %H:%M') if user.last_login else None,
    }
    
    return Response({
        'stats': stats
    })
