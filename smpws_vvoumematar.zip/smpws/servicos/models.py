# ==========================================
# apps/servicos/models.py
# ==========================================

from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from django.core.exceptions import ValidationError
from django.urls import reverse
from django.utils import timezone
from decimal import Decimal
from datetime import datetime, time, timedelta
import uuid

User = get_user_model()


class TipoServico(models.Model):
    """Tipos de serviços disponíveis"""
    
    SERVICOS_CHOICES = [
        ('creche_pet', 'Creche Pet'),
        ('pet_sitter', 'Pet Sitter'),
        ('dog_walker', 'Dog Walker'),
        ('banho', 'Banho'),
        ('tosa', 'Tosa'),
        ('banho_tosa', 'Banho e Tosa'),
        ('veterinario', 'Veterinário'),
        ('adestramento', 'Adestramento'),
        ('transporte', 'Transporte Pet'),
        ('hospedagem', 'Hospedagem'),
    ]
    
    nome = models.CharField(
        max_length=50,
        choices=SERVICOS_CHOICES,
        unique=True,
        verbose_name="Tipo de Serviço"
    )
    
    titulo = models.CharField(
        max_length=100,
        verbose_name="Título Exibido"
    )
    
    descricao = models.TextField(
        verbose_name="Descrição do Serviço"
    )
    
    icone = models.CharField(
        max_length=50,
        default='fas fa-paw',
        help_text='Classe do ícone FontAwesome',
        verbose_name="Ícone"
    )
    
    preco_base = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))],
        help_text="Preço base sugerido",
        verbose_name="Preço Base (R$)"
    )
    
    duracao_padrao = models.PositiveIntegerField(
        help_text="Duração padrão em minutos",
        verbose_name="Duração Padrão (min)"
    )
    
    ativo = models.BooleanField(
        default=True,
        verbose_name="Ativo"
    )
    
    ordem = models.PositiveIntegerField(
        default=0,
        verbose_name="Ordem de Exibição"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Tipo de Serviço"
        verbose_name_plural = "Tipos de Serviços"
        ordering = ['ordem', 'titulo']
    
    def __str__(self):
        return self.titulo
    
    @property
    def total_profissionais(self):
        """Total de profissionais ativos oferecendo este serviço"""
        return self.servicos.filter(
            profissional__ativo=True,
            ativo=True
        ).count()


class Profissional(models.Model):
    """Profissionais que oferecem serviços"""
    
    TIPO_CHOICES = [
        ('pessoa_fisica', 'Pessoa Física'),
        ('pessoa_juridica', 'Pessoa Jurídica/Estabelecimento'),
    ]
    
    STATUS_CHOICES = [
        ('pendente', 'Pendente Aprovação'),
        ('aprovado', 'Aprovado'),
        ('suspenso', 'Suspenso'),
        ('rejeitado', 'Rejeitado'),
    ]
    
    # Dados básicos
    usuario = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profissional',
        verbose_name="Usuário"
    )
    
    tipo = models.CharField(
        max_length=20,
        choices=TIPO_CHOICES,
        default='pessoa_fisica',
        verbose_name="Tipo"
    )
    
    nome_profissional = models.CharField(
        max_length=200,
        verbose_name="Nome Profissional/Estabelecimento"
    )
    
    slug = models.SlugField(
        max_length=255,
        unique=True,
        blank=True,
        verbose_name="URL Amigável"
    )
    
    # Documentos
    cpf_cnpj = models.CharField(
        max_length=18,
        help_text="CPF para pessoa física ou CNPJ para jurídica",
        verbose_name="CPF/CNPJ"
    )
    
    documento_foto = models.ImageField(
        upload_to='profissionais/documentos/%Y/%m/',
        help_text="Foto do documento (RG, CNH, etc)",
        verbose_name="Documento com Foto"
    )
    
    # Registros profissionais (opcional)
    registro_profissional = models.CharField(
        max_length=50,
        blank=True,
        help_text="CRMV, certificados, etc",
        verbose_name="Registro Profissional"
    )
    
    # Contato
    telefone_principal = models.CharField(
        max_length=15,
        validators=[RegexValidator(
            regex=r'^\(\d{2}\)\s\d{4,5}-\d{4}$',
            message="Formato: (11) 91234-5678"
        )],
        verbose_name="Telefone Principal"
    )
    
    telefone_secundario = models.CharField(
        max_length=15,
        blank=True,
        validators=[RegexValidator(
            regex=r'^\(\d{2}\)\s\d{4,5}-\d{4}$',
            message="Formato: (11) 91234-5678"
        )],
        verbose_name="Telefone Secundário"
    )
    
    whatsapp = models.CharField(
        max_length=15,
        blank=True,
        validators=[RegexValidator(
            regex=r'^\(\d{2}\)\s\d{4,5}-\d{4}$',
            message="Formato: (11) 91234-5678"
        )],
        verbose_name="WhatsApp"
    )
    
    # Localização
    endereco_completo = models.TextField(
        verbose_name="Endereço Completo"
    )
    
    cidade = models.CharField(
        max_length=100,
        verbose_name="Cidade"
    )
    
    estado = models.CharField(
        max_length=2,
        choices=[
            ('AC', 'Acre'), ('AL', 'Alagoas'), ('AP', 'Amapá'), ('AM', 'Amazonas'),
            ('BA', 'Bahia'), ('CE', 'Ceará'), ('DF', 'Distrito Federal'), ('ES', 'Espírito Santo'),
            ('GO', 'Goiás'), ('MA', 'Maranhão'), ('MT', 'Mato Grosso'), ('MS', 'Mato Grosso do Sul'),
            ('MG', 'Minas Gerais'), ('PA', 'Pará'), ('PB', 'Paraíba'), ('PR', 'Paraná'),
            ('PE', 'Pernambuco'), ('PI', 'Piauí'), ('RJ', 'Rio de Janeiro'), ('RN', 'Rio Grande do Norte'),
            ('RS', 'Rio Grande do Sul'), ('RO', 'Rondônia'), ('RR', 'Roraima'), ('SC', 'Santa Catarina'),
            ('SP', 'São Paulo'), ('SE', 'Sergipe'), ('TO', 'Tocantins')
        ],
        verbose_name="Estado"
    )
    
    cep = models.CharField(
        max_length=9,
        validators=[RegexValidator(
            regex=r'^\d{5}-?\d{3}$',
            message="CEP: 00000-000"
        )],
        verbose_name="CEP"
    )
    
    # Área de atendimento (em km)
    raio_atendimento = models.PositiveIntegerField(
        default=10,
        help_text="Raio de atendimento em quilômetros",
        verbose_name="Raio de Atendimento (km)"
    )
    
    # Perfil profissional
    bio = models.TextField(
        max_length=1000,
        help_text="Apresentação profissional (máx 1000 caracteres)",
        verbose_name="Biografia/Apresentação"
    )
    
    experiencia_anos = models.PositiveIntegerField(
        help_text="Anos de experiência na área",
        verbose_name="Anos de Experiência"
    )
    
    foto_perfil = models.ImageField(
        upload_to='profissionais/fotos/%Y/%m/',
        help_text="Foto profissional",
        verbose_name="Foto do Perfil"
    )
    
    # Configurações de trabalho
    aceita_emergencia = models.BooleanField(
        default=False,
        verbose_name="Aceita Emergências"
    )
    
    trabalha_feriados = models.BooleanField(
        default=False,
        verbose_name="Trabalha em Feriados"
    )
    
    trabalha_finais_semana = models.BooleanField(
        default=True,
        verbose_name="Trabalha Finais de Semana"
    )
    
    # Status e aprovação
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pendente',
        verbose_name="Status"
    )
    
    ativo = models.BooleanField(
        default=True,
        verbose_name="Ativo"
    )
    
    verificado = models.BooleanField(
        default=False,
        verbose_name="Verificado"
    )
    
    # Avaliações
    nota_media = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Nota Média"
    )
    
    total_avaliacoes = models.PositiveIntegerField(
        default=0,
        verbose_name="Total de Avaliações"
    )
    
    total_agendamentos = models.PositiveIntegerField(
        default=0,
        verbose_name="Total de Agendamentos"
    )
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    aprovado_em = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = "Profissional"
        verbose_name_plural = "Profissionais"
        ordering = ['-nota_media', '-total_agendamentos']
    
    def __str__(self):
        return self.nome_profissional
    
    def save(self, *args, **kwargs):
        """Gerar slug automaticamente"""
        if not self.slug:
            from django.utils.text import slugify
            base_slug = slugify(self.nome_profissional)
            slug = base_slug
            contador = 1
            while Profissional.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{contador}"
                contador += 1
            self.slug = slug
        
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        return reverse('servicos:profissional_detalhe', kwargs={'slug': self.slug})
    
    @property
    def aprovado(self):
        return self.status == 'aprovado'
    
    @property
    def pode_agendar(self):
        return self.ativo and self.aprovado
    
    def aprovar(self):
        """Aprova o profissional"""
        self.status = 'aprovado'
        self.aprovado_em = timezone.now()
        self.save()
    
    def suspender(self, motivo=None):
        """Suspende o profissional"""
        self.status = 'suspenso'
        self.save()
    
    def atualizar_estatisticas(self):
        """Atualiza estatísticas do profissional"""
        avaliacoes = self.avaliacoes.filter(aprovado=True)
        
        if avaliacoes.exists():
            self.nota_media = avaliacoes.aggregate(
                models.Avg('nota')
            )['nota__avg'] or Decimal('0.00')
            self.total_avaliacoes = avaliacoes.count()
        
        self.total_agendamentos = self.agendamentos.filter(
            status__in=['concluido', 'confirmado']
        ).count()
        
        self.save(update_fields=['nota_media', 'total_avaliacoes', 'total_agendamentos'])


class Servico(models.Model):
    """Serviços oferecidos por cada profissional"""
    
    profissional = models.ForeignKey(
        Profissional,
        on_delete=models.CASCADE,
        related_name='servicos',
        verbose_name="Profissional"
    )
    
    tipo_servico = models.ForeignKey(
        TipoServico,
        on_delete=models.CASCADE,
        related_name='servicos',
        verbose_name="Tipo de Serviço"
    )
    
    # Preço personalizado
    preco = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))],
        verbose_name="Preço (R$)"
    )
    
    # Duração personalizada
    duracao_minutos = models.PositiveIntegerField(
        verbose_name="Duração (minutos)"
    )
    
    # Descrição personalizada
    descricao = models.TextField(
        blank=True,
        help_text="Descrição específica deste profissional para o serviço",
        verbose_name="Descrição Personalizada"
    )
    
    # Configurações específicas
    preco_adicional_emergencia = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Taxa Adicional Emergência (R$)"
    )
    
    preco_adicional_feriado = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Taxa Adicional Feriado (R$)"
    )
    
    # Observações e requisitos
    observacoes = models.TextField(
        blank=True,
        help_text="Observações importantes sobre o serviço",
        verbose_name="Observações"
    )
    
    requisitos = models.TextField(
        blank=True,
        help_text="Requisitos necessários do pet/cliente",
        verbose_name="Requisitos"
    )
    
    ativo = models.BooleanField(
        default=True,
        verbose_name="Ativo"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Serviço"
        verbose_name_plural = "Serviços"
        unique_together = ['profissional', 'tipo_servico']
        ordering = ['tipo_servico__ordem', 'preco']
    
    def __str__(self):
        return f"{self.profissional.nome_profissional} - {self.tipo_servico.titulo}"
    
    @property
    def preco_final_emergencia(self):
        """Preço com taxa de emergência"""
        return self.preco + self.preco_adicional_emergencia
    
    @property
    def preco_final_feriado(self):
        """Preço com taxa de feriado"""
        return self.preco + self.preco_adicional_feriado


class DisponibilidadeProfissional(models.Model):
    """Disponibilidade semanal do profissional"""
    
    DIAS_SEMANA = [
        (0, 'Segunda-feira'),
        (1, 'Terça-feira'),
        (2, 'Quarta-feira'),
        (3, 'Quinta-feira'),
        (4, 'Sexta-feira'),
        (5, 'Sábado'),
        (6, 'Domingo'),
    ]
    
    profissional = models.ForeignKey(
        Profissional,
        on_delete=models.CASCADE,
        related_name='disponibilidades',
        verbose_name="Profissional"
    )
    
    dia_semana = models.IntegerField(
        choices=DIAS_SEMANA,
        verbose_name="Dia da Semana"
    )
    
    horario_inicio = models.TimeField(
        verbose_name="Horário de Início"
    )
    
    horario_fim = models.TimeField(
        verbose_name="Horário de Fim"
    )
    
    ativo = models.BooleanField(
        default=True,
        verbose_name="Ativo"
    )
    
    class Meta:
        verbose_name = "Disponibilidade"
        verbose_name_plural = "Disponibilidades"
        unique_together = ['profissional', 'dia_semana']
        ordering = ['dia_semana', 'horario_inicio']
    
    def __str__(self):
        return f"{self.profissional.nome_profissional} - {self.get_dia_semana_display()}: {self.horario_inicio} às {self.horario_fim}"


class Agendamento(models.Model):
    """Agendamentos de serviços"""
    
    STATUS_CHOICES = [
        ('pendente', 'Pendente Confirmação'),
        ('confirmado', 'Confirmado'),
        ('em_andamento', 'Em Andamento'),
        ('concluido', 'Concluído'),
        ('cancelado_cliente', 'Cancelado pelo Cliente'),
        ('cancelado_profissional', 'Cancelado pelo Profissional'),
        ('nao_compareceu', 'Cliente não Compareceu'),
    ]
    
    # Identificação
    codigo = models.CharField(
        max_length=20,
        unique=True,
        blank=True,
        verbose_name="Código do Agendamento"
    )
    
    # Relacionamentos
    cliente = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='agendamentos_cliente',
        verbose_name="Cliente"
    )
    
    profissional = models.ForeignKey(
        Profissional,
        on_delete=models.CASCADE,
        related_name='agendamentos',
        verbose_name="Profissional"
    )
    
    servico = models.ForeignKey(
        Servico,
        on_delete=models.CASCADE,
        related_name='agendamentos',
        verbose_name="Serviço"
    )
    
    # Data e hora
    data_agendamento = models.DateField(
        verbose_name="Data do Agendamento"
    )
    
    horario_inicio = models.TimeField(
        verbose_name="Horário de Início"
    )
    
    horario_fim = models.TimeField(
        verbose_name="Horário de Fim"
    )
    
    # Informações do pet
    nome_pet = models.CharField(
        max_length=100,
        verbose_name="Nome do Pet"
    )
    
    tipo_pet = models.CharField(
        max_length=50,
        choices=[
            ('cachorro', 'Cachorro'),
            ('gato', 'Gato'),
            ('passaro', 'Pássaro'),
            ('coelho', 'Coelho'),
            ('hamster', 'Hamster'),
            ('outro', 'Outro'),
        ],
        verbose_name="Tipo do Pet"
    )
    
    raca_pet = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Raça do Pet"
    )
    
    idade_pet = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="Idade do Pet"
    )
    
    peso_pet = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        verbose_name="Peso do Pet (kg)"
    )
    
    # Observações
    observacoes_cliente = models.TextField(
        blank=True,
        verbose_name="Observações do Cliente"
    )
    
    observacoes_profissional = models.TextField(
        blank=True,
        verbose_name="Observações do Profissional"
    )
    
    # Preços
    preco_servico = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        verbose_name="Preço do Serviço"
    )
    
    taxa_emergencia = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Taxa de Emergência"
    )
    
    taxa_feriado = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Taxa de Feriado"
    )
    
    desconto = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Desconto"
    )
    
    preco_total = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        verbose_name="Preço Total"
    )
    
    # Status e controle
    status = models.CharField(
        max_length=25,
        choices=STATUS_CHOICES,
        default='pendente',
        verbose_name="Status"
    )
    
    is_emergencia = models.BooleanField(
        default=False,
        verbose_name="É Emergência"
    )
    
    is_feriado = models.BooleanField(
        default=False,
        verbose_name="Em Feriado"
    )
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    confirmado_em = models.DateTimeField(null=True, blank=True)
    cancelado_em = models.DateTimeField(null=True, blank=True)
    concluido_em = models.DateTimeField(null=True, blank=True)
    
    # Controle de pagamento
    pago = models.BooleanField(
        default=False,
        verbose_name="Pago"
    )
    
    data_pagamento = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Data do Pagamento"
    )
    
    class Meta:
        verbose_name = "Agendamento"
        verbose_name_plural = "Agendamentos"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['data_agendamento', 'horario_inicio']),
            models.Index(fields=['profissional', 'data_agendamento']),
            models.Index(fields=['cliente', 'status']),
        ]
    
    def __str__(self):
        return f"{self.codigo} - {self.nome_pet} ({self.cliente.nome_completo})"
    
    def save(self, *args, **kwargs):
        """Gerar código automaticamente e calcular preço total"""
        if not self.codigo:
            self.codigo = f"AG{timezone.now().strftime('%Y%m%d')}{uuid.uuid4().hex[:6].upper()}"
        
        # Calcular preço total
        self.preco_total = (
            self.preco_servico + 
            self.taxa_emergencia + 
            self.taxa_feriado - 
            self.desconto
        )
        
        super().save(*args, **kwargs)
    
    def clean(self):
        """Validações do agendamento"""
        super().clean()
        
        # Validar data não é no passado
        if self.data_agendamento < timezone.now().date():
            raise ValidationError("Data do agendamento não pode ser no passado.")
        
        # Validar horário de fim depois do início
        if self.horario_fim <= self.horario_inicio:
            raise ValidationError("Horário de fim deve ser após o horário de início.")
    
    def confirmar(self):
        """Confirma o agendamento"""
        self.status = 'confirmado'
        self.confirmado_em = timezone.now()
        self.save()
    
    def cancelar(self, cancelado_por='cliente', motivo=None):
        """Cancela o agendamento"""
        if cancelado_por == 'cliente':
            self.status = 'cancelado_cliente'
        else:
            self.status = 'cancelado_profissional'
        
        self.cancelado_em = timezone.now()
        self.save()
    
    def concluir(self):
        """Marca agendamento como concluído"""
        self.status = 'concluido'
        self.concluido_em = timezone.now()
        self.save()
    
    @property
    def pode_cancelar(self):
        """Verifica se pode cancelar (até 24h antes)"""
        data_limite = datetime.combine(self.data_agendamento, self.horario_inicio) - timedelta(hours=24)
        return timezone.now() < timezone.make_aware(data_limite)
    
    @property
    def pode_avaliar(self):
        """Verifica se pode avaliar (serviço concluído)"""
        return self.status == 'concluido'


class AvaliacaoProfissional(models.Model):
    """Avaliações dos profissionais pelos clientes"""
    
    agendamento = models.OneToOneField(
        Agendamento,
        on_delete=models.CASCADE,
        related_name='avaliacao',
        verbose_name="Agendamento"
    )
    
    profissional = models.ForeignKey(
        Profissional,
        on_delete=models.CASCADE,
        related_name='avaliacoes',
        verbose_name="Profissional"
    )
    
    cliente = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='avaliacoes_feitas',
        verbose_name="Cliente"
    )
    
    # Avaliação geral
    nota = models.PositiveIntegerField(
        choices=[(i, f'{i} estrela{"s" if i > 1 else ""}') for i in range(1, 6)],
        verbose_name="Nota Geral"
    )
    
    # Avaliações específicas
    pontualidade = models.PositiveIntegerField(
        choices=[(i, f'{i} estrela{"s" if i > 1 else ""}') for i in range(1, 6)],
        verbose_name="Pontualidade"
    )
    
    qualidade_servico = models.PositiveIntegerField(
        choices=[(i, f'{i} estrela{"s" if i > 1 else ""}') for i in range(1, 6)],
        verbose_name="Qualidade do Serviço"
    )
    
    atendimento = models.PositiveIntegerField(
        choices=[(i, f'{i} estrela{"s" if i > 1 else ""}') for i in range(1, 6)],
        verbose_name="Atendimento"
    )
    
    # Comentários
    comentario = models.TextField(
        verbose_name="Comentário"
    )
    
    # Recomendações
    recomendaria = models.BooleanField(
        verbose_name="Recomendaria este Profissional"
    )
    
    # Controle
    aprovado = models.BooleanField(
        default=True,
        verbose_name="Avaliação Aprovada"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Avaliação de Profissional"
        verbose_name_plural = "Avaliações de Profissionais"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Avaliação de {self.cliente.nome_completo} para {self.profissional.nome_profissional} ({self.nota}★)"
    
    def save(self, *args, **kwargs):
        """Atualizar estatísticas do profissional após salvar"""
        super().save(*args, **kwargs)
        self.profissional.atualizar_estatisticas()


class FotoServico(models.Model):
    """Fotos dos serviços realizados"""
    
    agendamento = models.ForeignKey(
        Agendamento,
        on_delete=models.CASCADE,
        related_name='fotos',
        verbose_name="Agendamento"
    )
    
    foto = models.ImageField(
        upload_to='servicos/fotos/%Y/%m/',
        verbose_name="Foto"
    )
    
    descricao = models.CharField(
        max_length=255,
        blank=True,
        verbose_name="Descrição"
    )
    
    is_antes = models.BooleanField(
        default=False,
        verbose_name="Foto Antes do Serviço"
    )
    
    is_depois = models.BooleanField(
        default=False,
        verbose_name="Foto Depois do Serviço"
    )
    
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Foto do Serviço"
        verbose_name_plural = "Fotos dos Serviços"
        ordering = ['-uploaded_at']
    
    def __str__(self):
        return f"Foto - {self.agendamento.codigo}"
