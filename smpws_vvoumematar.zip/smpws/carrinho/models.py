from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator
from django.core.exceptions import ValidationError
from decimal import Decimal

User = get_user_model()


class Carrinho(models.Model):
    """Carrinho de compras do usuário"""
    
    usuario = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='carrinho',
        verbose_name="Usuário"
    )
    
    # Timestamps
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Criado em"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Atualizado em"
    )
    
    # Dados para carrinho abandonado
    session_key = models.CharField(
        max_length=40,
        blank=True,
        null=True,
        help_text="Para carrinho de usuários não logados"
    )
    
    class Meta:
        verbose_name = "Carrinho"
        verbose_name_plural = "Carrinhos"
        ordering = ['-updated_at']
    
    def __str__(self):
        return f"Carrinho de {self.usuario.email if self.usuario else 'Anônimo'}"
    
    @property
    def total_itens(self):
        """Total de itens no carrinho"""
        return sum(item.quantidade for item in self.itens.all())
    
    @property
    def subtotal(self):
        """Subtotal sem frete e descontos"""
        return sum(item.subtotal for item in self.itens.all())
    
    @property
    def total_desconto(self):
        """Total de desconto dos produtos"""
        return sum(item.desconto_total for item in self.itens.all())
    
    @property
    def peso_total(self):
        """Peso total do carrinho (para cálculo de frete)"""
        return sum(item.peso_total for item in self.itens.all())
    
    @property
    def total_preco(self):
        """Preço total do carrinho (subtotal - descontos)"""
        return self.subtotal
    
    @property
    def esta_vazio(self):
        """Verifica se carrinho está vazio"""
        return not self.itens.exists()
    
    def limpar(self):
        """Remove todos os itens do carrinho"""
        self.itens.all().delete()
        self.save()
    
    def adicionar_produto(self, produto, quantidade=1):
        """Adiciona produto ao carrinho ou atualiza quantidade"""
        from produtos.models import Produto
        
        # Validar produto
        if not isinstance(produto, Produto):
            raise ValidationError("Produto inválido")
        
        if not produto.ativo:
            raise ValidationError("Produto não está ativo")
        
        # Verificar estoque
        if produto.controlar_estoque and quantidade > produto.estoque:
            raise ValidationError(f"Apenas {produto.estoque} unidades disponíveis")
        
        # Obter ou criar item
        item, created = ItemCarrinho.objects.get_or_create(
            carrinho=self,
            produto=produto,
            defaults={
                'quantidade': quantidade,
                'preco_unitario': produto.preco_final
            }
        )
        
        if not created:
            # Atualizar quantidade existente
            nova_quantidade = item.quantidade + quantidade
            
            # Verificar estoque novamente
            if produto.controlar_estoque and nova_quantidade > produto.estoque:
                raise ValidationError(f"Apenas {produto.estoque} unidades disponíveis")
            
            item.quantidade = nova_quantidade
            item.preco_unitario = produto.preco_final  # Atualizar preço
            item.save()
        
        return item
    
    def remover_produto(self, produto):
        """Remove produto completamente do carrinho"""
        try:
            item = self.itens.get(produto=produto)
            item.delete()
            return True
        except ItemCarrinho.DoesNotExist:
            return False
    
    def atualizar_quantidade(self, produto, quantidade):
        """Atualiza quantidade de um produto"""
        try:
            item = self.itens.get(produto=produto)
            
            if quantidade <= 0:
                item.delete()
                return None
            
            # Verificar estoque
            if produto.controlar_estoque and quantidade > produto.estoque:
                raise ValidationError(f"Apenas {produto.estoque} unidades disponíveis")
            
            item.quantidade = quantidade
            item.preco_unitario = produto.preco_final  # Atualizar preço
            item.save()
            
            return item
            
        except ItemCarrinho.DoesNotExist:
            raise ValidationError("Item não encontrado no carrinho")


class ItemCarrinho(models.Model):
    """Item individual do carrinho"""
    
    carrinho = models.ForeignKey(
        Carrinho,
        on_delete=models.CASCADE,
        related_name='itens',
        verbose_name="Carrinho"
    )
    
    produto = models.ForeignKey(
        'produtos.Produto',
        on_delete=models.CASCADE,
        verbose_name="Produto"
    )
    
    quantidade = models.PositiveIntegerField(
        default=1,
        validators=[MinValueValidator(1)],
        verbose_name="Quantidade"
    )
    
    # Preço no momento da adição (para histórico)
    preco_unitario = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))],
        verbose_name="Preço Unitário"
    )
    
    # Observações específicas do item
    observacoes = models.TextField(
        blank=True,
        max_length=500,
        verbose_name="Observações"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Item do Carrinho"
        verbose_name_plural = "Itens do Carrinho"
        unique_together = ['carrinho', 'produto']
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.produto.nome} - Qtd: {self.quantidade}"
    
    @property
    def subtotal(self):
        """Subtotal do item (preço x quantidade)"""
        return self.preco_unitario * self.quantidade
    
    @property
    def preco_original(self):
        """Preço original do produto (sem promoção)"""
        return self.produto.preco
    
    @property
    def tem_desconto(self):
        """Verifica se item tem desconto"""
        return self.produto.tem_desconto
    
    @property
    def desconto_unitario(self):
        """Desconto por unidade"""
        if self.tem_desconto:
            return self.preco_original - self.preco_unitario
        return Decimal('0.00')
    
    @property
    def desconto_total(self):
        """Desconto total do item"""
        return self.desconto_unitario * self.quantidade
    
    @property
    def peso_total(self):
        """Peso total do item"""
        if self.produto.peso:
            return self.produto.peso * self.quantidade
        return Decimal('0.000')
    
    @property
    def disponivel(self):
        """Verifica se produto ainda está disponível"""
        return self.produto.disponivel
    
    @property
    def estoque_suficiente(self):
        """Verifica se há estoque suficiente"""
        if not self.produto.controlar_estoque:
            return True
        return self.produto.estoque >= self.quantidade
    
    def clean(self):
        """Validação do item"""
        super().clean()
        
        # Validar se produto está ativo
        if not self.produto.ativo:
            raise ValidationError("Produto não está mais ativo")
        
        # Validar estoque
        if self.produto.controlar_estoque and self.quantidade > self.produto.estoque:
            raise ValidationError(f"Apenas {self.produto.estoque} unidades disponíveis")
    
    def save(self, *args, **kwargs):
        """Salvar item com validações"""
        self.full_clean()
        
        # Atualizar preço se não foi definido
        if not self.preco_unitario:
            self.preco_unitario = self.produto.preco_final
        
        super().save(*args, **kwargs)
        
        # Atualizar timestamp do carrinho
        self.carrinho.save()


class CarrinhoAbandonado(models.Model):
    """Modelo para tracking de carrinho abandonado"""
    
    carrinho = models.OneToOneField(
        Carrinho,
        on_delete=models.CASCADE,
        related_name='abandonado'
    )
    
    email_enviado = models.BooleanField(
        default=False,
        verbose_name="Email de Recuperação Enviado"
    )
    
    data_abandono = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Data do Abandono"
    )
    
    data_email = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Data do Email"
    )
    
    recuperado = models.BooleanField(
        default=False,
        verbose_name="Carrinho Recuperado"
    )
    
    class Meta:
        verbose_name = "Carrinho Abandonado"
        verbose_name_plural = "Carrinhos Abandonados"
        ordering = ['-data_abandono']
    
    def __str__(self):
        return f"Carrinho abandonado - {self.carrinho.usuario.email}"
