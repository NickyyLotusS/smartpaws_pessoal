from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db import transaction
from django.core.exceptions import ValidationError as DjangoValidationError

from .models import Carrinho, ItemCarrinho
from .forms import (
    AdicionarCarrinhoForm,
    AtualizarQuantidadeForm,
    CupomDescontoForm,
    ObservacoesItemForm
)
from produtos.models import Produto


@login_required
def carrinho_view(request):
    """Visualiza o carrinho completo"""
    
    # Obter ou criar carrinho
    carrinho, created = Carrinho.objects.get_or_create(usuario=request.user)
    
    # Formulário para cupom
    cupom_form = CupomDescontoForm()
    
    # Preparar dados dos itens com formulários
    itens_com_forms = []
    for item in carrinho.itens.select_related('produto', 'produto__categoria', 'produto__marca').prefetch_related('produto__imagens'):
        # Formulário para atualizar quantidade
        quantidade_form = AtualizarQuantidadeForm(item=item, initial={'quantidade': item.quantidade})
        
        # Formulário para observações
        observacoes_form = ObservacoesItemForm(instance=item)
        
        itens_com_forms.append({
            'item': item,
            'quantidade_form': quantidade_form,
            'observacoes_form': observacoes_form,
            'imagem_principal': item.produto.imagens.filter(is_principal=True).first(),
        })
    
    context = {
        'carrinho': carrinho,
        'itens_com_forms': itens_com_forms,
        'cupom_form': cupom_form,
        'total_itens': carrinho.total_itens,
        'subtotal': carrinho.subtotal,
        'total_desconto': carrinho.total_desconto,
        'total_preco': carrinho.total_preco,
        'esta_vazio': carrinho.esta_vazio,
    }
    
    return render(request, 'carrinho/carrinho.html', context)


@login_required
@require_POST
def adicionar_ao_carrinho_view(request):
   
    
    form = AdicionarCarrinhoForm(data=request.POST)
    
    if form.is_valid():
        try:
            with transaction.atomic():
                # Dados do formulário
                produto_id = form.cleaned_data['produto_id']
                quantidade = form.cleaned_data['quantidade']
                observacoes = form.cleaned_data.get('observacoes', '')
                
                # Obter produto
                produto = get_object_or_404(Produto, id=produto_id, ativo=True)
                
                # Obter ou criar carrinho
                carrinho, created = Carrinho.objects.get_or_create(usuario=request.user)
                
                # Adicionar produto
                item = carrinho.adicionar_produto(produto, quantidade)
                
                # Adicionar observações
                if observacoes:
                    item.observacoes = observacoes
                    item.save()
                
                messages.success(request, f'{produto.nome} adicionado ao carrinho!')
                
        except DjangoValidationError as e:
            messages.error(request, str(e))
        except Exception as e:
            messages.error(request, 'Erro ao adicionar produto ao carrinho.')
    else:
        # Mostrar erros do formulário
        for field, errors in form.errors.items():
            for error in errors:
                messages.error(request, f'{field}: {error}')
    
    # Redirect para onde veio ou para o carrinho
    next_url = request.POST.get('next', request.META.get('HTTP_REFERER', '/carrinho/'))
    return redirect(next_url)


@login_required
@require_POST
def atualizar_quantidade_view(request, item_id):
    """Atualiza quantidade de um item"""
    
    # Obter item do usuário
    item = get_object_or_404(
        ItemCarrinho,
        id=item_id,
        carrinho__usuario=request.user
    )
    
    form = AtualizarQuantidadeForm(item=item, data=request.POST)
    
    if form.is_valid():
        quantidade = form.cleaned_data['quantidade']
        
        try:
            with transaction.atomic():
                if quantidade == 0:
                    # Remover item
                    produto_nome = item.produto.nome
                    item.delete()
                    messages.success(request, f'{produto_nome} removido do carrinho!')
                else:
                    # Atualizar quantidade
                    if item.produto.controlar_estoque and quantidade > item.produto.estoque:
                        messages.error(request, f'Apenas {item.produto.estoque} unidades disponíveis.')
                    else:
                        item.quantidade = quantidade
                        item.preco_unitario = item.produto.preco_final  
                        item.save()
                        messages.success(request, 'Quantidade atualizada!')
                        
        except Exception as e:
            messages.error(request, 'Erro ao atualizar quantidade.')
    else:
        messages.error(request, 'Quantidade inválida.')
    
    return redirect('carrinho:ver')


@login_required
@require_POST
def remover_do_carrinho_view(request, item_id):
    """Remove item do carrinho"""
    
    # Obter item do usuário
    item = get_object_or_404(
        ItemCarrinho,
        id=item_id,
        carrinho__usuario=request.user
    )
    
    produto_nome = item.produto.nome
    
    try:
        item.delete()
        messages.success(request, f'{produto_nome} removido do carrinho!')
    except Exception as e:
        messages.error(request, 'Erro ao remover produto.')
    
    return redirect('carrinho:ver')


@login_required
@require_POST
def limpar_carrinho_view(request):
    """Limpa todo o carrinho"""
    
    try:
        carrinho = get_object_or_404(Carrinho, usuario=request.user)
        total_itens = carrinho.total_itens
        carrinho.limpar()
        
        messages.success(request, f'{total_itens} item(ns) removido(s) do carrinho!')
        
    except Exception as e:
        messages.error(request, 'Erro ao limpar carrinho.')
    
    return redirect('carrinho:ver')


@login_required
@require_POST
def aplicar_cupom_view(request):
    """Aplica cupom de desconto"""
    
    form = CupomDescontoForm(data=request.POST)
    
    if form.is_valid():
        codigo = form.cleaned_data['codigo']
        
        # TODO: Implementar lógica do cupom
        # Por enquanto, simular que não foi encontrado
        messages.error(request, f'Cupom "{codigo}" não encontrado ou inválido.')
    else:
        messages.error(request, 'Código do cupom inválido.')
    
    return redirect('carrinho:ver')


@login_required
def atualizar_observacoes_view(request, item_id):
    """Atualiza observações de um item"""
    
    # Obter item do usuário
    item = get_object_or_404(
        ItemCarrinho,
        id=item_id,
        carrinho__usuario=request.user
    )
    
    if request.method == 'POST':
        form = ObservacoesItemForm(data=request.POST, instance=item)
        
        if form.is_valid():
            form.save()
            messages.success(request, 'Observações atualizadas!')
        else:
            messages.error(request, 'Erro ao atualizar observações.')
    
    return redirect('carrinho:ver')


# Views AJAX (para uso com JavaScript)
@login_required
def carrinho_contador_ajax(request):
    """Retorna contador do carrinho via AJAX"""
    
    try:
        carrinho = Carrinho.objects.get(usuario=request.user)
        return JsonResponse({
            'total_itens': carrinho.total_itens,
            'total_preco': float(carrinho.total_preco),
            'success': True
        })
    except Carrinho.DoesNotExist:
        return JsonResponse({
            'total_itens': 0,
            'total_preco': 0.0,
            'success': True
        })


@login_required
@require_POST
def validar_carrinho_ajax(request):
    """Valida carrinho via AJAX"""
    
    try:
        carrinho = get_object_or_404(Carrinho, usuario=request.user)
        
        problemas = []
        
        for item in carrinho.itens.all():
            produto = item.produto
            
            # Verificar disponibilidade
            if not produto.ativo:
                problemas.append({
                    'item_id': item.id,
                    'produto': produto.nome,
                    'problema': 'Produto indisponível'
                })
                continue
            
            # Verificar estoque
            if produto.controlar_estoque and item.quantidade > produto.estoque:
                problemas.append({
                    'item_id': item.id,
                    'produto': produto.nome,
                    'problema': f'Apenas {produto.estoque} unidades disponíveis'
                })
        
        return JsonResponse({
            'problemas': problemas,
            'total_problemas': len(problemas),
            'carrinho_valido': len(problemas) == 0,
            'success': True
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': 'Erro ao validar carrinho.'
        })