import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartpaws.settings')
django.setup()

from servicos.models import Servico
from django.core.files import File

print("🖼️ Adicionando imagens aos serviços...\n")

# Dicionário: nome do serviço -> nome do arquivo
IMAGENS_SERVICOS = {
    'Banho e Tosa Completo': 'banho_tosa.jpg',
    'Banho Básico': 'banho_basico.jpg',
    'Tosa Higiênica': 'tosa_higienica.jpg',
    'Consulta Veterinária': 'veterinario.jpg',
    'Vacinação V10': 'vacina.jpg',
    'Vacinação Antirrábica': 'vacina_raiva.jpg',
    'Hotel Pet - Diária': 'hotel_pet.jpg',
    'Creche Pet Diária': 'creche_pet.jpg',
    'Dog Walker - 30min': 'passeio.jpg',
    'Dog Walker - 1 hora': 'passeio_longo.jpg',
    'Adestramento Básico': 'adestramento.jpg',
    'Adestramento Avançado': 'adestramento_avancado.jpg',
}

servicos = Servico.objects.all()

for servico in servicos:
    if servico.imagem:
        print(f"⏭️  {servico.nome} já tem imagem")
        continue
    
    arquivo = IMAGENS_SERVICOS.get(servico.nome)
    
    if not arquivo:
        print(f"⚠️  {servico.nome} - Sem imagem definida")
        continue
    
    caminho = f'media/servicos/{arquivo}'
    
    if os.path.exists(caminho):
        with open(caminho, 'rb') as f:
            servico.imagem.save(arquivo, File(f), save=True)
        print(f"✅ {servico.nome} - Imagem adicionada!")
    else:
        print(f"❌ {servico.nome} - Arquivo {arquivo} não encontrado")

print("\n✨ Imagens de serviços adicionadas!\n")