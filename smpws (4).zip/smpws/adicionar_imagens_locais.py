import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartpaws.settings')
django.setup()

from pets.models import Pet
from django.core.files import File

print("🖼️ Adicionando imagens locais...\n")

#Dicionário: nome do pet -> nome do arquivo
IMAGENS = {
    'Rex': 'billy.png',
    'Luna': 'bolinha.png',
    'Max': 'cleiton.png',
    'Bella': 'joca.png',
    'Thor': 'juju.png',
    'Nina': 'muca.png',
    'Bob': 'skoob.png',
    'Mel': 'xavier.png',
    'Zeus': 'cerveja.webp',
    'Lola': 'golden.webp',
    'Duke': 'pug.webp',
    'Mia': 'sorriso.webp',
    'Rocky': 'fro.webp',
    'Sophie': 'bagaco.webp',
    'Charlie': 'pidao.webp',
}

pets = Pet.objects.all()

for pet in pets:
    if pet.foto_principal:
        print(f"⏭️  {pet.nome} já tem imagem")
        continue
    
    arquivo = IMAGENS.get(pet.nome)
    
    if not arquivo:
        print(f"⚠️  {pet.nome} - Sem imagem definida")
        continue
    
    caminho = f'media/pets/{arquivo}'
    
    if os.path.exists(caminho):
        with open(caminho, 'rb') as f:
            pet.foto_principal.save(arquivo, File(f), save=True)
        print(f"✅ {pet.nome} - Imagem adicionada!")
    else:
        print(f"❌ {pet.nome} - Arquivo {arquivo} não encontrado")

print("\n✨ Imagens adicionadas!\n")

