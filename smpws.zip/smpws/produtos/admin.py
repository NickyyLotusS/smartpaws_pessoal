from django.contrib import admin

from django.contrib import admin
from django.utils.html import format_html
from django.db.models import Count
from .models import Categoria, Marca, Produto, ImagemProduto, Avaliacao, Lista


class ImagemProdutoInline(admin.TabularInline):
    """Inline para imagens do produto"""
    model = ImagemProduto
    extra = 1
    fields = ['imagem', 'alt_text', 'is_principal', 'ordem']


@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    """Admin para categorias"""
    
    list_display = [
        'imagem_miniatura',
        'nome',
        'total_produtos_count',
        'ativo',
        'destaque',
        'ordem',
        'created_at'
    ]
    
    list_filter = [
        'ativo',
        'destaque',
        'created_at'
    ]
    
    search_fields = [
        'nome',
        'descricao'
    ]
    
    list_editable = [
        'ativo',
        'destaque',
        'ordem'
    ]
    
    prepopulated_fields = {'slug': ('nome',)}
    
    fieldsets = (
        ('Informações Básicas', {
            'fields': ('nome', 'slug', 'descricao', 'icone')
        }),
        ('Imagem', {
            'fields': ('imagem',)
        }),
        ('Configurações', {
            'fields': ('ativo', 'destaque', 'ordem')
        }),
        ('SEO', {
            'fields': ('meta_title', 'meta_description'),
            'classes': ('collapse',)
        }),
    )
    
    def imagem_miniatura(self, obj):
        if obj.imagem:
            return format_html(
                '<img src="{}" width="50" height="50" style="object-fit: cover; border-radius: 5px;"/>',
                obj.imagem.url
            )
        return '-'
    imagem_miniatura.short_description = 'Imagem'
    
    def total_produtos_count(self, obj):
        return obj.total_produtos
    total_produtos_count.short_description = 'Produtos'
    
    def get_queryset(self, request):
        return super().get_queryset(request).annotate(
            produtos_count=Count('produtos')
        )


@admin.register(Marca)
class MarcaAdmin(admin.ModelAdmin):
    """Admin para marcas"""
    
    list_display = [
        'logo_miniatura',
        'nome',
        'pais_origem',
        'total_produtos_count',
        'ativo',
        'destaque',
        'created_at'
    ]
    
    list_filter = [
        'ativo',
        'destaque',
        'pais_origem',
        'created_at'
    ]
    
    search_fields = [
        'nome',
        'descricao',
        'pais_origem'
    ]
    
    list_editable = [
        'ativo',
        'destaque'
    ]
    
    prepopulated_fields = {'slug': ('nome',)}
    
    def logo_miniatura(self, obj):
        if obj.logo:
            return format_html(
                '<img src="{}" width="50" height="50" style="object-fit: cover; border-radius: 5px;"/>',
                obj.logo.url
            )
        return '-'
    logo_miniatura.short_description = 'Logo'
    
    def total_produtos_count(self, obj):
        return obj.total_produtos
    total_produtos_count.short_description = 'Produtos'


@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin):
    """Admin para produtos"""
    
    list_display = [
        'imagem_miniatura',
        'nome',
        'categoria',
        'marca',
        'preco_formatado',
        'estoque_status',
        'ativo',
        'destaque',
        'total_vendas',
        'visualizacoes',
        'media_avaliacoes_display'
    ]
    
    list_filter = [
        'categoria',
        'marca',
        'tipo_animal',
        'idade_animal',
        'ativo',
        'destaque',
        'promocao',
        'novo',
        'created_at'
    ]
    
    search_fields = [
        'nome',
        'descricao',
        'sku',
        'codigo_barras'
    ]
    
    list_editable = [
        'ativo',
        'destaque',
        'promocao'
    ]
    
    prepopulated_fields = {'slug': ('nome',)}
    
    readonly_fields = [
        'slug',
        'sku',
        'total_vendas',
        'visualizacoes',
        'created_at',
        'updated_at',
        'preview_imagens'
    ]
    
    inlines = [ImagemProdutoInline]
    
    fieldsets = (
        ('Informações Básicas', {
            'fields': ('nome', 'slug', 'categoria', 'marca', 'descricao', 'descricao_curta')
        }),
        ('Preços', {
            'fields': ('preco', 'preco_custo', 'preco_promocional')
        }),
        ('Estoque', {
            'fields': ('estoque', 'estoque_minimo', 'controlar_estoque')
        }),
        ('Características', {
            'fields': ('peso', 'dimensoes', 'unidade_medida', 'tipo_animal', 'idade_animal')
        }),
        ('Códigos', {
            'fields': ('sku', 'codigo_barras')
        }),
        ('Informações Adicionais', {
            'fields': ('ingredientes', 'modo_uso', 'beneficios'),
            'classes': ('collapse',)
        }),
        ('Status', {
            'fields': ('ativo', 'destaque', 'novo', 'promocao')
        }),
        ('Estatísticas', {
            'fields': ('total_vendas', 'visualizacoes', 'created_at', 'updated_at')
        }),
        ('SEO', {
            'fields': ('meta_title', 'meta_description'),
            'classes': ('collapse',)
        }),
        ('Preview Imagens', {
            'fields': ('preview_imagens',)
        }),
    )
    
    def imagem_miniatura(self, obj):
        imagem = obj.imagens.filter(is_principal=True).first()
        if imagem:
            return format_html(
                '<img src="{}" width="50" height="50" style="object-fit: cover; border-radius: 5px;"/>',
                imagem.imagem.url
            )
        return '-'
    imagem_miniatura.short_description = 'Imagem'
    
    def preco_formatado(self, obj):
        if obj.tem_desconto:
            return format_html(
                '<span style="text-decoration: line-through; color: #999;">R$ {:.2f}</span><br>'
                '<strong style="color: #e74c3c;">R$ {:.2f}</strong>',
                float(obj.preco), float(obj.preco_final)
            )
        return f'R$ {obj.preco_final:.2f}'
    preco_formatado.short_description = 'Preço'
    
    def estoque_status(self, obj):
        if not obj.controlar_estoque:
            return format_html('<span style="color: #17a2b8;">Sem controle</span>')
        
        if obj.estoque <= 0:
            return format_html('<span style="color: #dc3545;">Esgotado ({})</span>', obj.estoque)
        elif obj.estoque_baixo:
            return format_html('<span style="color: #ffc107;">Baixo ({})</span>', obj.estoque)
        else:
            return format_html('<span style="color: #28a745;">OK ({})</span>', obj.estoque)
    estoque_status.short_description = 'Estoque'
    
    def media_avaliacoes_display(self, obj):
        media = obj.media_avaliacoes
        total = obj.total_avaliacoes
        if media > 0:
            stars = '★' * int(media) + '☆' * (5 - int(media))
            return format_html(
                '<span title="{} avaliações">{} ({:.1f})</span>',
                total, stars, media
            )
        return '-'
    media_avaliacoes_display.short_description = 'Avaliações'
    
    def preview_imagens(self, obj):
        """Preview de todas as imagens"""
        html = '<div style="display: flex; gap: 10px; flex-wrap: wrap;">'
        for imagem in obj.imagens.all():
            principal = ' (Principal)' if imagem.is_principal else ''
            html += f'''
                <div style="text-align: center;">
                    <img src="{imagem.imagem.url}" width="100" style="border-radius: 5px;"/>
                    <br><small>{imagem.alt_text}{principal}</small>
                </div>
            '''
        html += '</div>'
        return format_html(html) if obj.imagens.exists() else '-'
    preview_imagens.short_description = 'Preview das Imagens'
    
    actions = ['marcar_destaque', 'remover_destaque', 'ativar', 'desativar', 'zerar_estoque']
    
    def marcar_destaque(self, request, queryset):
        count = queryset.update(destaque=True)
        self.message_user(request, f'{count} produto(s) destacado(s).')
    marcar_destaque.short_description = 'Marcar como destaque'
    
    def remover_destaque(self, request, queryset):
        count = queryset.update(destaque=False)
        self.message_user(request, f'Destaque removido de {count} produto(s).')
    remover_destaque.short_description = 'Remover destaque'
    
    def ativar(self, request, queryset):
        count = queryset.update(ativo=True)
        self.message_user(request, f'{count} produto(s) ativado(s).')
    ativar.short_description = 'Ativar produtos'
    
    def desativar(self, request, queryset):
        count = queryset.update(ativo=False)
        self.message_user(request, f'{count} produto(s) desativado(s).')
    desativar.short_description = 'Desativar produtos'


@admin.register(ImagemProduto)
class ImagemProdutoAdmin(admin.ModelAdmin):
    """Admin para imagens"""
    
    list_display = [
        'imagem_miniatura',
        'produto',
        'alt_text',
        'is_principal',
        'ordem'
    ]
    
    list_filter = [
        'is_principal',
        'created_at'
    ]
    
    search_fields = [
        'produto__nome',
        'alt_text'
    ]
    
    list_editable = [
        'is_principal',
        'ordem'
    ]
    
    def imagem_miniatura(self, obj):
        return format_html(
            '<img src="{}" width="80" height="80" style="object-fit: cover; border-radius: 5px;"/>',
            obj.imagem.url
        )
    imagem_miniatura.short_description = 'Imagem'


@admin.register(Avaliacao)
class AvaliacaoAdmin(admin.ModelAdmin):
    """Admin para avaliações"""
    
    list_display = [
        'produto',
        'usuario_nome',
        'nota_display',
        'titulo',
        'aprovado',
        'util',
        'created_at'
    ]
    
    list_filter = [
        'nota',
        'aprovado',
        'created_at'
    ]
    
    search_fields = [
        'produto__nome',
        'usuario__username',
        'titulo',
        'comentario'
    ]
    
    list_editable = [
        'aprovado'
    ]
    
    readonly_fields = [
        'created_at'
    ]
    
    def usuario_nome(self, obj):
        return getattr(obj.usuario, 'nome_completo', obj.usuario.username)
    usuario_nome.short_description = 'Usuário'
    
    def nota_display(self, obj):
        stars = '★' * obj.nota + '☆' * (5 - obj.nota)
        return format_html('<span title="{} estrelas">{}</span>', obj.nota, stars)
    nota_display.short_description = 'Nota'


@admin.register(Lista)
class ListaAdmin(admin.ModelAdmin):
    """Admin para listas"""
    
    list_display = [
        'nome',
        'usuario',
        'tipo',
        'total_produtos_count',
        'publica',
        'updated_at'
    ]
    
    list_filter = [
        'tipo',
        'publica',
        'created_at'
    ]
    
    search_fields = [
        'nome',
        'usuario__username'
    ]
    
    def total_produtos_count(self, obj):
        return obj.total_produtos
    total_produtos_count.short_description = 'Produtos'
