from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    

    path('', include('apps.core.urls')),                    # Home, sobre, contato
    path('produtos/', include('apps.produtos.urls')),       # Catálogo de produtos
    path('usuarios/', include('apps.usuarios.urls')),       # Sistema de usuários
    path('carrinho/', include('apps.carrinho.urls')),      # Carrinho de compras
    path('pagamento/', include('apps.pagamento.urls')),    # Sistema de pagamento
    path('adocao/', include('apps.adocao.urls')),          # Adoção de pets
    path('servicos/', include('apps.servicos.urls')),      # Serviços veterinários
    path('lojas/', include('apps.lojas.urls')),            # Lojas físicas
    path('pets/', include('apps.pets.urls')),              # Pets dos usuários
    
    # API (futuro)
    path('api/v1/', include('apps.api.urls')),
    
    # Redirects úteis
    path('catalogo/', RedirectView.as_view(url='/produtos/', permanent=True)),
    path('loja/', RedirectView.as_view(url='/produtos/', permanent=True)),
]

# Servir arquivos de mídia em desenvolvimento
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


# Handler para erros
handler404 = 'apps.core.views.handler404'
handler500 = 'apps.core.views.handler500'