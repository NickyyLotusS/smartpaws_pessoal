from django.db import models
from django.db import models
from django.contrib.auth import get_user_model
from django.utils.text import slugify
from django.urls import reverse

User = get_user_model

class ServicosDisponiveis (models.Model):

    ...