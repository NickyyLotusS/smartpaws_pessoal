from django.urls import path
from . import views

app_name = 'adocao'

urlpatterns = [
    # Lista de pets
    path('', views.PetAdocaoListView.as_view(), name='lista'),
    
    # Detalhe do pet
    path('<slug:slug>/', views.PetAdocaoDetailView.as_view(), name='detalhe'),
    
    # Cadastrar pet
    path('cadastrar/pet/', views.CadastrarPetAdocaoView.as_view(), name='cadastrar'),
    
    # Solicitar adoção
    path('<slug:slug>/solicitar/', views.SolicitarAdocaoView.as_view(), name='solicitar'),
    
    # Gerenciar pets do usuário
    path('meus/pets/', views.meus_pets, name='meus_pets'),
    path('meus/pets/<slug:slug>/editar/', views.editar_pet, name='editar_pet'),
    path('meus/pets/<slug:slug>/deletar/', views.deletar_pet, name='deletar_pet'),
    path('meus/pets/<slug:slug>/marcar-adotado/', views.marcar_adotado, name='marcar_adotado'),
    
    # Solicitações
    path('minhas/solicitacoes/', views.minhas_solicitacoes, name='minhas_solicitacoes'),
    path('meus/pets/<slug:slug>/solicitacoes/', views.gerenciar_solicitacoes, name='gerenciar_solicitacoes'),
    path('solicitacao/<int:solicitacao_id>/<str:acao>/', views.responder_solicitacao, name='responder_solicitacao'),
]