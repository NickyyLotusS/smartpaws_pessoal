from django import forms
from .models import PetAdocao, SolicitacaoAdocao


class PetAdocaoForm(forms.ModelForm):
    """Formulário para cadastrar pet para adoção"""
    
    class Meta:
        model = PetAdocao
        fields = [
            'nome', 'especie', 'raca', 'sexo',
            'porte', 'idade_categoria', 'idade_meses', 'peso', 'cor',
            'descricao', 'temperamento',
            'foto_principal', 'foto_2', 'foto_3',
            'vacinado', 'castrado', 'vermifugado', 'necessidades_especiais',
            'bom_com_criancas', 'bom_com_outros_pets',
            'cidade', 'estado', 'contato_doador'
        ]
        
        widgets = {
            'nome': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nome do pet'
            }),
            'especie': forms.Select(attrs={'class': 'form-control'}),
            'raca': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: Vira-lata, SRD, Labrador...'
            }),
            'sexo': forms.Select(attrs={'class': 'form-control'}),
            'porte': forms.Select(attrs={'class': 'form-control'}),
            'idade_categoria': forms.Select(attrs={'class': 'form-control'}),
            'idade_meses': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'placeholder': 'Idade em meses'
            }),
            'peso': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'placeholder': 'Peso em kg'
            }),
            'cor': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: Caramelo, Preto e branco...'
            }),
            'descricao': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 5,
                'placeholder': 'Conte sobre o pet: personalidade, história, o que gosta de fazer...'
            }),
            'temperamento': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: Dócil, brincalhão, calmo, energético...'
            }),
            'necessidades_especiais': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Se houver alguma necessidade especial ou cuidado contínuo...'
            }),
            'cidade': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Cidade'
            }),
            'estado': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'UF (Ex: SP)',
                'maxlength': '2'
            }),
            'contato_doador': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'WhatsApp ou telefone para contato'
            }),
        }
        
        labels = {
            'foto_principal': 'Foto Principal *',
            'foto_2': 'Foto 2 (opcional)',
            'foto_3': 'Foto 3 (opcional)',
            'bom_com_criancas': 'É bom com crianças?',
            'bom_com_outros_pets': 'É bom com outros pets?',
        }
    
    def clean_idade_meses(self):
        idade = self.cleaned_data.get('idade_meses')
        if idade < 0:
            raise forms.ValidationError('Idade não pode ser negativa')
        if idade > 300:  # ~25 anos
            raise forms.ValidationError('Idade muito alta, verifique')
        return idade
    
    def clean_estado(self):
        estado = self.cleaned_data.get('estado', '').upper()
        if len(estado) != 2:
            raise forms.ValidationError('Estado deve ter 2 letras (Ex: SP, RJ)')
        return estado


class SolicitacaoAdocaoForm(forms.ModelForm):
    """Formulário para solicitar adoção"""
    
    class Meta:
        model = SolicitacaoAdocao
        fields = [
            'nome_completo', 'cpf', 'telefone', 'email',
            'endereco', 'cidade', 'estado', 'cep',
            'mora_em', 'tem_quintal', 'quintal_fechado',
            'tem_outros_pets', 'quais_pets',
            'tem_criancas', 'idade_criancas',
            'motivo_adocao', 'ja_teve_pet', 'experiencia_pets'
        ]
        
        widgets = {
            'nome_completo': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nome completo'
            }),
            'cpf': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '000.000.000-00'
            }),
            'telefone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '(00) 00000-0000'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'seu@email.com'
            }),
            'endereco': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Rua, número, complemento'
            }),
            'cidade': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Cidade'
            }),
            'estado': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'UF',
                'maxlength': '2'
            }),
            'cep': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '00000-000'
            }),
            'mora_em': forms.Select(attrs={'class': 'form-control'}),
            'quais_pets': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: 2 gatos, 1 cachorro'
            }),
            'idade_criancas': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: 5 e 8 anos'
            }),
            'motivo_adocao': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Por que você deseja adotar este pet?'
            }),
            'experiencia_pets': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Conte sobre sua experiência com pets anteriores'
            }),
        }


class FiltroAdocaoForm(forms.Form):
    """Formulário de filtros"""
    
    especie = forms.ChoiceField(
        choices=[('', 'Todas espécies')] + PetAdocao.ESPECIES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    porte = forms.ChoiceField(
        choices=[('', 'Todos portes')] + PetAdocao.PORTES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    idade = forms.ChoiceField(
        choices=[('', 'Todas idades')] + PetAdocao.IDADES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    estado = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'UF'
        })
    )