from django.db import models
from django.db import models
from django.contrib.auth import get_user_model
from django.utils.text import slugify
from django.urls import reverse

User = get_user_model

class PetAdocao(models.Model):
    #Pets que estão dispiníveis para a adoção

    #Opções ou escolhas:
    ESPECIES = [
        ('cachorro','Cachorro')
        ('gato','Gato')
    ]

    SEXO = [
        ('macho', 'Macho')
        ('femea', 'Fêmea')
    ]

    TAMANHO = [
        ('pequeno', 'Pequeno(5-10 kg)')
        ('medio', 'Médio(10-25kg)')
        ('grande', 'Grande(25-40kg)')
    ]

    IDADE = [
        ('filhote', 'Filhote(0-1 ano)')
        ('jovem', 'Jovem(1-3 anos)')
        ('adulto', 'Adulto(3-7 anos)' )
        ('idoso', 'Idoso(acima de 7 anos)' )
    ]
    
    nome = models.CharField( max_length=100, verbose_name='Nome do animal')
    especie = models.CharField(max_length=20, choices= ESPECIES)
    slug = models.SlugFieldField( max_length=150, unique=True, blank=True)
    raca = models.CharField( max_length=100, blank=True, verbose_name='Raça', help_text='Deixe em branco caso o animal não possua raça')
    sexo = models.CharField( max_length=10, choices=SEXO)
    tamanho = models.CharField( max_length=20, choices= TAMANHO)
    idade_categoria = models.CharField( max_length=20, verbose_name='Faixa Etária', choices= IDADE)
    idade_meses = models.PositiveBigIntegerField(verbose_name="Idade em meses", help_text="Idade aproximada em meses")
    peso = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, verbose_name='Peso(kg)', help_text='Peso do animal')
    cor = models.CharField(max_digits=100,blank=True, verbose_name='Pelagem')
    
    descricao = models.TextField(verbose_name='Descrição', help_text="Conte a história do pet, personalidade, etc.")
    foto_principal= models.ImageField(upload_to='adocao/%Y/%m/', blank=True, null=True, verbose_name='Foto Principal')
    foto_2= models.ImageField(upload_to='adocao/%Y/%m/', blank=True, null=True, verbose_name='Foto 2')
    foto_3= models.ImageField(upload_to='adocao/%Y/%m/', blank=True, null=True, verbose_name='Foto 3')

    #Saude e vacinas

    vacinado = models.BooleanField(default=False, verbose_name="Vacinado?")
    vermifugado = models.BooleanField(default=False, verbose_name="Vermifugado?")
    castracao = models.BooleanField(default=False, verbose_name="Castrado?")
    necessidades_especiais = models.TextField(blank=True, verbose_name="Necessidades Especiais", help_text='tratamento contínuo, medicação')

    #Comportamento
    temperamento = models.CharField(max_length=200, blank=True, help_text="Ex: Dócil, brincalhão, temperamental")
    bom_com_criancas = models.BooleanField(default=True, verbose_name='Dócil com crianças?')
    bom_com_pets = models.BooleanField(default=True, verbose_name='Dócil com outros pets?')
    
    #Localidade

    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2, verbose_name='UF', help_text="Ex: SP, RJ, DF")

    #Informações do doador

    doador = models.ForeignKey( User, on_delete=models.CASCADE, related_name='pets_doacao', verbose_name='Doador')
    contato = models.CharField( max_length=100, verbose_name='Telefone de contato')

 
    adotado = models.BooleanField(
        default=False,
        verbose_name='Já foi adotado?'
    )
    destaque = models.BooleanField(
        default=False,
        verbose_name='Destacar na home?'
    )
    ativo = models.BooleanField(
        default=True,
        verbose_name='Anúncio ativo?'
    )
    
    # Metadados
    data_cadastro = models.DateTimeField(
        auto_now_add=True,
        verbose_name='Data de cadastro'
    )
    data_atualizacao = models.DateTimeField(
        auto_now=True,
        verbose_name='Última atualização'
    )
    visualizacoes = models.PositiveIntegerField(
        default=0,
        verbose_name='Visualizações'
    )
    
    class Meta:
        verbose_name = 'Pet para Adoção'
        verbose_name_plural = 'Pets para Adoção'
        ordering = ['-data_cadastro']
        indexes = [
            models.Index(fields=['especie', 'adotado']),
            models.Index(fields=['cidade', 'estado']),
            models.Index(fields=['-data_cadastro']),
        ]
    
    def __str__(self):
        return f"{self.nome} - {self.get_especie_display()}"
    
    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.nome)
            slug = base_slug
            contador = 1
            while PetAdocao.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{contador}"
                contador += 1
            self.slug = slug
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        return reverse('adocao:detalhe', kwargs={'slug': self.slug})
    
    @property
    def idade_formatada(self):
        """Retorna idade formatada"""
        anos = self.idade_meses // 12
        meses = self.idade_meses % 12
        
        if anos > 0:
            return f"{anos} ano(s) e {meses} mês(es)"
        return f"{meses} mês(es)"
    
    @property
    def todas_fotos(self):
       
        fotos = [self.foto_principal]
        if self.foto_2:
            fotos.append(self.foto_2)
        if self.foto_3:
            fotos.append(self.foto_3)
        return fotos
    
    def incrementar_visualizacao(self):
     
        self.visualizacoes += 1
        self.save(update_fields=['visualizacoes'])

class SolicitacaoAdocao(models.Model):
    #solicitação de adoção
    
    STATUS_CHOICES = [
        ('pendente', 'Pendente'),
        ('em_analise', 'Em Análise'),
        ('aprovada', 'Aprovada'),
        ('recusada', 'Recusada'),
        ('cancelada', 'Cancelada'),
    ]
    
    # Relacionamentos
    pet = models.ForeignKey(
        PetAdocao,
        on_delete=models.CASCADE,
        related_name='solicitacoes',
        verbose_name='Pet'
    )
    solicitante = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='solicitacoes_adocao',
        verbose_name='Solicitante'
    )
    
    # Dados do adotante
    nome_completo = models.CharField(max_length=200)
    cpf = models.CharField(max_length=14)
    telefone = models.CharField(max_length=20)
    email = models.EmailField()
    
    # Endereço
    endereco = models.CharField(max_length=200)
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2)
    cep = models.CharField(max_length=9)
    
    # Questionário sobre moradia e condições
    mora_em = models.CharField(
        max_length=50,
        choices=[
            ('casa', 'Casa'),
            ('apartamento', 'Apartamento'),
        ],
        verbose_name='Tipo de moradia'
    )
    tem_quintal = models.BooleanField(
        default=False,
        verbose_name='Tem quintal?'
    )
    quintal_fechado = models.BooleanField(
        default=False,
        verbose_name='Quintal é fechado?'
    )
    tem_outros_pets = models.BooleanField(
        default=False,
        verbose_name='Tem outros pets?'
    )
    quais_pets = models.CharField(
        max_length=200,
        blank=True,
        verbose_name='Quais pets?'
    )
    tem_criancas = models.BooleanField(
        default=False,
        verbose_name='Tem crianças?'
    )
    idade_criancas = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='Idade das crianças'
    )
    motivo_adocao = models.TextField(
        verbose_name='Por que deseja adotar este pet?'
    )
    ja_teve_pet = models.BooleanField(
        default=False,
        verbose_name='Já teve pet antes?'
    )
    experiencia_pets = models.TextField(
        blank=True,
        verbose_name='Conte sua experiência com pets'
    )
    
    # Status
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pendente'
    )
    observacoes_doador = models.TextField(
        blank=True,
        verbose_name='Observações do doador'
    )
    
    # Datas
    data_solicitacao = models.DateTimeField(auto_now_add=True)
    data_resposta = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = 'Solicitação de Adoção'
        verbose_name_plural = 'Solicitações de Adoção'
        ordering = ['-data_solicitacao']
    
    def __str__(self):
        return f"{self.solicitante.username} -> {self.pet.nome}"
