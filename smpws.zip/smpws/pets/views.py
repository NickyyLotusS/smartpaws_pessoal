from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.db.models import Q, Count
from django.urls import reverse_lazy
from django.core.paginator import Paginator
from .models import PetAdocao, SolicitacaoAdocao
from .forms import PetAdocaoForm, SolicitacaoAdocaoForm, FiltroAdocaoForm


# ==========================================
# VIEW 1: LISTAR PETS DISPONÍVEIS
# ==========================================

class PetAdocaoListView(ListView):
    """Lista de pets disponíveis para adoção"""
    
    model = PetAdocao
    template_name = 'adicionardps.html'
    context_object_name = 'pets'
    paginate_by = 12
    
    def get_queryset(self):
        queryset = PetAdocao.objects.filter(
            adotado=False,
            ativo=True
        ).select_related('doador')
        
        # Filtro por espécie
        especie = self.request.GET.get('especie')
        if especie:
            queryset = queryset.filter(especie=especie)
        
        # Filtro por porte
        porte = self.request.GET.get('porte')
        if porte:
            queryset = queryset.filter(porte=porte)
        
        # Filtro por idade
        idade = self.request.GET.get('idade')
        if idade:
            queryset = queryset.filter(idade_categoria=idade)
        
        # Filtro por localização
        estado = self.request.GET.get('estado')
        if estado:
            queryset = queryset.filter(estado=estado)
        
        cidade = self.request.GET.get('cidade')
        if cidade:
            queryset = queryset.filter(cidade__icontains=cidade)
        
        # Filtros de saúde
        if self.request.GET.get('vacinado') == 'sim':
            queryset = queryset.filter(vacinado=True)
        if self.request.GET.get('castrado') == 'sim':
            queryset = queryset.filter(castrado=True)
        
        # Filtros de comportamento
        if self.request.GET.get('bom_criancas') == 'sim':
            queryset = queryset.filter(bom_com_criancas=True)
        if self.request.GET.get('bom_pets') == 'sim':
            queryset = queryset.filter(bom_com_outros_pets=True)
        
        # Busca por nome
        busca = self.request.GET.get('q')
        if busca:
            queryset = queryset.filter(
                Q(nome__icontains=busca) |
                Q(raca__icontains=busca) |
                Q(descricao__icontains=busca)
            )
        
        # Ordenação
        ordem = self.request.GET.get('ordem', '-data_cadastro')
        queryset = queryset.order_by(ordem)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['total_pets'] = self.get_queryset().count()
        context['form_filtro'] = FiltroAdocaoForm(self.request.GET)
        context['filtros_ativos'] = any([
            self.request.GET.get('especie'),
            self.request.GET.get('porte'),
            self.request.GET.get('idade'),
            self.request.GET.get('estado'),
        ])
        
        # Estatísticas
        context['stats'] = {
            'total_disponiveis': PetAdocao.objects.filter(adotado=False, ativo=True).count(),
            'total_adotados': PetAdocao.objects.filter(adotado=True).count(),
            'cachorros': PetAdocao.objects.filter(especie='cachorro', adotado=False).count(),
            'gatos': PetAdocao.objects.filter(especie='gato', adotado=False).count(),
        }
        
        return context


# ==========================================
# VIEW 2: DETALHE DO PET
# ==========================================

class PetAdocaoDetailView(DetailView):
    """Página de detalhes de um pet"""
    
    model = PetAdocao
    template_name = 'adicionardps.html'
    context_object_name = 'pet'
    slug_field = 'slug'
    slug_url_kwarg = 'slug'
    
    def get_queryset(self):
        return PetAdocao.objects.filter(ativo=True).select_related('doador')
    
    def get_object(self):
        obj = super().get_object()
        # Incrementar visualizações
        obj.incrementar_visualizacao()
        return obj
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        pet = self.get_object()
        
        # Pets similares (mesma espécie, mesmo porte)
        context['pets_similares'] = PetAdocao.objects.filter(
            especie=pet.especie,
            porte=pet.porte,
            adotado=False,
            ativo=True
        ).exclude(id=pet.id)[:4]
        
        # Verificar se usuário já fez solicitação
        if self.request.user.is_authenticated:
            context['ja_solicitou'] = SolicitacaoAdocao.objects.filter(
                pet=pet,
                solicitante=self.request.user
            ).exists()
        
        return context


# ==========================================
# VIEW 3: CADASTRAR PET PARA ADOÇÃO
# ==========================================

class CadastrarPetAdocaoView(LoginRequiredMixin, CreateView):
    """Cadastrar pet para adoção"""
    
    model = PetAdocao
    form_class = PetAdocaoForm
    template_name = 'adicionardps.html'
    success_url = reverse_lazy('adocao:meus_pets')
    
    def form_valid(self, form):
        form.instance.doador = self.request.user
        messages.success(
            self.request,
            f'Pet "{form.instance.nome}" cadastrado com sucesso! '
            'Aguarde análise para ser publicado.'
        )
        return super().form_valid(form)
    
    def form_invalid(self, form):
        messages.error(
            self.request,
            'Erro ao cadastrar pet. Verifique os campos.'
        )
        return super().form_invalid(form)


# ==========================================
# VIEW 4: SOLICITAR ADOÇÃO
# ==========================================

class SolicitarAdocaoView(LoginRequiredMixin, CreateView):
    """Solicitar adoção de um pet"""
    
    model = SolicitacaoAdocao
    form_class = SolicitacaoAdocaoForm
    template_name = 'adicionardps.html'
    
    def dispatch(self, request, *args, **kwargs):
        self.pet = get_object_or_404(
            PetAdocao,
            slug=kwargs['slug'],
            adotado=False,
            ativo=True
        )
        
        # Verificar se já solicitou
        if SolicitacaoAdocao.objects.filter(
            pet=self.pet,
            solicitante=request.user
        ).exists():
            messages.warning(
                request,
                'Você já fez uma solicitação para este pet.'
            )
            return redirect('adocao:detalhe', slug=self.pet.slug)
        
        return super().dispatch(request, *args, **kwargs)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['pet'] = self.pet
        return context
    
    def form_valid(self, form):
        form.instance.pet = self.pet
        form.instance.solicitante = self.request.user
        messages.success(
            self.request,
            f'Solicitação enviada com sucesso! '
            f'O doador entrará em contato em breve.'
        )
        return super().form_valid(form)
    
    def get_success_url(self):
        return reverse_lazy('adocao:minhas_solicitacoes')


# ==========================================
# VIEW 5: MEUS PETS (PARA DOAÇÃO)
# ==========================================

@login_required
def meus_pets(request):
    """Pets que o usuário cadastrou para doação"""
    
    pets = PetAdocao.objects.filter(
        doador=request.user
    ).annotate(
        total_solicitacoes=Count('solicitacoes')
    ).order_by('-data_cadastro')
    
    # Paginação
    paginator = Paginator(pets, 10)
    page_number = request.GET.get('page')
    pets_paginados = paginator.get_page(page_number)
    
    context = {
        'pets': pets_paginados,
        'total_pets': pets.count(),
        'pets_disponiveis': pets.filter(adotado=False, ativo=True).count(),
        'pets_adotados': pets.filter(adotado=True).count(),
    }
    
    return render(request, 'adocao/meus_pets.html', context)


# ==========================================
# VIEW 6: MINHAS SOLICITAÇÕES
# ==========================================

@login_required
def minhas_solicitacoes(request):
    """Solicitações de adoção feitas pelo usuário"""
    
    solicitacoes = SolicitacaoAdocao.objects.filter(
        solicitante=request.user
    ).select_related('pet', 'pet__doador').order_by('-data_solicitacao')
    
    # Paginação
    paginator = Paginator(solicitacoes, 10)
    page_number = request.GET.get('page')
    solicitacoes_paginadas = paginator.get_page(page_number)
    
    context = {
        'solicitacoes': solicitacoes_paginadas,
        'total_solicitacoes': solicitacoes.count(),
        'pendentes': solicitacoes.filter(status='pendente').count(),
        'aprovadas': solicitacoes.filter(status='aprovada').count(),
    }
    
    return render(request, 'adocao/minhas_solicitacoes.html', context)


# ==========================================
# VIEW 7: GERENCIAR SOLICITAÇÕES (DOADOR)
# ==========================================

@login_required
def gerenciar_solicitacoes(request, slug):
    """Doador gerencia solicitações do seu pet"""
    
    pet = get_object_or_404(
        PetAdocao,
        slug=slug,
        doador=request.user
    )
    
    solicitacoes = SolicitacaoAdocao.objects.filter(
        pet=pet
    ).select_related('solicitante').order_by('-data_solicitacao')
    
    context = {
        'pet': pet,
        'solicitacoes': solicitacoes,
        'total': solicitacoes.count(),
        'pendentes': solicitacoes.filter(status='pendente').count(),
    }
    
    return render(request, 'adocao/gerenciar_solicitacoes.html', context)


# ==========================================
# VIEW 8: APROVAR/RECUSAR SOLICITAÇÃO
# ==========================================

@login_required
def responder_solicitacao(request, solicitacao_id, acao):
    """Aprovar ou recusar solicitação de adoção"""
    
    from django.utils import timezone
    
    solicitacao = get_object_or_404(
        SolicitacaoAdocao,
        id=solicitacao_id,
        pet__doador=request.user
    )
    
    if acao == 'aprovar':
        solicitacao.status = 'aprovada'
        solicitacao.data_resposta = timezone.now()
        solicitacao.save()
        
        messages.success(
            request,
            f'Solicitação de {solicitacao.solicitante.username} aprovada!'
        )
    
    elif acao == 'recusar':
        solicitacao.status = 'recusada'
        solicitacao.data_resposta = timezone.now()
        solicitacao.save()
        
        messages.info(
            request,
            f'Solicitação de {solicitacao.solicitante.username} recusada.'
        )
    
    return redirect('adocao:gerenciar_solicitacoes', slug=solicitacao.pet.slug)


# ==========================================
# VIEW 9: MARCAR PET COMO ADOTADO
# ==========================================

@login_required
def marcar_adotado(request, slug):
    """Marcar pet como adotado"""
    
    pet = get_object_or_404(
        PetAdocao,
        slug=slug,
        doador=request.user
    )
    
    pet.adotado = True
    pet.save()
    
    messages.success(
        request,
        f'Pet "{pet.nome}" marcado como adotado! Parabéns! 🎉'
    )
    
    return redirect('adocao:meus_pets')


# ==========================================
# VIEW 10: EDITAR PET
# ==========================================

@login_required
def editar_pet(request, slug):
    """Editar pet cadastrado"""
    
    pet = get_object_or_404(
        PetAdocao,
        slug=slug,
        doador=request.user
    )
    
    if request.method == 'POST':
        form = PetAdocaoForm(request.POST, request.FILES, instance=pet)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pet atualizado com sucesso!')
            return redirect('adocao:meus_pets')
    else:
        form = PetAdocaoForm(instance=pet)
    
    context = {
        'form': form,
        'pet': pet,
        'editando': True
    }
    
    return render(request, 'adocao/cadastrar.html', context)


# ==========================================
# VIEW 11: DELETAR PET
# ==========================================

@login_required
def deletar_pet(request, slug):
    """Deletar pet cadastrado"""
    
    pet = get_object_or_404(
        PetAdocao,
        slug=slug,
        doador=request.user
    )
    
    if request.method == 'POST':
        nome = pet.nome
        pet.delete()
        messages.success(request, f'Pet "{nome}" removido com sucesso.')
        return redirect('adocao:meus_pets')
    
    context = {'pet': pet}
    return render(request, 'adocao/confirmar_delete.html', context)