from django.contrib import admin
from django.utils.html import format_html
from .models import PetAdocao, SolicitacaoAdocao


@admin.register(PetAdocao)
class PetAdocaoAdmin(admin.ModelAdmin):
    """Admin customizado para pets"""
    
    list_display = [
        'foto_miniatura',
        'nome',
        'especie',
        'raca',
        'porte',
        'idade_categoria',
        'cidade_estado',
        'doador',
        'adotado',
        'destaque',
        'visualizacoes',
        'data_cadastro'
    ]
    
    list_filter = [
        'especie',
        'porte',
        'idade_categoria',
        'sexo',
        'adotado',
        'destaque',
        'vacinado',
        'castrado',
        'estado',
        'data_cadastro'
    ]
    
    search_fields = [
        'nome',
        'raca',
        'cidade',
        'descricao',
        'doador__username',
        'doador__email'
    ]
    
    list_editable = [
        'adotado',
        'destaque'
    ]
    
    prepopulated_fields = {'slug': ('nome',)}
    
    readonly_fields = [
        'slug',
        'visualizacoes',
        'data_cadastro',
        'data_atualizacao',
        'preview_fotos'
    ]
    
    fieldsets = (
        ('Informações Básicas', {
            'fields': ('nome', 'slug', 'especie', 'raca', 'sexo')
        }),
        ('Características', {
            'fields': ('porte', 'idade_categoria', 'idade_meses', 'peso', 'cor')
        }),
        ('Descrição', {
            'fields': ('descricao', 'temperamento')
        }),
        ('Fotos', {
            'fields': ('foto_principal', 'foto_2', 'foto_3', 'preview_fotos')
        }),
        ('Saúde', {
            'fields': ('vacinado', 'castrado', 'vermifugado', 'necessidades_especiais')
        }),
        ('Comportamento', {
            'fields': ('bom_com_criancas', 'bom_com_outros_pets')
        }),
        ('Localização', {
            'fields': ('cidade', 'estado')
        }),
        ('Doador', {
            'fields': ('doador', 'contato_doador')
        }),
        ('Status', {
            'fields': ('adotado', 'destaque', 'ativo')
        }),
        ('Estatísticas', {
            'fields': ('visualizacoes', 'data_cadastro', 'data_atualizacao')
        }),
    )
    
    def foto_miniatura(self, obj):

        if obj.foto_principal:
            return format_html(
                '<img src="{}" width="50" height="50" style="object-fit: cover; border-radius: 5px;"/>',
                obj.foto_principal.url
            )
        return '-'
    foto_miniatura.short_description = 'Foto'
    
    def cidade_estado(self, obj):

        return f"{obj.cidade}/{obj.estado}"
    cidade_estado.short_description = 'Localização'
    
    def preview_fotos(self, obj):

        html = '<div style="display: flex; gap: 10px;">'
        for foto in obj.todas_fotos:
            if foto:
                html += f'<img src="{foto.url}" width="150" style="border-radius: 5px;"/>'
        html += '</div>'
        return format_html(html)
    preview_fotos.short_description = 'Preview das Fotos'
    
    actions = ['marcar_como_adotado', 'marcar_como_disponivel', 'destacar', 'remover_destaque']
    
    def marcar_como_adotado(self, request, queryset):

        count = queryset.update(adotado=True)
        self.message_user(request, f'{count} pet(s) marcado(s) como adotado(s).')
    marcar_como_adotado.short_description = 'Marcar como adotado'
    
    def marcar_como_disponivel(self, request, queryset):

        count = queryset.update(adotado=False)
        self.message_user(request, f'{count} pet(s) marcado(s) como disponível(eis).')
    marcar_como_disponivel.short_description = 'Marcar como disponível'
    
    def destacar(self, request, queryset):

        count = queryset.update(destaque=True)
        self.message_user(request, f'{count} pet(s) destacado(s).')
    destacar.short_description = 'Destacar na home'
    
    def remover_destaque(self, request, queryset):

        count = queryset.update(destaque=False)
        self.message_user(request, f'Destaque removido de {count} pet(s).')
    remover_destaque.short_description = 'Remover destaque'


@admin.register(SolicitacaoAdocao)
class SolicitacaoAdocaoAdmin(admin.ModelAdmin):

    
    list_display = [
        'id',
        'pet',
        'solicitante',
        'telefone',
        'cidade_estado',
        'status_badge',
        'data_solicitacao'
    ]
    
    list_filter = [
        'status',
        'mora_em',
        'tem_quintal',
        'tem_outros_pets',
        'tem_criancas',
        'data_solicitacao'
    ]
    
    search_fields = [
        'nome_completo',
        'cpf',
        'email',
        'telefone',
        'pet__nome',
        'solicitante__username'
    ]
    
    readonly_fields = [
        'data_solicitacao',
        'data_resposta'
    ]
    
    fieldsets = (
        ('Informações da Solicitação', {
            'fields': ('pet', 'solicitante', 'status', 'data_solicitacao', 'data_resposta')
        }),
        ('Dados Pessoais', {
            'fields': ('nome_completo', 'cpf', 'telefone', 'email')
        }),
        ('Endereço', {
            'fields': ('endereco', 'cidade', 'estado', 'cep')
        }),
        ('Moradia', {
            'fields': ('mora_em', 'tem_quintal', 'quintal_fechado')
        }),
        ('Pets e Crianças', {
            'fields': ('tem_outros_pets', 'quais_pets', 'tem_criancas', 'idade_criancas')
        }),
        ('Sobre o Adotante', {
            'fields': ('motivo_adocao', 'ja_teve_pet', 'experiencia_pets')
        }),
        ('Avaliação', {
            'fields': ('observacoes_doador',)
        }),
    )
    
    def cidade_estado(self, obj):
        return f"{obj.cidade}/{obj.estado}"
    cidade_estado.short_description = 'Localização'
    
    def status_badge(self, obj):
     
        colors = {
            'pendente': '#ffc107',
            'em_analise': '#17a2b8',
            'aprovada': '#28a745',
            'recusada': '#dc3545',
            'cancelada': '#6c757d',
        }
        return format_html(
            '<span style="background: {}; color: white; padding: 3px 10px; border-radius: 3px; font-weight: bold;">{}</span>',
            colors.get(obj.status, '#6c757d'),
            obj.get_status_display()
        )
    status_badge.short_description = 'Status'
    
    actions = ['aprovar_solicitacoes', 'recusar_solicitacoes']
    
    def aprovar_solicitacoes(self, request, queryset):
       
        from django.utils import timezone
        count = queryset.update(status='aprovada', data_resposta=timezone.now())
        self.message_user(request, f'{count} solicitação(ões) aprovada(s).')
    aprovar_solicitacoes.short_description = 'Aprovar solicitações'
    
    def recusar_solicitacoes(self, request, queryset):
    
        from django.utils import timezone
        count = queryset.update(status='recusada', data_resposta=timezone.now())
        self.message_user(request, f'{count} solicitação(ões) recusada(s).')
    recusar_solicitacoes.short_description = 'Recusar solicitações'