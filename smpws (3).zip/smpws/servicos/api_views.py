from rest_framework import status, generics, permissions, filters
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db.models import Q, Avg
from django.utils import timezone
from django_filters.rest_framework import DjangoFilterBackend

from .models import (
    TipoServico, Profissional, Servico, Agendamento, AvaliacaoServico
)
from .serializers import (
    TipoServicoSerializer, ProfissionalSerializer, ProfissionalResumoSerializer,
    ServicoSerializer, AgendamentoSerializer, CriarAgendamentoSerializer,
    AvaliacaoServicoSerializer, CadastrarProfissionalSerializer
)
from .filters import ProfissionalFilter, ServicoFilter


class TipoServicoListAPIView(generics.ListAPIView):

    
    queryset = TipoServico.objects.filter(ativo=True)
    serializer_class = TipoServicoSerializer
    permission_classes = [permissions.AllowAny]


class ProfissionalListAPIView(generics.ListAPIView):

    
    serializer_class = ProfissionalResumoSerializer
    permission_classes = [permissions.AllowAny]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = ProfissionalFilter
    search_fields = ['nome_comercial', 'descricao', 'cidade']
    ordering_fields = ['nota_media', 'total_avaliacoes', 'created_at']
    ordering = ['-nota_media', '-total_avaliacoes']
    
    def get_queryset(self):
        return Profissional.objects.filter(
            status='ativo',
            aceita_agendamentos=True
        ).prefetch_related('servicos', 'avaliacoes')


class ProfissionalDetailAPIView(generics.RetrieveAPIView):

    
    serializer_class = ProfissionalSerializer
    permission_classes = [permissions.AllowAny]
    
    def get_queryset(self):
        return Profissional.objects.filter(status='ativo').prefetch_related(
            'servicos__tipo_servico', 'horarios', 'fotos', 'avaliacoes__cliente'
        )


class ServicoListAPIView(generics.ListAPIView):

    
    serializer_class = ServicoSerializer
    permission_classes = [permissions.AllowAny]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = ServicoFilter
    search_fields = ['nome', 'descricao', 'profissional__nome_comercial']
    ordering_fields = ['preco_base', 'duracao_estimada']
    ordering = ['preco_base']
    
    def get_queryset(self):
        return Servico.objects.filter(
            ativo=True,
            profissional__status='ativo',
            profissional__aceita_agendamentos=True
        ).select_related('tipo_servico', 'profissional')


class CadastrarProfissionalAPIView(generics.CreateAPIView):

    
    serializer_class = CadastrarProfissionalSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def create(self, request, *args, **kwargs):
        # Verificar se usuário já é profissional
        if hasattr(request.user, 'profissional'):
            return Response({
                'message': 'Usuário já possui cadastro como profissional.',
                'success': False
            }, status=status.HTTP_400_BAD_REQUEST)
        
        response = super().create(request, *args, **kwargs)
        
        if response.status_code == 201:
            response.data = {
                'message': 'Cadastro enviado para aprovação! Você receberá um email quando for aprovado.',
                'profissional': response.data,
                'success': True
            }
        
        return response


class AgendamentoCreateAPIView(generics.CreateAPIView):

    
    serializer_class = CriarAgendamentoSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        
        if response.status_code == 201:
            agendamento = Agendamento.objects.get(id=response.data['id'])
            response.data = {
                'message': 'Agendamento criado com sucesso!',
                'agendamento': AgendamentoSerializer(agendamento).data,
                'success': True
            }
        
        return response


class MeusAgendamentosAPIView(generics.ListAPIView):
  
    
    serializer_class = AgendamentoSerializer
    permission_classes = [permissions.IsAuthenticated]
    ordering = ['-data_agendamento', '-hora_agendamento']
    
    def get_queryset(self):
        return Agendamento.objects.filter(
            cliente=self.request.user
        ).select_related('servico__profissional', 'servico__tipo_servico')


class AgendamentoDetailAPIView(generics.RetrieveAPIView):

    
    serializer_class = AgendamentoSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return Agendamento.objects.filter(
            cliente=self.request.user
        ).select_related('servico__profissional', 'servico__tipo_servico')


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def cancelar_agendamento(request, agendamento_id):

    
    try:
        agendamento = get_object_or_404(
            Agendamento,
            id=agendamento_id,
            cliente=request.user
        )
        
        motivo = request.data.get('motivo', '')
        
        if agendamento.cancelar(motivo):
            return Response({
                'message': 'Agendamento cancelado com sucesso!',
                'agendamento': AgendamentoSerializer(agendamento).data,
                'success': True
            })
        else:
            return Response({
                'message': 'Não é possível cancelar este agendamento.',
                'success': False
            }, status=status.HTTP_400_BAD_REQUEST)
            
    except Exception as e:
        return Response({
            'message': 'Erro ao cancelar agendamento.',
            'success': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET'])
@permission_classes([permissions.AllowAny])
def horarios_disponiveis(request, servico_id):

    
    data_str = request.GET.get('data')
    if not data_str:
        return Response({
            'message': 'Parâmetro data é obrigatório.',
            'success': False
        }, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        from datetime import datetime
        data = datetime.strptime(data_str, '%Y-%m-%d').date()
        
        servico = get_object_or_404(Servico, id=servico_id, ativo=True)
        

        dia_semana = data.weekday()
        horario_funcionamento = servico.profissional.horarios.filter(
            dia_semana=dia_semana,
            ativo=True
        ).first()
        
        if not horario_funcionamento:
            return Response({
                'horarios': [],
                'message': 'Profissional não atende neste dia.',
                'success': True
            })
        
      
        from datetime import time, timedelta
        
        horarios_possiveis = []
        hora_atual = horario_funcionamento.hora_inicio
        hora_fim = horario_funcionamento.hora_fim
        
        while hora_atual < hora_fim:
            horarios_possiveis.append(hora_atual)
  
            dt = timezone.datetime.combine(data, hora_atual)
            dt += timedelta(minutes=30)
            hora_atual = dt.time()
        
  
        agendamentos_ocupados = Agendamento.objects.filter(
            servico=servico,
            data_agendamento=data,
            status__in=['pendente', 'confirmado', 'em_andamento']
        ).values_list('hora_agendamento', flat=True)
        
        horarios_disponiveis = [
            h.strftime('%H:%M') for h in horarios_possiveis 
            if h not in agendamentos_ocupados
        ]
        
        return Response({
            'horarios': horarios_disponiveis,
            'data': data_str,
            'success': True
        })
        
    except ValueError:
        return Response({
            'message': 'Formato de data inválido. Use YYYY-MM-DD.',
            'success': False
        }, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        return Response({
            'message': 'Erro ao buscar horários.',
            'success': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AvaliarServicoAPIView(generics.CreateAPIView):

    
    serializer_class = AvaliacaoServicoSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def create(self, request, *args, **kwargs):
        agendamento_id = request.data.get('agendamento_id')
        
        if not agendamento_id:
            return Response({
                'message': 'ID do agendamento é obrigatório.',
                'success': False
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            agendamento = get_object_or_404(
                Agendamento,
                id=agendamento_id,
                cliente=request.user,
                status='concluido'
            )

            if hasattr(agendamento, 'avaliacao'):
                return Response({
                    'message': 'Este agendamento já foi avaliado.',
                    'success': False
                }, status=status.HTTP_400_BAD_REQUEST)
            
      
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            
            avaliacao = serializer.save(
                agendamento=agendamento,
                cliente=request.user,
                profissional=agendamento.servico.profissional
            )
            
            return Response({
                'message': 'Avaliação enviada com sucesso!',
                'avaliacao': AvaliacaoServicoSerializer(avaliacao).data,
                'success': True
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            return Response({
                'message': 'Erro ao enviar avaliação.',
                'success': False
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)