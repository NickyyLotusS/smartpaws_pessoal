# ==========================================
# apps/servicos/views.py
# ==========================================

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Avg
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone

from .models import (
    TipoServico, Profissional, Servico, DisponibilidadeProfissional,
    Agendamento, AvaliacaoProfissional
)
from .forms import (
    CadastroProfissionalForm, AgendarServicoForm, AvaliarServicoForm,
    BuscarServicoForm, DisponibilidadeForm, ServicoForm
)


def home_servicos(request):
    """Página inicial dos serviços"""
    
    # Tipos de serviços disponíveis
    tipos_servicos = TipoServico.objects.filter(ativo=True).order_by('ordem')
    
    # Profissionais em destaque (melhor avaliados)
    profissionais_destaque = Profissional.objects.filter(
        status='aprovado',
        ativo=True
    ).order_by('-nota_media', '-total_avaliacoes')[:8]
    
    # Estatísticas
    stats = {
        'total_profissionais': Profissional.objects.filter(status='aprovado', ativo=True).count(),
        'total_servicos': Servico.objects.filter(ativo=True).count(),
        'total_agendamentos': Agendamento.objects.count(),
    }
    
    context = {
        'tipos_servicos': tipos_servicos,
        'profissionais_destaque': profissionais_destaque,
        'stats': stats,
    }
    
    return render(request, 'servicos/home.html', context)


def buscar_servicos(request):
    """Busca e lista serviços/profissionais"""
    
    form = BuscarServicoForm(request.GET)
    profissionais = Profissional.objects.filter(
        status='aprovado',
        ativo=True
    ).prefetch_related('servicos', 'avaliacoes')
    
    if form.is_valid():
        busca = form.cleaned_data.get('busca')
        tipo_servico = form.cleaned_data.get('tipo_servico')
        cidade = form.cleaned_data.get('cidade')
        estado = form.cleaned_data.get('estado')
        preco_max = form.cleaned_data.get('preco_max')
        aceita_emergencia = form.cleaned_data.get('aceita_emergencia')
        trabalha_finais_semana = form.cleaned_data.get('trabalha_finais_semana')
        apenas_verificados = form.cleaned_data.get('apenas_verificados')
        ordenar = form.cleaned_data.get('ordenar', 'relevancia')
        
        # Aplicar filtros
        if busca:
            profissionais = profissionais.filter(
                Q(nome_profissional__icontains=busca) |
                Q(bio__icontains=busca) |
                Q(servicos__tipo_servico__titulo__icontains=busca)
            ).distinct()
        
        if tipo_servico:
            profissionais = profissionais.filter(
                servicos__tipo_servico=tipo_servico
            ).distinct()
        
        if cidade:
            profissionais = profissionais.filter(cidade__icontains=cidade)
        
        if estado:
            profissionais = profissionais.filter(estado=estado)
        
        if preco_max:
            profissionais = profissionais.filter(
                servicos__preco__lte=preco_max
            ).distinct()
        
        if aceita_emergencia:
            profissionais = profissionais.filter(aceita_emergencia=True)
        
        if trabalha_finais_semana:
            profissionais = profissionais.filter(trabalha_finais_semana=True)
        
        if apenas_verificados:
            profissionais = profissionais.filter(verificado=True)
        
        # Aplicar ordenação
        if ordenar == 'nota':
            profissionais = profissionais.order_by('-nota_media', '-total_avaliacoes')
        elif ordenar == 'preco_asc':
            profissionais = profissionais.order_by('servicos__preco')
        elif ordenar == 'preco_desc':
            profissionais = profissionais.order_by('-servicos__preco')
        elif ordenar == 'experiencia':
            profissionais = profissionais.order_by('-experiencia_anos')
        elif ordenar == 'recentes':
            profissionais = profissionais.order_by('-created_at')
        else:  # relevancia
            profissionais = profissionais.order_by('-nota_media', '-total_agendamentos')
    
    # Paginação
    paginator = Paginator(profissionais, 12)
    page = request.GET.get('page')
    profissionais_paginados = paginator.get_page(page)
    
    context = {
        'form': form,
        'profissionais': profissionais_paginados,
        'total_resultados': profissionais.count(),
    }
    
    return render(request, 'servicos/buscar.html', context)


def profissional_detalhe(request, slug):
    """Detalhes do profissional"""
    
    profissional = get_object_or_404(
        Profissional.objects.prefetch_related(
            'servicos__tipo_servico',
            'disponibilidades',
            'avaliacoes__cliente'
        ),
        slug=slug,
        status='aprovado',
        ativo=True
    )
    
    # Serviços do profissional
    servicos = profissional.servicos.filter(ativo=True).select_related('tipo_servico')
    
    # Disponibilidades
    disponibilidades = profissional.disponibilidades.filter(ativo=True).order_by('dia_semana')
    
    # Avaliações recentes
    avaliacoes = profissional.avaliacoes.filter(aprovado=True).select_related('cliente').order_by('-created_at')
    
    context = {
        'profissional': profissional,
        'servicos': servicos,
        'disponibilidades': disponibilidades,
        'avaliacoes': avaliacoes[:10],  # Últimas 10
        'total_avaliacoes': avaliacoes.count(),
    }
    
    return render(request, 'servicos/profissional_detalhe.html', context)


@login_required
def agendar_servico(request, profissional_slug, servico_id):
    """Agendar um serviço específico"""
    
    profissional = get_object_or_404(
        Profissional,
        slug=profissional_slug,
        status='aprovado',
        ativo=True
    )
    
    servico = get_object_or_404(
        Servico,
        id=servico_id,
        profissional=profissional,
        ativo=True
    )
    
    if request.method == 'POST':
        form = AgendarServicoForm(profissional=profissional, data=request.POST)
        
        if form.is_valid():
            try:
                agendamento = form.save(commit=False)
                agendamento.cliente = request.user
                
                # Calcular horário de fim
                from datetime import datetime, timedelta
                duracao = timedelta(minutes=servico.duracao_minutos)
                data_agendamento = agendamento.data_agendamento
                horario_inicio = agendamento.horario_inicio
                
                horario_fim = (datetime.combine(data_agendamento, horario_inicio) + duracao).time()
                agendamento.horario_fim = horario_fim
                
                # Definir preços
                agendamento.preco_servico = servico.preco
                
                if agendamento.is_emergencia:
                    agendamento.taxa_emergencia = servico.preco_adicional_emergencia
                
                # TODO: Verificar se é feriado e aplicar taxa
                
                agendamento.save()
                
                messages.success(request, 'Agendamento realizado com sucesso!')
                return redirect('servicos:meus_agendamentos')
                
            except Exception as e:
                messages.error(request, 'Erro ao criar agendamento. Tente novamente.')
    else:
        form = AgendarServicoForm(
            profissional=profissional,
            initial={'profissional': profissional, 'servico': servico}
        )
    
    context = {
        'form': form,
        'profissional': profissional,
        'servico': servico,
    }
    
    return render(request, 'servicos/agendar.html', context)


@login_required
def meus_agendamentos(request):
    """Lista agendamentos do usuário"""
    
    agendamentos = Agendamento.objects.filter(
        cliente=request.user
    ).select_related(
        'profissional', 'servico__tipo_servico'
    ).order_by('-data_agendamento', '-horario_inicio')
    
    # Filtros
    status_filter = request.GET.get('status')
    if status_filter:
        agendamentos = agendamentos.filter(status=status_filter)
    
    # Paginação
    paginator = Paginator(agendamentos, 10)
    page = request.GET.get('page')
    agendamentos_paginados = paginator.get_page(page)
    
    context = {
        'agendamentos': agendamentos_paginados,
        'status_choices': Agendamento.STATUS_CHOICES,
        'status_filter': status_filter,
    }
    
    return render(request, 'servicos/meus_agendamentos.html', context)


@login_required
def agendamento_detalhe(request, agendamento_id):
    """Detalhes do agendamento"""
    
    agendamento = get_object_or_404(
        Agendamento.objects.select_related(
            'profissional', 'servico__tipo_servico'
        ).prefetch_related('fotos'),
        id=agendamento_id,
        cliente=request.user
    )
    
    context = {
        'agendamento': agendamento,
        'pode_avaliar': agendamento.pode_avaliar and not hasattr(agendamento, 'avaliacao'),
    }
    
    return render(request, 'servicos/agendamento_detalhe.html', context)


@login_required
@require_POST
def cancelar_agendamento_view(request, agendamento_id):
    """Cancela agendamento"""
    
    agendamento = get_object_or_404(
        Agendamento,
        id=agendamento_id,
        cliente=request.user
    )
    
    if not agendamento.pode_cancelar:
        messages.error(request, 'Não é possível cancelar este agendamento (prazo expirado).')
    else:
        motivo = request.POST.get('motivo', '')
        agendamento.cancelar('cliente', motivo)
        messages.success(request, 'Agendamento cancelado com sucesso!')
    
    return redirect('servicos:agendamento_detalhe', agendamento_id=agendamento_id)


@login_required
def avaliar_servico_view(request, agendamento_id):
    """Avaliar serviço prestado"""
    
    agendamento = get_object_or_404(
        Agendamento,
        id=agendamento_id,
        cliente=request.user,
        status='concluido'
    )
    
    # Verificar se já foi avaliado
    if hasattr(agendamento, 'avaliacao'):
        messages.info(request, 'Este serviço já foi avaliado.')
        return redirect('servicos:agendamento_detalhe', agendamento_id=agendamento_id)
    
    if request.method == 'POST':
        form = AvaliarServicoForm(request.POST)
        
        if form.is_valid():
            avaliacao = form.save(commit=False)
            avaliacao.agendamento = agendamento
            avaliacao.profissional = agendamento.profissional
            avaliacao.cliente = request.user
            avaliacao.save()
            
            messages.success(request, 'Avaliação enviada com sucesso!')
            return redirect('servicos:agendamento_detalhe', agendamento_id=agendamento_id)
    else:
        form = AvaliarServicoForm()
    
    context = {
        'form': form,
        'agendamento': agendamento,
    }
    
    return render(request, 'servicos/avaliar.html', context)


@login_required
def cadastrar_profissional(request):
    """Cadastra usuário como profissional"""
    
    # Verificar se já é profissional
    if hasattr(request.user, 'profissional'):
        messages.info(request, 'Você já possui cadastro como profissional.')
        return redirect('servicos:painel_profissional')
    
    if request.method == 'POST':
        form = CadastroProfissionalForm(request.POST, request.FILES)
        
        if form.is_valid():
            profissional = form.save(commit=False)
            profissional.usuario = request.user
            profissional.save()
            
            messages.success(request, 
                'Cadastro enviado para análise! '
                'Você receberá um email quando for aprovado.'
            )
            return redirect('servicos:home')
    else:
        form = CadastroProfissionalForm()
    
    context = {
        'form': form,
    }
    
    return render(request, 'servicos/cadastrar_profissional.html', context)


# Views para profissionais (painel)
@login_required
def painel_profissional(request):
    """Dashboard do profissional"""
    
    try:
        profissional = request.user.profissional
    except Profissional.DoesNotExist:
        messages.error(request, 'Você não é um profissional cadastrado.')
        return redirect('servicos:cadastrar_profissional')
    
    # Estatísticas
    hoje = timezone.now().date()
    
    agendamentos_hoje = profissional.agendamentos.filter(
        data_agendamento=hoje
    ).count()
    
    agendamentos_pendentes = profissional.agendamentos.filter(
        status='pendente'
    ).count()
    
    agendamentos_este_mes = profissional.agendamentos.filter(
        data_agendamento__year=hoje.year,
        data_agendamento__month=hoje.month
    ).count()
    
    # Agendamentos recentes
    agendamentos_recentes = profissional.agendamentos.select_related(
        'cliente', 'servico__tipo_servico'
    ).order_by('-created_at')[:5]
    
    context = {
        'profissional': profissional,
        'agendamentos_hoje': agendamentos_hoje,
        'agendamentos_pendentes': agendamentos_pendentes,
        'agendamentos_este_mes': agendamentos_este_mes,
        'agendamentos_recentes': agendamentos_recentes,
    }
    
    return render(request, 'servicos/painel_profissional.html', context)


@login_required
def agendamentos_profissional(request):
    """Lista agendamentos do profissional"""
    
    try:
        profissional = request.user.profissional
    except Profissional.DoesNotExist:
        messages.error(request, 'Você não é um profissional cadastrado.')
        return redirect('servicos:cadastrar_profissional')
    
    agendamentos = profissional.agendamentos.select_related(
        'cliente', 'servico__tipo_servico'
    ).order_by('-data_agendamento', '-horario_inicio')
    
    # Filtros
    status_filter = request.GET.get('status')
    if status_filter:
        agendamentos = agendamentos.filter(status=status_filter)
    
    # Paginação
    paginator = Paginator(agendamentos, 15)
    page = request.GET.get('page')
    agendamentos_paginados = paginator.get_page(page)
    
    context = {
        'agendamentos': agendamentos_paginados,
        'status_choices': Agendamento.STATUS_CHOICES,
        'status_filter': status_filter,
    }
    
    return render(request, 'servicos/agendamentos_profissional.html', context)


# AJAX Views
@login_required
def buscar_horarios_ajax(request):
    """Busca horários disponíveis via AJAX"""
    
    profissional_id = request.GET.get('profissional_id')
    data_str = request.GET.get('data')
    
    if not profissional_id or not data_str:
        return JsonResponse({
            'success': False,
            'message': 'Parâmetros obrigatórios: profissional_id e data'
        })
    
    try:
        from datetime import datetime
        data = datetime.strptime(data_str, '%Y-%m-%d').date()
        
        profissional = get_object_or_404(Profissional, id=profissional_id)
        
        # Verificar disponibilidade
        dia_semana = data.weekday()
        disponibilidade = profissional.disponibilidades.filter(
            dia_semana=dia_semana,
            ativo=True
        ).first()
        
        if not disponibilidade:
            return JsonResponse({
                'success': True,
                'horarios': [],
                'message': 'Profissional não trabalha neste dia.'
            })
        
        # Gerar horários (intervalos de 30 min)
        from datetime import timedelta
        horarios = []
        hora_atual = disponibilidade.horario_inicio
        
        while hora_atual < disponibilidade.horario_fim:
            horarios.append(hora_atual.strftime('%H:%M'))
            dt = datetime.combine(data, hora_atual) + timedelta(minutes=30)
            hora_atual = dt.time()
        
        # Remover ocupados
        ocupados = profissional.agendamentos.filter(
            data_agendamento=data,
            status__in=['pendente', 'confirmado', 'em_andamento']
        ).values_list('horario_inicio', flat=True)
        
        horarios_disponiveis = [
            h for h in horarios 
            if datetime.strptime(h, '%H:%M').time() not in ocupados
        ]
        
        return JsonResponse({
            'success': True,
            'horarios': horarios_disponiveis
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': 'Erro ao buscar horários'
        })
