from django.urls import path, include
from . import views, api_views

app_name = 'carrinho'


urlpatterns = [
    # Visualização principal
    path('', views.carrinho_view, name='ver'),
    
    # Gerenciamento de produtos
    path('adicionar/', views.adicionar_ao_carrinho_view, name='adicionar'),
    path('item/<int:item_id>/atualizar/', views.atualizar_quantidade_view, name='atualizar_quantidade'),
    path('item/<int:item_id>/remover/', views.remover_do_carrinho_view, name='remover_item'),
    path('item/<int:item_id>/observacoes/', views.atualizar_observacoes_view, name='atualizar_observacoes'),
    
    # Operações do carrinho
    path('limpar/', views.limpar_carrinho_view, name='limpar'),
    path('cupom/', views.aplicar_cupom_view, name='aplicar_cupom'),
    
    # AJAX endpoints (para uso com JavaScript)
    path('ajax/contador/', views.carrinho_contador_ajax, name='ajax_contador'),
    path('ajax/validar/', views.validar_carrinho_ajax, name='ajax_validar'),
]


api_patterns = [
    # Carrinho principal
    path('', api_views.CarrinhoAPIView.as_view(), name='api_carrinho'),
    path('resumo/', api_views.carrinho_resumo, name='api_carrinho_resumo'),
    
    # Gerenciamento de itens
    path('adicionar/', api_views.adicionar_ao_carrinho, name='api_adicionar'),
    path('item/<int:item_id>/atualizar/', api_views.atualizar_quantidade, name='api_atualizar_quantidade'),
    path('item/<int:item_id>/remover/', api_views.remover_do_carrinho, name='api_remover_item'),
    
    # Operações do carrinho
    path('limpar/', api_views.limpar_carrinho, name='api_limpar'),
    path('validar/', api_views.validar_carrinho, name='api_validar'),
    path('cupom/', api_views.aplicar_cupom, name='api_aplicar_cupom'),
]

urlpatterns += [path('api/', include(api_patterns))]