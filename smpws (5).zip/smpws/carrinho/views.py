from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_protect
from django.db import transaction
from django.conf import settings
from decimal import Decimal
from .models import Carrinho, ItemCarrinho, Pedido, ItemPedido
from produtos.models import Produto
import json
import stripe
import mercadopago
from django.http import JsonResponse
from django.conf import settings

# Configurar Stripe
stripe.api_key = settings.STRIPE_SECRET_KEY

# Configurar Mercado Pago
mp_sdk = mercadopago.SDK(settings.MERCADOPAGO_ACCESS_TOKEN)

def test_settings(request):
    """Testa se as configurações do .env foram carregadas"""
    return JsonResponse({
        'debug': settings.DEBUG,
        'secret_key_loaded': bool(settings.SECRET_KEY),
        'stripe_public_key_loaded': bool(settings.STRIPE_PUBLIC_KEY),
        'stripe_secret_key_loaded': bool(settings.STRIPE_SECRET_KEY),
        'mercadopago_public_key_loaded': bool(settings.MERCADOPAGO_PUBLIC_KEY),
        'mercadopago_access_token_loaded': bool(settings.MERCADOPAGO_ACCESS_TOKEN),
    })

def get_or_create_carrinho(user):
    """Obtém ou cria carrinho do usuário"""
    carrinho, created = Carrinho.objects.get_or_create(usuario=user)
    return carrinho


@login_required
def adicionar_ao_carrinho(request, produto_id):
    """Adiciona produto ao carrinho"""
    produto = get_object_or_404(Produto, id=produto_id, ativo=True)
    carrinho = get_or_create_carrinho(request.user)
    
    quantidade = int(request.POST.get('quantidade', 1))
    
    # Verifica estoque
    if quantidade > produto.estoque:
        messages.error(request, f'Apenas {produto.estoque} unidades disponíveis.')
        return redirect('produtos:detalhe', produto_id=produto_id)
    
    # Verifica se já existe no carrinho
    item, created = ItemCarrinho.objects.get_or_create(
        carrinho=carrinho,
        produto=produto,
        defaults={'quantidade': quantidade, 'preco_unitario': produto.preco_final}
    )
    
    if not created:
        # Atualiza quantidade
        nova_quantidade = item.quantidade + quantidade
        if nova_quantidade > produto.estoque:
            messages.error(request, f'Apenas {produto.estoque} unidades disponíveis.')
            return redirect('carrinho:visualizar')
        item.quantidade = nova_quantidade
        item.save()
    
    messages.success(request, f'{produto.nome} adicionado ao carrinho!')
    
    # Retorna JSON se for requisição AJAX
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'total_itens': carrinho.total_itens,
            'message': f'{produto.nome} adicionado ao carrinho!'
        })
    
    return redirect('carrinho:visualizar')


@login_required
def visualizar_carrinho(request):
    """Visualiza carrinho"""
    carrinho = get_or_create_carrinho(request.user)
    itens = carrinho.itens.select_related('produto').all()
    
    frete_gratis_minimo = Decimal('200.00')
    falta_frete_gratis = max(Decimal('0'), frete_gratis_minimo - carrinho.subtotal)
    
    context = {
        'carrinho': carrinho,
        'itens': itens,
        'falta_frete_gratis': falta_frete_gratis,
        'frete_gratis_minimo': frete_gratis_minimo,
    }
    
    return render(request, 'carrinho/visualizar.html', context)


@login_required
@require_POST
def atualizar_quantidade(request, item_id):
    """Atualiza quantidade de um item"""
    item = get_object_or_404(ItemCarrinho, id=item_id, carrinho__usuario=request.user)
    
    try:
        quantidade = int(request.POST.get('quantidade', 1))
        
        if quantidade <= 0:
            return JsonResponse({'success': False, 'error': 'Quantidade deve ser maior que zero'})
        
        # Verifica estoque
        if quantidade > item.produto.estoque:
            return JsonResponse({
                'success': False, 
                'error': f'Apenas {item.produto.estoque} unidades disponíveis'
            })
        
        item.quantidade = quantidade
        item.save()
        
        return JsonResponse({
            'success': True,
            'item_total': float(item.total),
            'carrinho_subtotal': float(item.carrinho.subtotal),
            'carrinho_total': float(item.carrinho.total),
            'carrinho_frete': float(item.carrinho.frete)
        })
    except ValueError:
        return JsonResponse({'success': False, 'error': 'Quantidade inválida'})


@login_required
@require_POST
def remover_item(request, item_id):
    """Remove item do carrinho"""
    item = get_object_or_404(ItemCarrinho, id=item_id, carrinho__usuario=request.user)
    produto_nome = item.produto.nome
    item.delete()
    
    messages.success(request, f'{produto_nome} removido do carrinho!')
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        carrinho = get_or_create_carrinho(request.user)
        return JsonResponse({
            'success': True,
            'total_itens': carrinho.total_itens,
            'carrinho_subtotal': float(carrinho.subtotal),
            'carrinho_total': float(carrinho.total)
        })
    
    return redirect('carrinho:visualizar')


@login_required
def limpar_carrinho(request):
    """Limpa todo o carrinho"""
    carrinho = get_or_create_carrinho(request.user)
    carrinho.itens.all().delete()
    
    messages.success(request, 'Carrinho limpo!')
    return redirect('carrinho:visualizar')


@login_required
@csrf_protect
def checkout(request):
    """Página de checkout"""
    carrinho = get_or_create_carrinho(request.user)
    itens = carrinho.itens.select_related('produto').all()
    
    if not itens:
        messages.warning(request, 'Seu carrinho está vazio!')
        return redirect('produtos:lista')
    
    # Verifica estoque de todos os itens
    for item in itens:
        if item.quantidade > item.produto.estoque:
            messages.error(
                request, 
                f'{item.produto.nome} possui apenas {item.produto.estoque} unidades disponíveis.'
            )
            return redirect('carrinho:visualizar')
    
    # Busca endereços do usuário
    enderecos = []
    if hasattr(request.user, 'enderecos'):
        enderecos = request.user.enderecos.all()
    
    context = {
        'carrinho': carrinho,
        'itens': itens,
        'enderecos': enderecos,
        'STRIPE_PUBLIC_KEY': settings.STRIPE_PUBLIC_KEY if settings.STRIPE_PUBLIC_KEY else None,
        'MERCADOPAGO_PUBLIC_KEY': settings.MERCADOPAGO_PUBLIC_KEY if settings.MERCADOPAGO_PUBLIC_KEY else None,
        'stripe_configured': bool(settings.STRIPE_SECRET_KEY),
        'mercadopago_configured': bool(settings.MERCADOPAGO_ACCESS_TOKEN),
    }
    
    return render(request, 'carrinho/checkout.html', context)


@login_required
@csrf_protect
@transaction.atomic
def finalizar_pedido(request):
    """Finaliza pedido e processa pagamento"""
    if request.method != 'POST':
        return redirect('carrinho:checkout')
    
    carrinho = get_or_create_carrinho(request.user)
    itens = carrinho.itens.select_related('produto').all()
    
    if not itens:
        messages.error(request, 'Seu carrinho está vazio!')
        return redirect('produtos:lista')
    
    # Validação de estoque
    for item in itens:
        if item.quantidade > item.produto.estoque:
            messages.error(
                request, 
                f'{item.produto.nome} não possui estoque suficiente.'
            )
            return redirect('carrinho:visualizar')
    
    # Dados do formulário
    endereco_id = request.POST.get('endereco_id')
    endereco_entrega = request.POST.get('endereco_entrega', '')
    forma_pagamento = request.POST.get('forma_pagamento')
    observacoes = request.POST.get('observacoes', '')
    payment_token = request.POST.get('payment_token')
    
    # Validações
    if not endereco_id and not endereco_entrega:
        messages.error(request, 'Informe um endereço de entrega!')
        return redirect('carrinho:checkout')
    
    if not forma_pagamento:
        messages.error(request, 'Selecione uma forma de pagamento!')
        return redirect('carrinho:checkout')
    
    # Obtém endereço formatado
    if endereco_id:
        try:
            endereco_obj = request.user.enderecos.get(id=endereco_id)
            endereco_completo = f"{endereco_obj.logradouro}, {endereco_obj.numero}"
            if endereco_obj.complemento:
                endereco_completo += f", {endereco_obj.complemento}"
            endereco_completo += f" - {endereco_obj.bairro}, {endereco_obj.cidade}/{endereco_obj.estado} - CEP: {endereco_obj.cep}"
        except:
            endereco_completo = endereco_entrega
    else:
        endereco_completo = endereco_entrega
    
    # Aplica desconto do PIX
    desconto_pix = Decimal('0.05')  # 5%
    desconto = Decimal('0')
    
    if forma_pagamento == 'pix':
        desconto = carrinho.subtotal * desconto_pix
    
    total_final = carrinho.subtotal + carrinho.frete - desconto
    
    # Cria o pedido
    pedido = Pedido.objects.create(
        usuario=request.user,
        subtotal=carrinho.subtotal,
        desconto=desconto,
        frete=carrinho.frete,
        total=total_final,
        endereco_entrega=endereco_completo,
        forma_pagamento=forma_pagamento,
        observacoes=observacoes,
        status='pendente'
    )
    
    # Cria itens do pedido e atualiza estoque
    for item in itens:
        ItemPedido.objects.create(
            pedido=pedido,
            produto=item.produto,
            nome_produto=item.produto.nome,
            quantidade=item.quantidade,
            preco_unitario=item.preco_unitario,
            subtotal=item.total
        )
        
        # Atualiza estoque (reserva)
        item.produto.estoque -= item.quantidade
        item.produto.save()
    
    # Processa pagamento
    try:
        if forma_pagamento == 'cartao':
            # STRIPE - Processamento de cartão
            if not payment_token:
                raise ValueError('Token de pagamento não fornecido')
            
            charge = stripe.Charge.create(
                amount=int(total_final * 100),  # em centavos
                currency='brl',
                source=payment_token,
                description=f'Pedido #{pedido.numero_pedido} - Smart Paws',
                metadata={
                    'pedido_id': pedido.id,
                    'usuario_id': request.user.id,
                    'email': request.user.email
                }
            )
            
            pedido.payment_id = charge.id
            pedido.status = 'pago'
            pedido.save()
            
            messages.success(request, f'Pagamento aprovado! Pedido #{pedido.numero_pedido} confirmado.')
            
        elif forma_pagamento == 'pix':
            # MERCADO PAGO - Gera PIX
            payment_data = {
                "transaction_amount": float(total_final),
                "description": f"Pedido #{pedido.numero_pedido} - Smart Paws",
                "payment_method_id": "pix",
                "payer": {
                    "email": request.user.email,
                    "first_name": request.user.first_name or "Cliente",
                    "last_name": request.user.last_name or "Smart Paws"
                }
            }
            
            result = mp_sdk.payment().create(payment_data)
            payment_response = result["response"]
            
            if result["status"] == 201:
                # Extrai QR Code e link de pagamento
                pedido.qr_code_pix = payment_response.get("point_of_interaction", {}).get("transaction_data", {}).get("qr_code", "")
                pedido.qr_code_base64 = payment_response.get("point_of_interaction", {}).get("transaction_data", {}).get("qr_code_base64", "")
                pedido.payment_id = payment_response.get("id")
                pedido.status = 'aguardando_pagamento'
                pedido.save()
                
                messages.success(request, f'Pedido #{pedido.numero_pedido} criado! Escaneie o QR Code para pagar.')
            else:
                raise ValueError(f'Erro ao gerar PIX: {payment_response}')
                
        elif forma_pagamento == 'boleto':
            # MERCADO PAGO - Gera Boleto
            payment_data = {
                "transaction_amount": float(total_final),
                "description": f"Pedido #{pedido.numero_pedido} - Smart Paws",
                "payment_method_id": "bolbradesco",  # ou outro banco
                "payer": {
                    "email": request.user.email,
                    "first_name": request.user.first_name or "Cliente",
                    "last_name": request.user.last_name or "Smart Paws",
                    "identification": {
                        "type": "CPF",
                        "number": "12345678909"  # Obter do usuário
                    }
                }
            }
            
            result = mp_sdk.payment().create(payment_data)
            payment_response = result["response"]
            
            if result["status"] == 201:
                pedido.boleto_url = payment_response.get("transaction_details", {}).get("external_resource_url", "")
                pedido.payment_id = payment_response.get("id")
                pedido.status = 'aguardando_pagamento'
                pedido.save()
                
                messages.success(request, f'Pedido #{pedido.numero_pedido} criado! Boleto gerado com sucesso.')
            else:
                raise ValueError(f'Erro ao gerar boleto: {payment_response}')
    
    except stripe.error.CardError as e:
        # Erro no cartão
        pedido.status = 'falha_pagamento'
        pedido.save()
        
        # Devolve estoque
        for item in pedido.itens.all():
            item.produto.estoque += item.quantidade
            item.produto.save()
        
        messages.error(request, f'Erro no pagamento: {e.user_message}')
        return redirect('carrinho:checkout')
    
    except Exception as e:
        # Outro erro
        pedido.status = 'erro'
        pedido.save()
        
        # Devolve estoque
        for item in pedido.itens.all():
            item.produto.estoque += item.quantidade
            item.produto.save()
        
        messages.error(request, f'Erro ao processar pagamento: {str(e)}')
        return redirect('carrinho:checkout')
    
    # Limpa carrinho
    carrinho.itens.all().delete()
    
    return redirect('carrinho:pedido_confirmado', pedido_id=pedido.id)


@login_required
def pedido_confirmado(request, pedido_id):
    """Página de confirmação do pedido"""
    pedido = get_object_or_404(Pedido, id=pedido_id, usuario=request.user)
    
    context = {
        'pedido': pedido,
    }
    
    return render(request, 'carrinho/pedido_confirmado.html', context)


@login_required
def meus_pedidos(request):
    """Lista pedidos do usuário"""
    pedidos = Pedido.objects.filter(
        usuario=request.user
    ).prefetch_related('itens__produto').order_by('-criado_em')
    
    context = {
        'pedidos': pedidos,
    }
    
    return render(request, 'carrinho/meus_pedidos.html', context)


@login_required
def detalhe_pedido(request, pedido_id):
    """Detalhes de um pedido"""
    pedido = get_object_or_404(
        Pedido.objects.prefetch_related('itens__produto'),
        id=pedido_id,
        usuario=request.user
    )
    
    context = {
        'pedido': pedido,
    }
    
    return render(request, 'carrinho/detalhe_pedido.html', context)


# AJAX - Contador do carrinho no header
@login_required
def carrinho_count(request):
    """Retorna quantidade de itens no carrinho (AJAX)"""
    carrinho = get_or_create_carrinho(request.user)
    return JsonResponse({
        'count': carrinho.total_itens,
        'subtotal': float(carrinho.subtotal)
    })


# Webhook Mercado Pago para atualizar status de pagamento
@require_POST
def webhook_mercadopago(request):
    """Recebe notificações do Mercado Pago"""
    try:
        data = json.loads(request.body)
        
        if data.get('type') == 'payment':
            payment_id = data.get('data', {}).get('id')
            
            if payment_id:
                payment_info = mp_sdk.payment().get(payment_id)
                payment = payment_info["response"]
                
                # Busca pedido
                try:
                    pedido = Pedido.objects.get(payment_id=payment_id)
                    
                    if payment['status'] == 'approved':
                        pedido.status = 'pago'
                    elif payment['status'] == 'rejected':
                        pedido.status = 'falha_pagamento'
                        # Devolve estoque
                        for item in pedido.itens.all():
                            item.produto.estoque += item.quantidade
                            item.produto.save()
                    
                    pedido.save()
                except Pedido.DoesNotExist:
                    pass
        
        return JsonResponse({'status': 'ok'})
    
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
