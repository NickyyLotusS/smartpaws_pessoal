from django import forms
from django.core.validators import MinValueValidator, MaxValueValidator
from .models import ItemCarrinho
from produtos.models import Produto


class AdicionarCarrinhoForm(forms.Form):
    """Formulário para adicionar produto ao carrinho"""
    
    produto_id = forms.IntegerField(
        widget=forms.HiddenInput()
    )
    
    quantidade = forms.IntegerField(
        min_value=1,
        max_value=999,
        initial=1,
        widget=forms.NumberInput(attrs={
            'class': 'form-control text-center',
            'style': 'width: 80px;',
            'min': '1',
            'max': '999'
        }),
        label='Quantidade'
    )
    
    observacoes = forms.CharField(
        required=False,
        max_length=500,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': 'Observações sobre o produto (opcional)'
        }),
        label='Observações'
    )
    
    def __init__(self, produto=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        if produto:
            # Definir produto_id
            self.fields['produto_id'].initial = produto.id
            
            # Ajustar máximo baseado no estoque
            if produto.controlar_estoque:
                max_quantidade = min(produto.estoque, 999)
                self.fields['quantidade'].max_value = max_quantidade
                self.fields['quantidade'].widget.attrs['max'] = max_quantidade
                
                if max_quantidade <= 0:
                    self.fields['quantidade'].disabled = True
                    self.fields['quantidade'].help_text = 'Produto fora de estoque'
                elif max_quantidade < 10:
                    self.fields['quantidade'].help_text = f'Apenas {max_quantidade} unidades disponíveis'
    
    def clean_produto_id(self):
        """Valida se produto existe e está ativo"""
        produto_id = self.cleaned_data.get('produto_id')
        
        try:
            produto = Produto.objects.get(id=produto_id, ativo=True)
            return produto_id
        except Produto.DoesNotExist:
            raise forms.ValidationError('Produto não encontrado ou inativo.')
    
    def clean(self):
        """Validação geral do formulário"""
        cleaned_data = super().clean()
        produto_id = cleaned_data.get('produto_id')
        quantidade = cleaned_data.get('quantidade')
        
        if produto_id and quantidade:
            try:
                produto = Produto.objects.get(id=produto_id)
                
                # Verificar estoque
                if produto.controlar_estoque and quantidade > produto.estoque:
                    raise forms.ValidationError(
                        f'Apenas {produto.estoque} unidades disponíveis.'
                    )
                    
            except Produto.DoesNotExist:
                raise forms.ValidationError('Produto não encontrado.')
        
        return cleaned_data


class AtualizarQuantidadeForm(forms.Form):

    
    quantidade = forms.IntegerField(
        min_value=0,
        max_value=999,
        widget=forms.NumberInput(attrs={
            'class': 'form-control text-center quantidade-input',
            'style': 'width: 80px;',
            'min': '0',
            'max': '999'
        }),
        label='Quantidade'
    )
    
    def __init__(self, item=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        if item:
            # Valor inicial
            self.fields['quantidade'].initial = item.quantidade
            
            # Ajustar máximo baseado no estoque
            produto = item.produto
            if produto.controlar_estoque:
                max_quantidade = min(produto.estoque, 999)
                self.fields['quantidade'].widget.attrs['max'] = max_quantidade
                
                if max_quantidade < item.quantidade:
                    self.fields['quantidade'].help_text = f'Máximo disponível: {max_quantidade}'
    
    def clean_quantidade(self):
        """Valida quantidade"""
        quantidade = self.cleaned_data.get('quantidade')
        
        if quantidade is not None and quantidade < 0:
            raise forms.ValidationError('Quantidade não pode ser negativa.')
        
        return quantidade


class CupomDescontoForm(forms.Form):
    """Formulário para aplicar cupom de desconto"""
    
    codigo = forms.CharField(
        max_length=50,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Digite o código do cupom',
            'style': 'text-transform: uppercase;'
        }),
        label='Código do Cupom'
    )
    
    def clean_codigo(self):
        """Limpa e valida código do cupom"""
        codigo = self.cleaned_data.get('codigo', '').strip().upper()
        
        if len(codigo) < 3:
            raise forms.ValidationError('Código deve ter pelo menos 3 caracteres.')
        
        # TODO: Validar se cupom existe e está válido
        # Por enquanto, apenas retornar o código limpo
        
        return codigo


class ObservacoesItemForm(forms.ModelForm):
    """Formulário para editar observações de um item"""
    
    class Meta:
        model = ItemCarrinho
        fields = ['observacoes']
        widgets = {
            'observacoes': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Observações sobre este item...'
            })
        }
        labels = {
            'observacoes': 'Observações'
        }
    
    def clean_observacoes(self):
        """Limpa observações"""
        observacoes = self.cleaned_data.get('observacoes', '').strip()
        
        if len(observacoes) > 500:
            raise forms.ValidationError('Observações não podem exceder 500 caracteres.')
        
        return observacoes