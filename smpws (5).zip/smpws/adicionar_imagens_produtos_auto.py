import os
import django
import requests
from io import BytesIO
from django.core.files import File
import time

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartpaws.settings')
django.setup()

from produtos.models import Produto

print("\n" + "="*70)
print("🖼️ BAIXANDO IMAGENS REAIS DE PRODUTOS PET")
print("="*70 + "\n")

# IMAGENS REAIS DE PRODUTOS - URLs diretas
IMAGENS_PRODUTOS = {
    # ALIMENTOS
    'Ração Premium para Cães': 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800',
    'Ração Super Premium para Gatos': 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800',
    'Ração Úmida Sachê': 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800',
    'Petisco': 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800',
    'Bifinho': 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800',
    'Osso': 'https://images.unsplash.com/photo-1587764379873-97837921fd44?w=800',
    
    # BRINQUEDOS
    'Brinquedo Mordedor': 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=800',
    'Pelúcia': 'https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800',
    'Bolinha': 'https://images.unsplash.com/photo-1587764379873-97837921fd44?w=800',
    'Arranhador': 'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=800',
    'Corda': 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=800',
    'Frisbee': 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=800',
    
    # ROUPAS
    'Moletom': 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800',
    'Camiseta': 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800',
    'Bandana': 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800',
    'Capa de Chuva': 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800',
    
    # HIGIENE
    'Shampoo': 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=800',
    'Tapete Higiênico': 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=800',
    'Areia': 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=800',
    'Escova': 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=800',
    
    # SAÚDE
    'Antipulgas': 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=800',
    'Vermífugo': 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=800',
    'Suplemento': 'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=800',
    
    # CONFORTO
    'Cama': 'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=800',
    'Almofada': 'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=800',
    'Casinha': 'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=800',
    
    # ALIMENTAÇÃO
    'Comedouro': 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800',
    'Bebedouro': 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800',
    
    # PASSEIO
    'Coleira': 'https://images.unsplash.com/photo-1601758123927-4d2d6b3c7e90?w=800',
    'Guia': 'https://images.unsplash.com/photo-1601758123927-4d2d6b3c7e90?w=800',
    'Peitoral': 'https://images.unsplash.com/photo-1601758123927-4d2d6b3c7e90?w=800',
}

def encontrar_imagem_url(nome_produto):
    """Encontra URL da imagem baseada no nome do produto"""
    nome_lower = nome_produto.lower()
    
    for palavra_chave, url in IMAGENS_PRODUTOS.items():
        if palavra_chave.lower() in nome_lower:
            return url
    
    # Imagem padrão para pets
    if 'cão' in nome_lower or 'cães' in nome_lower:
        return 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800'
    elif 'gato' in nome_lower:
        return 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=800'
    
    return 'https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=800'

def baixar_imagem(url):
    """Baixa imagem da URL"""
    try:
        response = requests.get(url, timeout=15, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        if response.status_code == 200:
            return BytesIO(response.content)
            
    except Exception as e:
        print(f"   ❌ Erro: {e}")
    
    return None

def adicionar_imagens_produtos():
    produtos = Produto.objects.filter(imagem_principal__isnull=True) | Produto.objects.filter(imagem_principal='')
    
    if not produtos.exists():
        print("✅ Todos os produtos já têm imagens!\n")
        return
    
    print(f"📦 Encontrados {produtos.count()} produtos sem imagem\n")
    
    adicionados = 0
    falhas = 0
    
    for i, produto in enumerate(produtos, 1):
        print(f"[{i}/{produtos.count()}] {produto.nome[:50]}...")
        
        # Encontra URL da imagem
        url = encontrar_imagem_url(produto.nome)
        print(f"   📥 Baixando imagem...")
        
        # Baixa imagem
        imagem = baixar_imagem(url)
        
        if imagem:
            try:
                nome_arquivo = f"produto_{produto.id}.jpg"
                produto.imagem_principal.save(nome_arquivo, File(imagem), save=True)
                print(f"   ✅ Imagem adicionada!\n")
                adicionados += 1
            except Exception as e:
                print(f"   ❌ Erro ao salvar: {e}\n")
                falhas += 1
        else:
            print(f"   ❌ Falha ao baixar\n")
            falhas += 1
        
        # Delay para não sobrecarregar
        time.sleep(1)
    
    print("="*70)
    print("📊 RESUMO:")
    print(f"   ✅ Sucesso: {adicionados}")
    print(f"   ❌ Falhas: {falhas}")
    print("="*70 + "\n")

if __name__ == '__main__':
    try:
        adicionar_imagens_produtos()
        print("✨ Processo concluído!\n")
    except KeyboardInterrupt:
        print("\n\n⚠️ Interrompido\n")
    except Exception as e:
        print(f"\n❌ ERRO: {e}\n")
