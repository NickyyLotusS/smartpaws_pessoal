document.addEventListener('DOMContentLoaded', () => {
    const track = document.querySelector('.carrossel-track');
    const btnAnterior = document.querySelector('.carrossel-nav.anterior');
    const btnProximo = document.querySelector('.carrossel-nav.proximo');
    const items = document.querySelectorAll('.carrossel-item');
    
    if (!track || !items.length || !btnAnterior || !btnProximo) {
        console.log('Carrossel não encontrado nesta página');
        return;
    }
    
    // DUPLICA OS ITENS PARA CRIAR LOOP INFINITO
    const itemsArray = Array.from(items);
    itemsArray.forEach(item => {
        const clone = item.cloneNode(true);
        track.appendChild(clone);
    });
    
    // DUPLICA NOVAMENTE PARA LOOP MAIS SUAVE
    itemsArray.forEach(item => {
        const clone = item.cloneNode(true);
        track.appendChild(clone);
    });
    
    let currentIndex = 0;
    let itemsPerView = 4; // 4 cards visíveis por padrão
    let autoplayInterval;
    const autoplayDelay = 3000; // 3 segundos
    const totalOriginal = items.length;
    
    function updateItemsPerView() {
        const width = window.innerWidth;
        if (width <= 480) {
            itemsPerView = 1;
        } else if (width <= 768) {
            itemsPerView = 2;
        } else if (width <= 1024) {
            itemsPerView = 3;
        } else {
            itemsPerView = 4;
        }
    }
    
    function updateCarousel(instant = false) {
        const allItems = track.querySelectorAll('.carrossel-item');
        const itemWidth = allItems[0].offsetWidth;
        const gap = 15;
        const offset = -(currentIndex * (itemWidth + gap));
        
        if (instant) {
            track.style.transition = 'none';
        } else {
            track.style.transition = 'transform 0.5s ease';
        }
        
        track.style.transform = `translateX(${offset}px)`;
        
        // Remove transition após aplicar
        if (instant) {
            setTimeout(() => {
                track.style.transition = 'transform 0.5s ease';
            }, 50);
        }
        
        // Botões sempre habilitados (loop infinito)
        btnAnterior.disabled = false;
        btnProximo.disabled = false;
    }
    
    function nextSlide() {
        currentIndex++;
        updateCarousel();
        
        // Quando chegar ao final dos originais, volta pro início instantaneamente
        if (currentIndex >= totalOriginal) {
            setTimeout(() => {
                currentIndex = 0;
                updateCarousel(true);
            }, 500);
        }
    }
    
    function prevSlide() {
        currentIndex--;
        
        // Se for menor que 0, pula pro final
        if (currentIndex < 0) {
            currentIndex = totalOriginal - 1;
            updateCarousel(true);
            setTimeout(() => {
                updateCarousel();
            }, 50);
        } else {
            updateCarousel();
        }
    }
    
    function startAutoplay() {
        stopAutoplay(); // Limpa qualquer interval existente
        autoplayInterval = setInterval(nextSlide, autoplayDelay);
    }
    
    function stopAutoplay() {
        if (autoplayInterval) {
            clearInterval(autoplayInterval);
        }
    }
    
    // Event listeners
    btnProximo.addEventListener('click', () => {
        nextSlide();
        stopAutoplay();
        startAutoplay();
    });
    
    btnAnterior.addEventListener('click', () => {
        prevSlide();
        stopAutoplay();
        startAutoplay();
    });
    
    // Para autoplay ao passar o mouse
    track.addEventListener('mouseenter', stopAutoplay);
    track.addEventListener('mouseleave', startAutoplay);
    
    // Navegação por teclado
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
            stopAutoplay();
            startAutoplay();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
            stopAutoplay();
            startAutoplay();
        }
    });
    
    // Touch/Swipe para mobile
    let touchStartX = 0;
    let touchEndX = 0;
    
    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
        stopAutoplay();
    });
    
    track.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
        startAutoplay();
    });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;
        
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                nextSlide();
            } else {
                prevSlide();
            }
        }
    }
    
    // Atualiza ao redimensionar
    window.addEventListener('resize', () => {
        updateItemsPerView();
        updateCarousel(true);
    });
    
    // Inicialização
    updateItemsPerView();
    updateCarousel();
    startAutoplay();
});

// ==========================================
// MENU DROPDOWN
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    const dropdowns = document.querySelectorAll('.has-dropdown');
    
    if (!dropdowns.length) {
        console.log('Nenhum dropdown encontrado nesta página');
        return;
    }

    dropdowns.forEach(dropdown => {
        const trigger = dropdown.querySelector('a');
        
        if (!trigger) return;

        trigger.addEventListener('click', function(event) {
            if (trigger.getAttribute('href') === '#') {
                event.preventDefault();

                document.querySelectorAll('.has-dropdown.is-open').forEach(openDropdown => {
                    if (openDropdown !== dropdown) {
                        openDropdown.classList.remove('is-open');
                    }
                });

                dropdown.classList.toggle('is-open');
            }
        });
    });

    window.addEventListener('click', function(event) {
        if (!event.target.closest('.has-dropdown')) {
            document.querySelectorAll('.has-dropdown.is-open').forEach(openDropdown => {
                openDropdown.classList.remove('is-open');
            });
        }
    });
});

// ==========================================
// ANIMAÇÃO REVEAL AO ROLAR
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    const elementsToReveal = document.querySelectorAll('.reveal-on-scroll');
    
    if (!elementsToReveal.length) {
        console.log('Nenhum elemento para revelar nesta página');
        return;
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    elementsToReveal.forEach(element => {
        observer.observe(element);
    });
});

// ==========================================
// BOTÃO VOLTAR AO TOPO
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    const backToTopButton = document.getElementById('back-to-top-btn');
    
    if (!backToTopButton) {
        console.log('Botão voltar ao topo não encontrado nesta página');
        return;
    }

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            backToTopButton.classList.add('is-visible');
        } else {
            backToTopButton.classList.remove('is-visible');
        }
    });

    backToTopButton.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});


// static/JS/busca.js

document.addEventListener('DOMContentLoaded', function() {
    const inputBusca = document.getElementById('barra_pesquisa');
    const sugestoesDiv = document.getElementById('sugestoes-busca');
    let timeoutBusca;
    
    if (!inputBusca) return;
    
    // Buscar ao digitar
    inputBusca.addEventListener('input', function() {
        const termo = this.value.trim();
        
        clearTimeout(timeoutBusca);
        
        if (termo.length < 2) {
            sugestoesDiv.style.display = 'none';
            return;
        }
        
        // Aguarda 300ms antes de buscar (debounce)
        timeoutBusca = setTimeout(() => {
            buscarProdutos(termo);
        }, 300);
    });
    
    // Fechar sugestões ao clicar fora
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.busca-wrapper')) {
            sugestoesDiv.style.display = 'none';
        }
    });
    
    // Reabrir sugestões ao focar no input (se já tiver conteúdo)
    inputBusca.addEventListener('focus', function() {
        if (this.value.trim().length >= 2 && sugestoesDiv.innerHTML) {
            sugestoesDiv.style.display = 'block';
        }
    });
    
    // Submit do formulário com Enter
    inputBusca.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sugestoesDiv.style.display = 'none';
        }
    });
    
    // Buscar produtos via AJAX
    async function buscarProdutos(termo) {
        try {
            const response = await fetch(`/produtos/buscar/?q=${encodeURIComponent(termo)}`);
            const data = await response.json();
            
            if (data.produtos && data.produtos.length > 0) {
                mostrarSugestoes(data.produtos);
            } else {
                mostrarBuscaVazia(termo);
            }
        } catch (error) {
            console.error('Erro ao buscar produtos:', error);
            sugestoesDiv.style.display = 'none';
        }
    }
    
    // Mostrar sugestões
    function mostrarSugestoes(produtos) {
        let html = '';
        
        produtos.forEach(produto => {
            html += `
                <a href="${produto.url}" class="sugestao-item">
                    <img src="${produto.imagem}" alt="${produto.nome}" class="sugestao-imagem" onerror="this.src='/static/IMG/produtos/default.png'">
                    <div class="sugestao-info">
                        <p class="sugestao-nome">${produto.nome}</p>
                        <p class="sugestao-categoria">${produto.categoria}</p>
                    </div>
                    <div class="sugestao-preco">R$ ${produto.preco}</div>
                </a>
            `;
        });
        
        sugestoesDiv.innerHTML = html;
        sugestoesDiv.style.display = 'block';
    }
    
    // Mostrar mensagem vazia
    function mostrarBuscaVazia(termo) {
        sugestoesDiv.innerHTML = `
            <div class="busca-vazia">
                <i class="fas fa-search"></i>
                <p>Nenhum resultado para "${termo}"</p>
                <p style="font-size: 12px; margin-top: 10px;">Tente buscar por outro termo</p>
            </div>
        `;
        sugestoesDiv.style.display = 'block';
    }
});
