import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartpaws.settings')
django.setup()

from pets.models import Pet
from servicos.models import Servico
from produtos.models import Produto
from django.core.files import File

print("\n" + "="*70)
print("🖼️ SMART PAWS - ADICIONAR IMAGENS")
print("="*70 + "\n")

# ============================================
# PETS
# ============================================

print("🐾 Adicionando imagens aos pets...\n")

IMAGENS_PETS = {
    'Rex': 'billy.png',
    'Luna': 'bolinha.png',
    'Max': 'cleiton.png',
    'Bella': 'joca.png',
    'Thor': 'juju.png',
    'Nina': 'muca.png',
    'Bob': 'skoob.png',
    'Mel': 'xavier.png',
    'Zeus': 'cerveja.webp',
    'Lola': 'golden.webp',
    'Duke': 'pug.webp',
    'Mia': 'sorriso.webp',
    'Rocky': 'fro.webp',
    'Sophie': 'bagaco.webp',
    'Charlie': 'pidao.webp',
}

pets_adicionados = 0
pets = Pet.objects.all()

for pet in pets:
    if pet.foto_principal:
        print(f"⏭️  {pet.nome} já tem imagem")
        continue
    
    arquivo = IMAGENS_PETS.get(pet.nome)
    
    if not arquivo:
        print(f"⚠️  {pet.nome} - Sem imagem definida")
        continue
    
    caminho = f'media/pets/{arquivo}'
    
    if os.path.exists(caminho):
        with open(caminho, 'rb') as f:
            pet.foto_principal.save(arquivo, File(f), save=True)
        print(f"✅ {pet.nome} - Imagem adicionada!")
        pets_adicionados += 1
    else:
        print(f"❌ {pet.nome} - Arquivo não encontrado: {caminho}")

# ============================================
# SERVIÇOS
# ============================================

print("\n💼 Adicionando imagens aos serviços...\n")

IMAGENS_SERVICOS = {
    'Banho e Tosa Completo': 'banho_tosa.jpg',
    'Banho Básico': 'banho_basico.jpg',
    'Tosa Higiênica': 'tosa_higienica.jpg',
    'Consulta Veterinária': 'veterinario.jpg',
    'Vacinação V10': 'vacina.jpg',
    'Vacinação Antirrábica': 'vacina_raiva.jpg',
    'Hotel Pet - Diária': 'hotel_pet.jpg',
    'Creche Pet Diária': 'creche_pet.jpg',
    'Dog Walker - 30min': 'passeio.jpg',
    'Dog Walker - 1 hora': 'passeio_longo.jpg',
    'Adestramento Básico': 'adestramento.jpg',
    'Adestramento Avançado': 'adestramento_avancado.jpg',
}

servicos_adicionados = 0
servicos = Servico.objects.all()

for servico in servicos:
    if servico.imagem:
        print(f"⏭️  {servico.nome} já tem imagem")
        continue
    
    arquivo = IMAGENS_SERVICOS.get(servico.nome)
    
    if not arquivo:
        print(f"⚠️  {servico.nome} - Sem imagem definida")
        continue
    
    caminho = f'media/servicos/{arquivo}'
    
    if os.path.exists(caminho):
        with open(caminho, 'rb') as f:
            servico.imagem.save(arquivo, File(f), save=True)
        print(f"✅ {servico.nome} - Imagem adicionada!")
        servicos_adicionados += 1
    else:
        print(f"❌ {servico.nome} - Arquivo não encontrado: {caminho}")

# ============================================
# PRODUTOS
# ============================================

print("\n📦 Adicionando imagens aos produtos...\n")

IMAGENS_PRODUTOS = {
    'Ração Golden Fórmula Adultos': 'racao_golden_adulto.jpg',
    'Ração Royal Canin Filhote': 'racao_royal_filhote.jpg',
    'Petisco Palito Carne': 'petisco_palito.jpg',
    'Coleira de Couro': 'coleira_couro.jpg',
    'Cama Pet Macia': 'cama_pet.jpg',
    'Brinquedo Mordedor': 'brinquedo_mordedor.jpg',
    'Shampoo Pet': 'shampoo.jpg',
    'Areia Sanitária': 'areia_sanitaria.jpg',
    'Comedouro Inox': 'comedouro.jpg',
    'Bebedouro Automático': 'bebedouro.jpg',
}

produtos_adicionados = 0
produtos = Produto.objects.all()

for produto in produtos:
    if produto.imagem_principal:
        print(f"⏭️  {produto.nome} já tem imagem")
        continue
    
    arquivo = IMAGENS_PRODUTOS.get(produto.nome)
    
    if not arquivo:
        print(f"⚠️  {produto.nome} - Sem imagem definida")
        continue
    
    caminho = f'media/produtos/{arquivo}'
    
    if os.path.exists(caminho):
        with open(caminho, 'rb') as f:
            produto.imagem_principal.save(arquivo, File(f), save=True)
        print(f"✅ {produto.nome} - Imagem adicionada!")
        produtos_adicionados += 1
    else:
        print(f"❌ {produto.nome} - Arquivo não encontrado: {caminho}")



# ============================================
# RESUMO
# ============================================

print("\n" + "="*70)
print("✅ RESUMO FINAL:")
print(f"   🐾 Pets: {pets_adicionados}")
print(f"   💼 Serviços: {servicos_adicionados}")
print(f"   📦 Produtos: {produtos_adicionados}")
print("="*70)
print("\n✨ Processo de imagens concluído! 🎉\n")