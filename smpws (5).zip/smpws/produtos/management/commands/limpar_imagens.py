from django.core.management.base import BaseCommand
from produtos.models import Produto

class Command(BaseCommand):
    help = 'Remove todas as imagens dos produtos'

    def handle(self, *args, **kwargs):
        self.stdout.write('🗑️ Removendo imagens...\n')
        
        produtos = Produto.objects.exclude(imagem_principal__isnull=True).exclude(imagem_principal='')
        total = produtos.count()
        
        if total == 0:
            self.stdout.write(self.style.WARNING('Nenhum produto com imagem encontrado'))
            return
        
        self.stdout.write(f'📦 Encontrados {total} produtos com imagens\n')
        
        removidos = 0
        for produto in produtos:
            if produto.imagem_principal:
                produto.imagem_principal.delete(save=False)
                produto.imagem_principal = None
                produto.save()
                
                self.stdout.write(self.style.SUCCESS(f'✅ {produto.nome[:50]}'))
                removidos += 1
        
        self.stdout.write(self.style.SUCCESS(f'\n🎉 Total removido: {removidos}'))
