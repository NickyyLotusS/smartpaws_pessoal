# produtos/management/commands/baixar_imagens.py

import requests
import time
from io import BytesIO
from django.core.management.base import BaseCommand
from produtos.models import Produto
from django.core.files import File

class Command(BaseCommand):
    help = 'Baixa imagens do Unsplash e atribui aos produtos'

    def handle(self, *args, **kwargs):
        UNSPLASH_ACCESS_KEY = 'DRs4tFOFQvwmJXh-TKQDkEDsh6MREuJjhLrowJg0MhY'
        
        produtos = Produto.objects.filter(imagem_principal='')
        total = produtos.count()
        
        self.stdout.write(self.style.SUCCESS(f'🖼️  Iniciando download de {total} imagens...\n'))
        
        for index, produto in enumerate(produtos, 1):
            self.stdout.write(f'[{index}/{total}] Processando: {produto.nome}')
            
            query = self.extrair_query(produto.nome)
            url = f'https://api.unsplash.com/photos/random?query={query}&client_id={UNSPLASH_ACCESS_KEY}'
            
            try:
                response = requests.get(url, timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    image_url = data['urls']['regular']
                    
                    # Baixar imagem
                    img_response = requests.get(image_url, timeout=15)
                    
                    if img_response.status_code == 200:
                        # MUDANÇA AQUI: usar BytesIO ao invés de NamedTemporaryFile
                        img_io = BytesIO(img_response.content)
                        
                        # Salvar no ImageField
                        produto.imagem_principal.save(
                            f'produto_{produto.id}.jpg',
                            File(img_io),
                            save=True
                        )
                        
                        self.stdout.write(self.style.SUCCESS(f'  ✅ Imagem atrelada'))
                    else:
                        self.stdout.write(self.style.ERROR(f'  ❌ Erro ao baixar imagem'))
                        
                else:
                    self.stdout.write(self.style.WARNING(f'  ⚠️  API retornou {response.status_code}'))
                    
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'  ❌ Erro: {str(e)}'))
            
            # Delay para respeitar rate limit (50 req/hora)
            time.sleep(1)
        
        self.stdout.write(self.style.SUCCESS(f'\n🎉 Processo concluído!'))
        self.stdout.write(self.style.SUCCESS(f'📊 {Produto.objects.exclude(imagem_principal="").count()} produtos com imagem'))
    
    def extrair_query(self, nome_produto):
        """Extrai palavras-chave e traduz para inglês"""
        mapeamento = {
            'ração': 'pet food',
            'brinquedo': 'pet toy',
            'cama': 'pet bed',
            'coleira': 'dog collar',
            'guia': 'dog leash',
            'comedouro': 'pet bowl',
            'bebedouro': 'pet water fountain',
            'shampoo': 'pet shampoo',
            'tapete': 'pet training pad',
            'cães': 'dog',
            'gatos': 'cat',
            'petisco': 'dog treat',
            'moletom': 'dog clothes',
            'camiseta': 'dog shirt',
            'arranhador': 'cat scratching post',
            'antipulgas': 'flea treatment',
            'vermífugo': 'pet dewormer',
            'sachê': 'cat wet food',
            'osso': 'dog bone toy',
            'bolinha': 'dog ball',
            'rastreador': 'pet gps tracker',
            'peitoral': 'dog harness',
            'bandana': 'dog bandana',
            'capa': 'dog raincoat',
            'gravata': 'dog bow tie',
            'areia': 'cat litter',
            'granulado': 'cat litter',
            'escova': 'pet brush',
            'cortador': 'pet nail clipper',
            'lenço': 'pet wipes',
            'fonte': 'pet water fountain',
            'frisbee': 'dog frisbee',
            'corda': 'dog rope toy',
        }
        
        nome_lower = nome_produto.lower()
        
        for termo_pt, termo_en in mapeamento.items():
            if termo_pt in nome_lower:
                return termo_en
        
        return 'pet product'
