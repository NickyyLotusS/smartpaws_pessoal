# ==========================================
# produtos/views.py
# ==========================================
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView, DetailView
from django.db.models import Q, Count, Avg
from .models import Produto, CategoriaProduto
from .forms import ProdutoFiltroForm


class ProdutoListView(ListView):
    """Lista de produtos com filtros avançados"""
    model = Produto
    template_name = 'produtos/lista.html'
    context_object_name = 'produtos'
    paginate_by = 20
    
    def get_queryset(self):
        queryset = Produto.objects.filter(ativo=True).select_related('categoria')
        
        # Parâmetros do filtro
        busca = self.request.GET.get('busca', '').strip()
        categoria_param = self.request.GET.get('categoria')
        preco_min = self.request.GET.get('preco_min')
        preco_max = self.request.GET.get('preco_max')
        em_promocao = self.request.GET.get('em_promocao')
        ordenar = self.request.GET.get('ordenar', 'relevancia')
        
        # Filtro de busca
        if busca:
            queryset = queryset.filter(
                Q(nome__icontains=busca) |
                Q(descricao__icontains=busca) |
                Q(categoria__nome__icontains=busca)
            )
        
        # ============================================
        # FILTRO POR CATEGORIA - CORRIGIDO
        # ============================================
        if categoria_param:
            # Verifica se é um número (ID) ou texto (slug/nome)
            if categoria_param.isdigit():
                # É um ID
                queryset = queryset.filter(categoria_id=categoria_param)
            else:
                # É um slug ou nome - busca pela categoria
                queryset = queryset.filter(
                    Q(categoria__slug__iexact=categoria_param) |
                    Q(categoria__slug__icontains=categoria_param) |
                    Q(categoria__nome__iexact=categoria_param) |
                    Q(categoria__nome__icontains=categoria_param)
                )
        
        # Filtro por preço
        if preco_min:
            try:
                queryset = queryset.filter(preco_original__gte=float(preco_min))
            except ValueError:
                pass
                
        if preco_max:
            try:
                queryset = queryset.filter(preco_original__lte=float(preco_max))
            except ValueError:
                pass
        
        # Filtro de promoção
        if em_promocao:
            queryset = queryset.filter(preco_desconto__isnull=False)
        
        # Ordenação
        if ordenar == 'menor_preco':
            queryset = queryset.order_by('preco_original')
        elif ordenar == 'maior_preco':
            queryset = queryset.order_by('-preco_original')
        elif ordenar == 'melhor_avaliacao':
            queryset = queryset.order_by('-avaliacao', '-numero_avaliacoes')
        elif ordenar == 'nome_az':
            queryset = queryset.order_by('nome')
        elif ordenar == 'nome_za':
            queryset = queryset.order_by('-nome')
        else:  # relevancia ou mais_vendidos
            queryset = queryset.order_by('-destaque', '-created_at')
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Formulário de filtros
        context['form_filtro'] = ProdutoFiltroForm(self.request.GET)
        
        # Todas as categorias
        context['categorias'] = CategoriaProduto.objects.filter(ativo=True).annotate(
            total_produtos=Count('produtos', filter=Q(produtos__ativo=True))
        )
        
        # Produtos em destaque
        context['produtos_destaque'] = Produto.objects.filter(
            ativo=True, 
            destaque=True
        )[:4]
        
        # Estatísticas
        context['total_produtos'] = self.get_queryset().count()
        
        # Categoria selecionada
        categoria_param = self.request.GET.get('categoria')
        categoria_selecionada = None
        
        if categoria_param:
            if categoria_param.isdigit():
                categoria_selecionada = CategoriaProduto.objects.filter(id=categoria_param).first()
            else:
                categoria_selecionada = CategoriaProduto.objects.filter(
                    Q(slug__iexact=categoria_param) | 
                    Q(slug__icontains=categoria_param) |
                    Q(nome__iexact=categoria_param) |
                    Q(nome__icontains=categoria_param)
                ).first()
        
        context['categoria_selecionada'] = categoria_selecionada
        
        # Parâmetros atuais (para manter filtros ativos)
        context['filtros_ativos'] = {
            'busca': self.request.GET.get('busca', ''),
            'categoria': self.request.GET.get('categoria', ''),
            'preco_min': self.request.GET.get('preco_min', ''),
            'preco_max': self.request.GET.get('preco_max', ''),
            'em_promocao': self.request.GET.get('em_promocao', ''),
            'ordenar': self.request.GET.get('ordenar', 'relevancia'),
        }
        
        return context


class ProdutoDetailView(DetailView):
    """Detalhes do produto"""
    model = Produto
    template_name = 'produtos/detalhe.html'
    context_object_name = 'produto'
    slug_field = 'slug'
    slug_url_kwarg = 'slug'
    
    def get_queryset(self):
        return Produto.objects.filter(ativo=True).select_related('categoria')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Produtos relacionados
        context['produtos_relacionados'] = Produto.objects.filter(
            categoria=self.object.categoria,
            ativo=True
        ).exclude(pk=self.object.pk)[:6]
        
        return context


def buscar_produtos_ajax(request):
    """Busca produtos via AJAX para sugestões"""
    termo = request.GET.get('q', '').strip()
    
    if len(termo) < 2:
        return JsonResponse({'produtos': []})
    
    produtos = Produto.objects.filter(
        Q(nome__icontains=termo) |
        Q(descricao__icontains=termo) |
        Q(categoria__nome__icontains=termo),
        ativo=True
    ).select_related('categoria')[:8]
    
    resultados = []
    for p in produtos:
        resultados.append({
            'nome': p.nome,
            'categoria': p.categoria.nome if p.categoria else 'Sem categoria',
            'preco': f"{p.preco_final:.2f}".replace('.', ','),
            'imagem': p.imagem_principal.url if p.imagem_principal else '/static/IMG/produtos/default.png',
            'url': p.get_absolute_url()
        })
    
    return JsonResponse({'produtos': resultados})