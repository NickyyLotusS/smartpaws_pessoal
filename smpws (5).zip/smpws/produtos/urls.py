# ==========================================
# produtos/urls.py
# ==========================================

from django.urls import path
from . import views

app_name = 'produtos'

urlpatterns = [
    # Busca AJAX (DEVE VIR ANTES!)
    path('buscar/', views.buscar_produtos_ajax, name='buscar_ajax'),
    
    # Lista de produtos (com filtros)
    path('', views.ProdutoListView.as_view(), name='lista'),
    
    # Filtrar por categoria (opcional)
    path('categoria/<slug:categoria_slug>/', views.ProdutoListView.as_view(), name='por_categoria'),
    
    # Detalhe do produto (DEVE VIR POR ÚLTIMO!)
    path('<slug:slug>/', views.ProdutoDetailView.as_view(), name='detalhe'),
]
